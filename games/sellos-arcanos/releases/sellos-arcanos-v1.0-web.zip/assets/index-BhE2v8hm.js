(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const a of s)if(a.type==="childList")for(const r of a.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&n(r)}).observe(document,{childList:!0,subtree:!0});function t(s){const a={};return s.integrity&&(a.integrity=s.integrity),s.referrerPolicy&&(a.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?a.credentials="include":s.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function n(s){if(s.ep)return;s.ep=!0;const a=t(s);fetch(s.href,a)}})();const nn={vacio:{es:"Vacío",en:"Void",domain:"arcano"},fuego:{es:"Fuego",en:"Fire",domain:"igneo"},abismo:{es:"Abismo",en:"Abyss",domain:"abisal"},rayo:{es:"Rayo",en:"Lightning",domain:"igneo"},infierno:{es:"Infierno",en:"Inferno",domain:"igneo"},veneno:{es:"Veneno",en:"Poison",domain:"natural"},hielo:{es:"Hielo",en:"Ice",domain:"abisal"},tierra:{es:"Tierra",en:"Earth",domain:"natural"},cosmos:{es:"Cosmos",en:"Cosmos",domain:"abisal"},sombra:{es:"Sombra",en:"Shadow",domain:"arcano"},luz:{es:"Luz",en:"Light",domain:"arcano"},cristal:{es:"Cristal",en:"Crystal",domain:"natural"}},us={abisal:{es:"Abisal",en:"Abyssal",beats:"igneo",color:"#2ff2d6"},igneo:{es:"Ígneo",en:"Igneous",beats:"natural",color:"#ff7a2e"},natural:{es:"Natural",en:"Natural",beats:"arcano",color:"#3dff88"},arcano:{es:"Arcano",en:"Arcane",beats:"abisal",color:"#b06bff"}},Od={asalto:{es:"Asalto",en:"Assault"},tanque:{es:"Tanque",en:"Tank"},hechicero:{es:"Hechicero",en:"Sorcerer"},soporte:{es:"Soporte",en:"Support"}},Hn=[{es:"Cría",en:"Hatchling",scale:.62,mult:1},{es:"Adulta",en:"Adult",scale:.78,mult:1.12},{es:"Primordial",en:"Primordial",scale:.92,mult:1.3}];function Bd(i,e){const t=nn[i].domain,n=nn[e].domain;return us[t].beats===n?1.3:us[n].beats===t?.77:1}const xt=(i,e,t)=>i<<16|e<<8|t,En=[{id:"hidra",num:"01",el:"vacio",role:"asalto",color:"#b06bff",body:xt(80,74,100),bone:xt(146,136,174),stats:[90,70,45,95],circle:"hexagrama",halo:!0,island:11,nodes:9,name:{es:"Hidra del Vacío",en:"Void Hydra"},sub:{es:"Jefe colosal · Cinco cabezas",en:"Colossal boss · Five heads"},lore:{es:"Cada cabeza recuerda una estrella que devoró. Si cortas una, el vacío hace crecer dos.",en:"Each head remembers a star it devoured. Cut one off and the void grows two."}},{id:"fenix",num:"02",el:"fuego",role:"soporte",color:"#ff7a2e",body:xt(86,75,87),bone:xt(155,136,157),stats:[70,45,85,100],circle:"heptagrama",halo:!0,island:6,nodes:7,name:{es:"Fénix Solar",en:"Solar Phoenix"},sub:{es:"Ave legendaria · Renace de su ceniza",en:"Legendary bird · Reborn from its ashes"},lore:{es:"Cuando muere se convierte en amanecer. Sus plumas siguen ardiendo mil años después de caer.",en:"When it dies it becomes a sunrise. Its feathers keep burning a thousand years after they fall."}},{id:"kraken",num:"03",el:"abismo",role:"tanque",color:"#2ff2d6",body:xt(73,81,92),bone:xt(138,144,164),stats:[80,95,35,90],circle:"pentagrama",island:7,nodes:8,name:{es:"Kraken Abisal",en:"Abyssal Kraken"},sub:{es:"Titán marino · Ocho brazos",en:"Sea titan · Eight arms"},lore:{es:"Duerme bajo la fosa más honda del océano. Sus ojos son la única luz que ven los barcos hundidos.",en:"It sleeps beneath the ocean's deepest trench. Its eyes are the only light sunken ships ever see."}},{id:"grifo",num:"04",el:"rayo",role:"asalto",color:"#4fb4ff",body:xt(74,78,97),bone:xt(139,141,170),stats:[95,55,100,50],circle:"hexagrama",island:4,nodes:6,name:{es:"Grifo de Tormenta",en:"Storm Griffin"},sub:{es:"Guardián alado · Cazador del cielo",en:"Winged guardian · Sky hunter"},lore:{es:"Mitad águila, mitad león. Cada batir de alas suelta un relámpago sobre quien ose tocar su nido.",en:"Half eagle, half lion. Every beat of its wings looses lightning on whoever dares touch its nest."}},{id:"cerbero",num:"05",el:"infierno",role:"asalto",color:"#ff3d3d",body:xt(89,73,87),bone:xt(158,134,158),stats:[100,70,85,45],circle:"pentagrama",island:9,nodes:6,name:{es:"Cerbero Infernal",en:"Infernal Cerberus"},sub:{es:"Guardián del umbral · Tres cabezas",en:"Threshold guardian · Three heads"},lore:{es:"Una cabeza vigila el pasado, otra el presente y la última el futuro. Ninguna duerme jamás.",en:"One head watches the past, another the present and the last the future. None of them ever sleeps."}},{id:"basilisco",num:"06",el:"veneno",role:"hechicero",color:"#3dff88",body:xt(73,81,89),bone:xt(138,145,159),stats:[75,65,60,100],circle:"heptagrama",island:2,nodes:7,name:{es:"Basilisco Esmeralda",en:"Emerald Basilisk"},sub:{es:"Rey de las serpientes · Mirada de piedra",en:"King of serpents · Stone gaze"},lore:{es:"Su corona es de hueso y su mirada, de piedra. Quienes lo enfrentaron siguen en pie, convertidos en estatuas.",en:"Its crown is bone and its gaze is stone. Those who faced it still stand, turned to statues."}},{id:"wyvern",num:"07",el:"hielo",role:"hechicero",color:"#9fefff",body:xt(76,80,94),bone:xt(142,143,167),stats:[80,60,65,95],circle:"hexagrama",island:3,nodes:6,name:{es:"Wyvern de Escarcha",en:"Frost Wyvern"},sub:{es:"Dragón bípedo · Aliento helado",en:"Two-legged dragon · Frost breath"},lore:{es:"Anida en los picos donde el viento no deja huellas. Su aliento convierte la lluvia en cristal.",en:"It nests on peaks where the wind leaves no tracks. Its breath turns rain into crystal."}},{id:"golem",num:"08",el:"tierra",role:"tanque",color:"#ffb23e",body:xt(75,65,58),bone:xt(151,139,158),stats:[85,100,30,85],circle:"pentagrama",island:1,nodes:5,name:{es:"Gólem Rúnico",en:"Runic Golem"},sub:{es:"Constructo ancestral · Corazón de runas",en:"Ancient construct · Heart of runes"},lore:{es:"Ninguna de sus rocas se toca. Lo mantiene unido una sola runa encendida en el pecho.",en:"None of its rocks touch. A single rune burning in its chest holds it together."}},{id:"leviatan",num:"09",el:"cosmos",role:"hechicero",color:"#7f8cff",body:xt(63,68,106),bone:xt(142,138,173),stats:[70,70,60,100],circle:"heptagrama",island:10,nodes:8,name:{es:"Leviatán Celeste",en:"Celestial Leviathan"},sub:{es:"Titán del cielo · Nada entre estrellas",en:"Sky titan · Swims among stars"},lore:{es:"Las constelaciones de su piel cambian cada noche. Los astrónomos antiguos lo confundían con el cielo.",en:"The constellations on its skin change every night. Ancient astronomers mistook it for the sky."}},{id:"aracna",num:"10",el:"sombra",role:"soporte",color:"#ff4fd2",body:xt(87,73,95),bone:xt(156,134,167),stats:[75,55,90,80],circle:"hexagrama",island:8,nodes:8,name:{es:"Reina Aracna",en:"Arachne Queen"},sub:{es:"Matriarca · Ocho ojos",en:"Matriarch · Eight eyes"},lore:{es:"Teje sellos en lugar de telarañas. Cada hilo que toca el suelo es un hechizo a punto de cerrarse.",en:"She weaves seals instead of webs. Every thread that touches the ground is a spell about to close."}},{id:"ciervo",num:"11",el:"luz",role:"soporte",color:"#ffd76a",body:xt(83,79,85),bone:xt(149,141,158),stats:[55,65,90,90],circle:"heptagrama",island:0,nodes:4,name:{es:"Ciervo Astral",en:"Astral Stag"},sub:{es:"Espíritu del bosque · Astas de cristal",en:"Forest spirit · Crystal antlers"},lore:{es:"Solo aparece en noches sin luna. Donde pisa nacen flores que brillan hasta el amanecer.",en:"It only appears on moonless nights. Where it steps, flowers bloom that glow until dawn."}},{id:"tortuga",num:"12",el:"cristal",role:"tanque",color:"#b4ff4a",body:xt(79,83,71),bone:xt(143,144,158),stats:[65,100,35,100],circle:"pentagrama",island:5,nodes:6,name:{es:"Tortuga Ancestral",en:"Ancient Tortoise"},sub:{es:"Titán milenario · Montaña viviente",en:"Thousand-year titan · Living mountain"},lore:{es:"Lleva mil años caminando. Los cristales de su caparazón crecen un palmo cada siglo.",en:"It has been walking for a thousand years. The crystals on its shell grow a handspan every century."}}],ct=Object.fromEntries(En.map(i=>[i.id,i])),ua=["fenix","kraken","basilisco"],du={BASE_URL:"./",DEV:!1,MODE:"production",PROD:!0,SSR:!1},ir=new URLSearchParams(location.search),Zs=du||{};function hu(){const i=ir.get("platform");if(i)return i;const e=location.hostname+" "+document.referrer;return/crazygames/.test(e)?"crazygames":/poki/.test(e)?"poki":/gamedistribution|gdgames/.test(e)?"gamedistribution":/itch\.io|itch\.zone|hwcdn/.test(e)?"itch":Zs.VITE_PLATFORM||"web"}function Er(i){return new Promise((e,t)=>{const n=document.createElement("script");n.src=i,n.async=!0,n.onload=e,n.onerror=t,document.head.appendChild(n)})}const mi={pause:()=>{},resume:()=>{}},Tr=Zs.VITE_API_BASE||"",Ds=Zs.VITE_ADSENSE_CLIENT||"",Ar=ir.has("fakeads");let Cr=Date.now();const uu=18e4,je={name:hu(),sdk:null,adsReady:!1,iapReady:!1,noAds:!1,setHooks(i){Object.assign(mi,i)},async init(){try{if(this.name==="crazygames")await Er("https://sdk.crazygames.com/crazygames-sdk-v3.js"),await window.CrazyGames.SDK.init(),this.sdk=window.CrazyGames.SDK,this.adsReady=this.sdk.environment!=="disabled";else if(this.name==="poki")await Er("https://game-cdn.poki.com/scripts/v2/poki-sdk.js"),await window.PokiSDK.init(),this.sdk=window.PokiSDK,this.adsReady=!0;else if(this.name==="gamedistribution")await new Promise(i=>{window.GD_OPTIONS={gameId:Zs.VITE_GD_GAME_ID||"",onEvent:e=>{e.name==="SDK_READY"&&i(),e.name==="SDK_GAME_PAUSE"&&mi.pause(),e.name==="SDK_GAME_START"&&mi.resume()}},Er("https://html5.api.gamedistribution.com/main.min.js").catch(i),setTimeout(i,5e3)}),this.sdk=window.gdsdk,this.adsReady=!!this.sdk;else if(this.name==="web"&&Ds){window.adsbygoogle=window.adsbygoogle||[],window.adBreak=window.adConfig=function(e){window.adsbygoogle.push(e)};const i=document.createElement("script");i.async=!0,i.dataset.adClient=Ds,Zs.DEV&&(i.dataset.adbreakTest="on"),i.src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client="+Ds,i.crossOrigin="anonymous",document.head.appendChild(i),window.adConfig({preloadAdBreaks:"on",sound:"on"}),this.adsReady=!0}}catch(i){console.warn("SDK de plataforma no disponible",i),this.sdk=null,this.adsReady=!1}if(Ar&&(this.adsReady=!0),this.name==="web"||this.name==="itch")try{const e=await(await fetch(Tr+"/api/checkout",{method:"GET"})).json();this.iapReady=!!e.enabled}catch{this.iapReady=!1}},loadingStart(){this.name==="crazygames"&&this.sdk?.game?.loadingStart?.()},loadingStop(){this.name==="crazygames"&&this.sdk?.game?.loadingStop?.(),this.name==="poki"&&this.sdk?.gameLoadingFinished?.()},gameplayStart(){this.name==="crazygames"&&this.sdk?.game?.gameplayStart?.(),this.name==="poki"&&this.sdk?.gameplayStart?.()},gameplayStop(){this.name==="crazygames"&&this.sdk?.game?.gameplayStop?.(),this.name==="poki"&&this.sdk?.gameplayStop?.()},happytime(){this.name==="crazygames"&&this.sdk?.game?.happytime?.()},async storageGet(i){return this.name==="crazygames"&&this.sdk?.data?this.sdk.data.getItem(i):null},async storageSet(i,e){this.name==="crazygames"&&this.sdk?.data&&this.sdk.data.setItem(i,e)},hasRewarded(){return this.adsReady},rewarded(){if(!this.adsReady)return Promise.resolve(!1);mi.pause();const i=e=>(mi.resume(),Cr=Date.now(),e);return Ar?new Promise(e=>setTimeout(()=>e(i(!0)),1200)):this.name==="crazygames"?new Promise(e=>{this.sdk.ad.requestAd("rewarded",{adStarted:()=>{},adFinished:()=>e(i(!0)),adError:()=>e(i(!1))})}):this.name==="poki"?this.sdk.rewardedBreak(()=>{}).then(e=>i(!!e)).catch(()=>i(!1)):this.name==="gamedistribution"?this.sdk.showAd("rewarded").then(()=>i(!0)).catch(()=>i(!1)):this.name==="web"&&Ds?new Promise(e=>{let t=!1;window.adBreak({type:"reward",name:"reward",beforeReward:n=>n(),adViewed:()=>{t=!0},adDismissed:()=>{t=!1},adBreakDone:()=>e(i(t))})}):Promise.resolve(i(!1))},interstitial(){if(!this.adsReady||this.noAds||Ar||Date.now()-Cr<uu)return Promise.resolve();Cr=Date.now(),mi.pause();const i=()=>mi.resume();return this.name==="crazygames"?new Promise(e=>{this.sdk.ad.requestAd("midgame",{adStarted:()=>{},adFinished:()=>{i(),e()},adError:()=>{i(),e()}})}):this.name==="poki"?this.sdk.commercialBreak(()=>{}).then(i,i):this.name==="gamedistribution"?this.sdk.showAd().then(i,i):this.name==="web"&&Ds?new Promise(e=>{window.adBreak({type:"next",name:"between_runs",adBreakDone:()=>{i(),e()}})}):(i(),Promise.resolve())},canBuy(){return this.iapReady},async buy(i,e){const t=await fetch(Tr+"/api/checkout",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sku:i,lang:e,returnUrl:location.href.split("?")[0].split("#")[0]})}),n=await t.json();if(!t.ok||!n.url)throw new Error(n.error||"checkout");location.href=n.url},async consumeReturn(){const i=ir.get("session_id");if(!i||ir.get("purchase")!=="ok")return null;history.replaceState(null,"",location.pathname);const t=await(await fetch(Tr+"/api/verify?session_id="+encodeURIComponent(i))).json();return t.paid?{sku:t.sku,session:i}:null}},sr="sellos_arcanos_save_v1",ri=10,vo=10*60*1e3;function di(){const i=new Date;return`${i.getFullYear()}-${i.getMonth()+1}-${i.getDate()}`}function zd(){const i={};for(const e of En)i[e.id]={seen:!1,forms:[!1,!1,!1]};return{v:1,created:Date.now(),name:"",starterChosen:!1,tutorialDone:!1,rankXp:0,essence:300,crystals:0,ink:ri,inkTs:Date.now(),fragments:{},creatures:{},team:[],bestiary:i,islands:{unlocked:0,cleared:[]},cosmetics:{tints:[],seals:["propio"],effects:["anillo"],seal:"propio",effect:"anillo"},daily:{day:0,last:""},contracts:{date:"",list:[]},pass:{season:1,xp:0,premium:!1,free:[],prem:[]},ads:{date:"",ink:0,chest:!1},purchases:{sessions:[],founder:!1,noAds:!1},settings:{lang:"",music:.6,sfx:.8,quality:"auto",shake:!0},stats:{seals:0,perfect:0,kills:0,runs:0,bosses:0,ults:0,playMs:0},titles:[],milestones:[]}}const C=zd();let _o=0;function Hd(i,e){for(const t in e)e[t]&&typeof e[t]=="object"&&!Array.isArray(e[t])&&i[t]&&typeof i[t]=="object"&&!Array.isArray(i[t])?Hd(i[t],e[t]):i[t]=e[t]}async function fu(){let i=null;try{i=await je.storageGet(sr)}catch{}if(!i)try{i=localStorage.getItem(sr)}catch{i=null}if(i)try{const e=JSON.parse(i);Hd(C,e)}catch(e){console.warn("save corrupto, empezando de nuevo",e)}return gr(),C}function as(){clearTimeout(_o);const i=JSON.stringify(C);try{localStorage.setItem(sr,i)}catch{}je.storageSet(sr,i).catch(()=>{})}function ht(){clearTimeout(_o),_o=setTimeout(as,400)}function pu(){const i=zd();for(const e of Object.keys(C))delete C[e];Object.assign(C,i),as()}function gr(){const i=Date.now();if(C.ink>=ri){C.inkTs=i;return}const e=Math.floor((i-C.inkTs)/vo);e>0&&(C.ink=Math.min(ri,C.ink+e),C.inkTs+=e*vo,C.ink>=ri&&(C.inkTs=i),ht())}function mu(){return C.ink>=ri?0:Math.max(0,vo-(Date.now()-C.inkTs))}function Gd(i){C.ink=Math.min(ri+20,C.ink+i),ht()}function gu(){return gr(),C.ink<=0?!1:(C.ink>=ri&&(C.inkTs=Date.now()),C.ink-=1,ht(),!0)}const T=(i,e)=>({es:i,en:e}),vu={gameTitle:T("Sellos Arcanos","Arcane Seals"),tagline:T("Invoca · Sella · Domina","Summon · Seal · Rule"),play:T("Jugar","Play"),pressStart:T("Pulsa Enter o toca la pantalla","Press Enter or tap the screen"),language:T("Idioma","Language"),settings:T("Ajustes","Settings"),settingsSub:T("Controles, sonido y gráficos","Controls, sound and graphics"),season1:T("Temporada 1","Season 1"),eclipse:T("Eclipse","Eclipse"),loading:T("Cargando","Loading"),noWebgl:T("Tu navegador no admite WebGL. Prueba con Chrome, Edge, Firefox o Safari actualizados.","Your browser does not support WebGL. Try an up-to-date Chrome, Edge, Firefox or Safari."),orderWelcome:T("La Orden de los Selladores te da la bienvenida","The Order of Sealers welcomes you"),chooseFirst:T("Elige tu primera criatura","Choose your first creature"),chooseFirstHelp:T("Las doce Bestias Primordiales escaparon cuando se rompió el Sello del Vacío. Vincúlate con una Cría para empezar a sellarlas.","The twelve Primordial Beasts broke free when the Void Seal shattered. Bond with a hatchling to start sealing them."),yourName:T("Tu nombre de Sellador","Your Sealer name"),defaultName:T("Sellador","Sealer"),bindPact:T("Sellar el pacto","Seal the pact"),rank:T("Rango","Rank"),xp:T("de experiencia","XP"),mainMenu:T("Menú principal","Main menu"),chapter:T("Capítulo","Chapter"),bestiary:T("Bestiario","Bestiary"),formsSealed:T("{n} de 36 formas selladas","{n} of 36 forms sealed"),team:T("Equipo","Team"),shop:T("Tienda","Shop"),shopSub:T("Tintes de la temporada Eclipse","Eclipse season tints"),pass:T("Pase Arcano","Arcane Pass"),passSub:T("Nivel {n} de 30","Tier {n} of 30"),dailyReward:T("Recompensa diaria","Daily reward"),dayOf:T("Día {n} de 7","Day {n} of 7"),claim:T("Reclamar","Claim"),claimed:T("Reclamado","Claimed"),claimedReward:T("¡Recompensa reclamada!","Reward claimed!"),founderPack:T("Pack del Fundador","Founder Pack"),founderSub:T("Oferta única: 600 cristales + tinte Prisma","One-time offer: 600 crystals + Prism tint"),dailyContracts:T("Contratos del día","Today's contracts"),yourTeam:T("Tu equipo","Your team"),viewLeader:T("Ver ficha del líder","View leader"),milestone:T("¡Hito del Bestiario: {n} formas! +{c} cristales","Bestiary milestone: {n} forms! +{c} crystals"),contract:T("Contrato","Contract"),menu:T("Menú","Menu"),mapTitle:T("Mapa del Velo","Map of the Veil"),mapSub:T("Doce islas flotan sobre el Abismo. Elige tu destino.","Twelve islands float above the Abyss. Choose your destination."),citadel:T("Ciudadela del Sello","Seal Citadel"),islandN:T("Isla {n}","Island {n}"),lvl:T("Nv","Lv"),completed:T("completada","completed"),locked:T("bloqueada","locked"),inProgress:T("en curso","in progress"),primordial:T("Primordial","Primordial"),levels:T("Niveles","Levels"),element:T("Elemento","Element"),creatures:T("Criaturas","Creatures"),loot:T("Botín","Loot"),fragmentsOf:T("Fragmentos de {el}","{el} Fragments"),clearPrevious:T("Vence al Primordial anterior","Defeat the previous Primordial"),travel:T("Viajar","Travel"),travelingTo:T("Viajando a","Travelling to"),tip:T("Consejo","Tip"),fromBestiary:T("Del Bestiario","From the Bestiary"),islandReady:T("Isla lista","Island ready"),enter:T("Entrar","Enter"),music:T("Música","Music"),sounds:T("Sonidos","Sounds"),graphics:T("Gráficos","Graphics"),q_auto:T("Auto","Auto"),q_low:T("Bajos","Low"),q_medium:T("Medios","Medium"),q_high:T("Altos","High"),screenShake:T("Vibración de cámara","Screen shake"),yes:T("Sí","Yes"),no:T("No","No"),fullscreen:T("Pantalla completa","Fullscreen"),controls:T("Controles","Controls"),k_move:T("Moverse","Move"),k_abilities:T("Habilidades","Abilities"),k_ult:T("Definitiva (con la barra de Sello llena)","Ultimate (when the Seal bar is full)"),space:T("Espacio","Space"),spaceShort:T("Esp","Spc"),k_dodge:T("Esquivar","Dodge"),k_switch:T("Cambiar de criatura","Switch creature"),k_target:T("Cambiar de objetivo","Cycle target"),k_seal:T("Trazar sello (criatura débil)","Trace seal (weakened creature)"),k_pause:T("Pausa","Pause"),touchHelp:T("En móvil: joystick a la izquierda, habilidades a la derecha, desliza el dedo para esquivar y toca un retrato para cambiar de criatura. También funciona con mando.","On mobile: joystick on the left, abilities on the right, swipe to dodge and tap a portrait to switch creatures. Gamepads work too."),privacy:T("Privacidad","Privacy"),privacyText:T("Tu progreso se guarda en este dispositivo. No pedimos datos personales. Los pagos los procesa Stripe y los anuncios, la plataforma donde juegas.","Your progress is saved on this device. We do not ask for personal data. Payments are processed by Stripe and ads by the platform you play on."),resetProgress:T("Borrar progreso","Reset progress"),resetConfirm:T("Se borrará todo tu progreso en este dispositivo. No se puede deshacer.","All your progress on this device will be deleted. This cannot be undone."),reset:T("Borrar","Delete"),close:T("Cerrar","Close"),ok:T("Aceptar","OK"),cancel:T("Cancelar","Cancel"),hp:T("Vida","HP"),energy:T("Energía","Energy"),sealBar:T("Sello","Seal"),pause:T("Pausa","Pause"),move:T("Mover","Move"),dodge:T("Esquivar","Dodge"),swipeDodge:T("Desliza para esquivar","Swipe to dodge"),traceSealBtn:T("Trazar sello","Trace seal"),sealCost:T("Gasta 1 Tinta Rúnica · te quedan {n}","Costs 1 Runic Ink · {n} left"),noInk:T("Sin Tinta Rúnica: se recarga sola (1 cada 10 min)","No Runic Ink: it refills on its own (1 every 10 min)"),bossSealFree:T("El sello del Primordial no gasta Tinta","Sealing a Primordial costs no Ink"),beats:T("vence a","beats"),sealable:T("Sellable","Sealable"),shieldedAnchors:T("Protegido · {n} anclas","Shielded · {n} anchors"),runeAnchor:T("Ancla rúnica","Rune anchor"),breakAnchors:T("Rómpelas para poder sellarlo","Break them to seal it"),switchTo:T("Cambiar a {name}","Switch to {name}"),wave:T("Oleada {a} / {b}","Wave {a} / {b}"),dodged:T("Esquivado","Dodged"),immune:T("Inmune","Immune"),reflected:T("¡Reflejado!","Reflected!"),sealOpen:T("¡Sello abierto! Traza su runa","Seal open! Trace its rune"),bossSealOpen:T("¡El Primordial está débil! Séllalo","The Primordial is weak! Seal it"),anchorsBroken:T("¡Anclas rotas!","Anchors broken!"),anchors:T("Rompe las cuatro anclas rúnicas","Break the four rune anchors"),starShower:T("¡Lluvia de Estrellas!","Starfall!"),phase:T("Fase {n}","Phase {n}"),sealFailed:T("El sello resiste","The seal resists"),ultimate:T("Definitiva","Ultimate"),tut1:T("Muévete con WASD. Ataca con Q y E: apuntan solas al enemigo más cercano.","Move with WASD. Attack with Q and E: they aim at the nearest enemy."),tut1t:T("Mueve con el joystick (izquierda) y ataca con los botones de la derecha.","Move with the joystick (left) and attack with the buttons on the right."),tut2:T("Espacio para esquivar. Sal de los círculos rojos del suelo.","Space to dodge. Get out of the red circles on the ground."),tut2t:T("Desliza el dedo para esquivar. Sal de los círculos rojos del suelo.","Swipe to dodge. Get out of the red circles on the ground."),tut3:T("Bájale la vida a menos del 25 % y pulsa «Trazar sello» para capturarlo.","Drop its HP below 25% and press “Trace seal” to capture it."),tut4:T("Golpear llena tu barra de Sello: al 100 % usa la Definitiva (F).","Hitting fills your Seal bar: at 100% use your Ultimate (F)."),sealing:T("Sellado","Sealing"),traceSeal:T("Traza el sello: {name}","Trace the seal: {name}"),traceHelp:T("Une los nodos en orden antes de que el círculo se apague.","Connect the nodes in order before the circle fades."),ink:T("Tinta Rúnica","Runic Ink"),inkHelp:T("Cada intento gasta 1. Se recarga sola: 1 cada 10 minutos.","Each attempt costs 1. It refills on its own: 1 every 10 minutes."),time:T("Tiempo","Time"),struggle:T("La criatura forcejea: los nodos tiemblan.","The creature struggles: the nodes tremble."),perfectTrace:T("Trazo perfecto","Perfect trace"),sealed:T("¡Sellado!","Sealed!"),sealResists:T("El sello resiste","The seal resists"),perfectBonus:T("Vínculo alto y +50 % de Esencia","Strong bond and +50% Essence"),decimal:T(",","."),inMin:T("en {n} min","in {n} min"),noInkTitle:T("Sin Tinta Rúnica","Out of Runic Ink"),noInkBody:T("Necesitas Tinta para trazar el sello. Se recarga sola, o puedes ver un anuncio para conseguir 3 ahora.","You need Ink to trace the seal. It refills on its own, or you can watch an ad to get 3 now."),inkGained:T("+{n} Tinta Rúnica","+{n} Runic Ink"),pathEnds:T("El sendero termina","The path ends"),bossFirst:T("El Primordial de la isla te espera en su círculo. Si lo sellas, la siguiente isla se abrirá.","The island’s Primordial awaits in its circle. Seal it and the next island opens."),bossAgain:T("{name} ha vuelto a despertar. Enfréntalo de nuevo para conseguir más fragmentos.","{name} has awakened again. Face it once more for extra fragments."),returnCitadel:T("Volver a la Ciudadela","Return to the Citadel"),facePrimordial:T("Enfrentar al Primordial","Face the Primordial"),teamFell:T("Tu equipo ha caído","Your team has fallen"),teamFellBody:T("Puedes revivir a tu equipo con la mitad de la vida o retirarte con la mitad de la Esencia ganada.","You can revive your team at half HP or retreat with half the Essence earned."),revive:T("Revivir","Revive"),retreat:T("Retirarse","Retreat"),ad:T("anuncio","ad"),essenceShort:T("Esencia","Essence"),abandon:T("Abandonar expedición","Abandon expedition"),abandonBody:T("Volverás a la Ciudadela con la mitad de la Esencia y la experiencia. Las criaturas selladas se quedan contigo.","You will return with half the Essence and XP. Sealed creatures stay with you."),resume:T("Continuar","Resume"),primordialSealed:T("¡Primordial sellado!","Primordial sealed!"),expeditionDone:T("Expedición completada","Expedition complete"),retreated:T("Retirada","Retreat"),newEntry:T("{n} nueva(s) entrada(s) en el Bestiario","{n} new Bestiary entr(ies)"),victory:T("Victoria","Victory"),withdrawal:T("Vuelves a la Ciudadela","Back to the Citadel"),islandUnlocked:T("Nueva isla desbloqueada: {isle}","New island unlocked: {isle}"),newCreature:T("¡Nueva criatura en tu grimorio!","New creature in your grimoire!"),duplicateBonus:T("Ya la tenías: más vínculo y fragmentos","Already owned: more bond and fragments"),teamXp:T("Experiencia del equipo","Team experience"),essence:T("Esencia","Essence"),inclPerfect:T("Incluye +50 % por trazo perfecto","Includes +50% for perfect traces"),essenceHelp:T("Para entrenar a tus criaturas","To train your creatures"),fragments:T("Fragmentos de sello","Seal fragments"),fragmentsHelp:T("Para evolucionar a la forma Adulta","To evolve into the Adult form"),crystals:T("Cristales Arcanos","Arcane Crystals"),firstClear:T("Por sellar al Primordial por primera vez","For sealing the Primordial the first time"),passXp:T("XP del Pase Arcano","Arcane Pass XP"),passXpHelp:T("Sube de nivel el pase de la temporada","Levels up the season pass"),contractDone:T("Contrato completado","Contract complete"),doubleEssence:T("Duplicar Esencia","Double Essence"),doubled:T("+{n} Esencia extra","+{n} bonus Essence"),continue:T("Continuar","Continue"),thirdSlot:T("¡Rango 10! Ya puedes llevar 3 criaturas en el equipo","Rank 10! You can now bring 3 creatures"),greatBestiary:T("Gran Bestiario","Great Bestiary"),bestiarySub:T("Doce Primordiales, tres formas cada uno: Cría, Adulta y Primordial.","Twelve Primordials, three forms each: Hatchling, Adult and Primordial."),sealedForms:T("Formas selladas","Sealed forms"),all:T("Todas","All"),sealedF:T("Selladas","Sealed"),seenF:T("Vistas","Seen"),unknownF:T("Por descubrir","Undiscovered"),teamHelp:T("Equipo de hasta {n}. Abre una ficha para añadirla.","Team of up to {n}. Open an entry to add it."),titleHelp:T("Completa las tres formas de una criatura para ganar su título.","Complete all three forms of a creature to earn its title."),inTeam:T("Equipo","Team"),seenNotSealed:T("Vista · sin sellar","Seen · not sealed"),undiscovered:T("Por descubrir","Undiscovered"),notFoundYet:T("Aún no la has encontrado. Vive en {isle}.","Not found yet. It lives in {isle}."),domain:T("Dominio","Domain"),level:T("Nivel","Level"),maxLevel:T("Nivel máximo","Max level"),bond:T("Vínculo","Bond"),addToTeam:T("Añadir al equipo","Add to team"),removeFromTeam:T("Quitar del equipo","Remove from team"),train:T("Entrenar","Train"),evolve:T("Evolucionar","Evolve"),evolveTo:T("Evolucionar a {f}","Evolve to {f}"),evoReq1:T("Adulta: nivel 20 y 30 Fragmentos de {el} (tienes {have}).","Adult: level 20 and 30 {el} Fragments (you have {have})."),evoReq2:T("Primordial: nivel 40 y vencer al jefe de {isle}.","Primordial: level 40 and defeat the boss of {isle}."),evolveConfirm:T("{name} evolucionará a su forma {f}: más tamaño, más brillo y nuevas habilidades.","{name} will evolve into its {f} form: bigger, brighter and with new abilities."),evolved:T("¡{name} es ahora {f}!","{name} is now {f}!"),notSealedYet:T("Aún sin sellar","Not sealed yet"),livesIn:T("Su forma Cría vive en {isle} (isla {n}).","Its Hatchling form lives in {isle} (island {n})."),stats300:T("Estadísticas · 300 puntos","Stats · 300 points"),power:T("Poder","Power"),defense:T("Defensa","Defense"),agility:T("Agilidad","Agility"),magic:T("Magia","Magic"),abilities:T("Habilidades","Abilities"),unlocksAdult:T("se desbloquea en la forma Adulta","unlocks in the Adult form"),forms:T("Formas","Forms"),currentForm:T("Forma actual","Current form"),reqAdult:T("Nivel 20 y 30 fragmentos","Level 20 and 30 fragments"),reqPrimordial:T("Nivel 40 y vencer al jefe","Level 40 and beat the boss"),glowTints:T("Tintes de brillo","Glow tints"),original:T("Original","Original"),dragToRotate:T("Arrastra para girar","Drag to rotate"),teamMin:T("Tu equipo necesita al menos una criatura","Your team needs at least one creature"),teamFull:T("Tu equipo ya tiene {n}. Quita una antes.","Your team already has {n}. Remove one first."),tintPreview:T("Así se vería tu {name} con este tinte. Solo cambia el color: no da poder.","This is how your {name} would look. It only changes the color: no power."),getCrystals:T("Cristales","Crystals"),sealDesigns:T("Diseños de sello","Seal designs"),summonEffects:T("Efectos de invocación","Summon effects"),freeOffers:T("Gratis","Free"),earnCrystals:T("Consigue cristales jugando","Earn crystals by playing"),earnCrystalsHelp:T("Ganas Cristales Arcanos con la recompensa diaria, los hitos del Bestiario, el Pase Arcano y al sellar a cada Primordial por primera vez.","You earn Arcane Crystals from daily rewards, Bestiary milestones, the Arcane Pass and by sealing each Primordial for the first time."),bestValue:T("Mejor oferta","Best value"),tag_popular:T("Popular","Popular"),tag_bonus:T("+8 % extra","+8% bonus"),tag_value:T("Mejor valor","Top value"),seasonEclipse:T("Temporada Eclipse","Eclipse season"),tintFor:T("Tinte de brillo para {name}: cambia el neón de sus runas, ojos y círculo.","Glow tint for {name}: changes the neon of its runes, eyes and circle."),owned:T("Tuyo","Owned"),equip:T("Equipar","Equip"),equipped:T("Equipado","Equipped"),effectHelp:T("Se ve cada vez que invocas o cambias de criatura.","Shows every time you summon or switch creatures."),adInkHelp:T("Mira un anuncio corto. Te quedan {n} hoy.","Watch a short ad. {n} left today."),watchAd:T("Ver anuncio","Watch ad"),dailyChest:T("Cofre diario","Daily chest"),dailyChestHelp:T("500 Esencia y 5 Cristales una vez al día.","500 Essence and 5 Crystals once a day."),bestiaryMilestones:T("Hitos del Bestiario","Bestiary milestones"),bestiaryMilestonesHelp:T("Cristales gratis al llegar a 3, 6, 12, 18, 24, 30 y 36 formas selladas.","Free crystals at 3, 6, 12, 18, 24, 30 and 36 sealed forms."),noAdsHere:T("Los anuncios con premio no están disponibles en esta plataforma.","Reward ads are not available on this platform."),adUnavailable:T("No hay anuncio disponible ahora. Inténtalo más tarde.","No ad available right now. Try again later."),rule1:T("Sin compras al azar","No random purchases"),rule2:T("Ves el precio antes de comprar","You see the price before buying"),rule3:T("Toda compra pide confirmación","Every purchase asks for confirmation"),rule4:T("Nada de esto da poder: solo apariencia","Nothing here gives power: looks only"),confirmBuy:T("Confirmar compra","Confirm purchase"),confirmBuyBody:T("¿Quieres comprar «{name}»?","Do you want to buy “{name}”?"),buy:T("Comprar","Buy"),notEnoughCrystals:T("Faltan cristales","Not enough crystals"),needCrystals:T("Te faltan {n} Cristales Arcanos.","You need {n} more Arcane Crystals."),purchased:T("¡{name} es tuyo!","{name} is yours!"),purchaseDone:T("Compra completada: {name}. ¡Gracias por apoyar el juego!","Purchase complete: {name}. Thanks for supporting the game!"),paymentsOff:T("Los pagos no están disponibles en esta plataforma.","Payments are not available on this platform."),paymentError:T("No se pudo abrir el pago. Inténtalo de nuevo.","Could not open checkout. Please try again."),tint:T("Tinte","Tint"),seal:T("Sello","Seal"),effect:T("Efecto","Effect"),free:T("Gratis","Free"),premium:T("Premium","Premium"),passLevel:T("Nivel {n} de {m}","Tier {n} of {m}"),passHelp:T("Ganas XP de pase en cada expedición, al sellar y con los contratos.","Earn pass XP from every expedition, every seal and contracts."),premiumActive:T("Pista premium activa","Premium track active"),unlockPremium:T("Desbloquear premium","Unlock premium"),passPremium:T("Pase Arcano Premium","Arcane Pass Premium")};let fs="es";function _u(i){return i==="es"||i==="en"?i:(navigator.language||"en").toLowerCase().startsWith("es")?"es":"en"}function bl(i){fs=i==="en"?"en":"es",document.documentElement.lang=fs}function hi(){return fs}function x(i,e){const t=vu[i];let n=t?t[fs]??t.es:i;if(e)for(const s in e)n=n.split(`{${s}}`).join(e[s]);return n}function re(i){return i?i[fs]??i.es??"":""}function At(i){return Math.round(i).toLocaleString(fs==="es"?"es-ES":"en-US")}let ke=null,wi,en,Ri,Rr,Is,fa,Vd=.6,$d=.8,Wd=!1,ai=null,oc=0,ar=0,is=0;const Pi=i=>440*Math.pow(2,(i-69)/12),lc=[[50,53,57],[46,50,53],[43,46,50],[45,49,52]],Pr=[62,64,65,67,69,70,72,74,76,77,79,81,82,84],cc={vacio:[0,3,2,5],fuego:[4,6,7,9],abismo:[0,2,4,1],rayo:[7,9,11,7],infierno:[0,1,3,0],veneno:[2,5,4,6],hielo:[9,7,11,13],tierra:[0,4,3,1],cosmos:[5,9,7,12],sombra:[3,1,2,0],luz:[7,9,12,11],cristal:[11,9,13,12]};function xu(i,e){const t=ke.sampleRate,n=Math.floor(t*i),s=ke.createBuffer(2,n,t);for(let a=0;a<2;a++){const r=s.getChannelData(a);for(let o=0;o<n;o++)r[o]=(Math.random()*2-1)*Math.pow(1-o/n,e)}return s}let pa=null;function yu(){if(!pa){pa=ke.createBuffer(1,ke.sampleRate,ke.sampleRate);const e=pa.getChannelData(0);for(let t=0;t<e.length;t++)e[t]=Math.random()*2-1}const i=ke.createBufferSource();return i.buffer=pa,i.loop=!0,i}function Sl(){if(ke){ke.state==="suspended"&&ke.resume();return}const i=window.AudioContext||window.webkitAudioContext;if(!i)return;ke=new i,fa=ke.createDynamicsCompressor(),fa.threshold.value=-14,fa.ratio.value=4,wi=ke.createGain(),wi.gain.value=Wd?0:1,wi.connect(fa).connect(ke.destination),Rr=ke.createConvolver(),Rr.buffer=xu(3.2,2.6),Is=ke.createGain(),Is.gain.value=.55,Is.connect(Rr).connect(wi),en=ke.createGain(),en.gain.value=Vd*.5,en.connect(wi),en.connect(Is),Ri=ke.createGain(),Ri.gain.value=$d,Ri.connect(wi);const e=ke.createGain();e.gain.value=.25,Ri.connect(e).connect(Is),ai&&Yd()}function Xd(i,e){Vd=i,$d=e,ke&&(en.gain.setTargetAtTime(i*.5,ke.currentTime,.1),Ri.gain.setTargetAtTime(e,ke.currentTime,.1))}function dc(i){Wd=i,ke&&wi.gain.setTargetAtTime(i?0:1,ke.currentTime,.05)}function qd(i,e,t,n,s,a,r,o){i.gain.setValueAtTime(1e-4,e),i.gain.exponentialRampToValueAtTime(Math.max(n,2e-4),e+t),i.gain.exponentialRampToValueAtTime(1e-4,o+r)}function Mt({f:i,f2:e,type:t="sine",t:n=0,a:s=.005,dur:a=.2,r=.2,peak:o=.3,bus:l,detune:c=0,lp:h,q:d=1}){if(!ke)return;const u=ke.currentTime+n,m=ke.createOscillator();m.type=t,m.frequency.setValueAtTime(i,u),e&&m.frequency.exponentialRampToValueAtTime(e,u+a),m.detune.value=c;const g=ke.createGain();qd(g,u,s,o,0,void 0,r,u+a);let v=m;if(h){const f=ke.createBiquadFilter();f.type="lowpass",f.frequency.value=h,f.Q.value=d,m.connect(f),v=f}v.connect(g).connect(l||Ri),m.start(u),m.stop(u+a+r+.05)}function Qt({t:i=0,dur:e=.2,peak:t=.3,type:n="bandpass",f:s=1200,f2:a,q:r=1,a:o=.005,bus:l}){if(!ke)return;const c=ke.currentTime+i,h=yu(),d=ke.createBiquadFilter();d.type=n,d.frequency.setValueAtTime(s,c),a&&d.frequency.exponentialRampToValueAtTime(a,c+e),d.Q.value=r;const u=ke.createGain();qd(u,c,o,t,0,void 0,e*.6,c+e*.4),h.connect(d).connect(u).connect(l||Ri),h.start(c,Math.random()*.5),h.stop(c+e+.1)}function Xt(i,e=0,t=.12,n){const s=Pi(i);Mt({f:s,t:e,a:.003,dur:.05,r:1.6,peak:t,bus:n}),Mt({f:s*2.01,t:e,a:.003,dur:.03,r:.9,peak:t*.35,bus:n}),Mt({f:s*3.02,t:e,a:.003,dur:.02,r:.5,peak:t*.15,bus:n})}const hc=(i,e)=>i+Math.random()*(e-i),Ee={click(){Xt(88,0,.06)},hover(){Mt({f:2400,dur:.02,r:.05,peak:.015})},back(){Xt(81,0,.05)},error(){Mt({f:140,type:"square",dur:.12,r:.08,peak:.06,lp:900})},hit(i=!1){Qt({f:hc(900,1500),q:.8,dur:i?.18:.1,peak:i?.35:.22}),Mt({f:i?160:220,f2:50,dur:.12,r:.08,peak:i?.4:.22})},crit(){this.hit(!0),Xt(93,.02,.06)},whoosh(){Qt({f:400,f2:2600,q:1.4,dur:.25,peak:.12})},dodge(){Qt({f:1800,f2:500,q:2,dur:.18,peak:.12})},shoot(){Mt({f:hc(700,900),f2:1700,type:"triangle",dur:.08,r:.06,peak:.07})},breath(){Qt({type:"lowpass",f:1600,f2:500,dur:.9,peak:.2,a:.05})},boom(){Qt({type:"lowpass",f:700,f2:120,dur:.7,peak:.45}),Mt({f:90,f2:35,dur:.4,r:.3,peak:.5})},zap(){Qt({type:"highpass",f:2500,dur:.15,peak:.25}),Mt({f:1200,f2:200,type:"sawtooth",dur:.12,r:.05,peak:.08,lp:3e3})},heal(){[74,78,81,86].forEach((i,e)=>Xt(i,e*.07,.07))},shield(){[69,76,81].forEach(i=>Mt({f:Pi(i),type:"triangle",a:.04,dur:.3,r:.6,peak:.05}))},buff(){Mt({f:220,f2:660,type:"sawtooth",a:.05,dur:.4,r:.3,peak:.07,lp:1800})},summon(i){(cc[i]||cc.luz).forEach((t,n)=>Xt(Pr[0]+t,n*.11,.08)),Qt({f:300,f2:3e3,q:1,dur:.5,peak:.08,a:.1})},ult(){Mt({f:110,f2:440,type:"sawtooth",a:.3,dur:.6,r:.6,peak:.12,lp:2200}),Qt({type:"lowpass",f:300,f2:3e3,dur:.8,peak:.2,a:.3}),setTimeout(()=>this.boom(),600)},roar(i=1){Mt({f:95/i,f2:55/i,type:"sawtooth",a:.08,dur:1.1,r:.5,peak:.35,lp:700,q:4}),Mt({f:140/i,f2:70/i,type:"square",a:.1,dur:.9,r:.5,peak:.12,lp:500}),Qt({type:"lowpass",f:900,f2:200,dur:1.2,peak:.25,a:.08})},faint(){Mt({f:330,f2:80,type:"triangle",dur:.8,r:.4,peak:.15})},sealNode(i){Xt(Pr[Math.min(i,Pr.length-1)],0,.12)},sealPerfect(){[74,78,81,86,90].forEach(i=>Xt(i,0,.09)),[62,66,69].forEach(i=>Mt({f:Pi(i),type:"triangle",a:.05,dur:1,r:1.5,peak:.06}))},sealOk(){[74,77,81].forEach((i,e)=>Xt(i,e*.08,.09))},sealFail(){Mt({f:Pi(62),f2:Pi(55),type:"triangle",dur:.5,r:.4,peak:.15}),Qt({f:500,dur:.4,peak:.1})},levelUp(){[69,73,76,81,85].forEach((i,e)=>Xt(i,e*.06,.08))},coin(){Xt(91,0,.06),Xt(96,.07,.05)},warn(){Mt({f:440,type:"square",dur:.06,r:.04,peak:.03,lp:1500})},phase(){this.roar(1.3),Mt({f:55,dur:1.2,r:1,peak:.4})},break(){Qt({type:"highpass",f:1500,dur:.4,peak:.3}),[86,83,79].forEach((i,e)=>Xt(i,e*.05,.08))}};function Mu(i,e,t,n){for(const s of i){const a=Pi(s);for(const r of[-9,0,8])Mt({f:a,type:"sawtooth",t:e,a:t*.35,dur:t*.6,r:t*.6,peak:n/3,bus:en,detune:r,lp:700+Math.random()*300,q:.6});Mt({f:a*2,type:"sine",t:e,a:t*.4,dur:t*.5,r:t*.6,peak:n*.25,bus:en})}}function bu(){const i=ai==="combat"||ai==="boss",e=ai==="boss"?.4:i?.48:.75,t=8,n=lc[Math.floor(is/t)%lc.length],s=ar-ke.currentTime;if(is%t===0&&Mu(n,s,e*t,i?.1:.14),i){const r=n[0]-12;Mt({f:Pi(r),type:"triangle",t:s,a:.01,dur:e*.4,r:.1,peak:.16,bus:en,lp:400}),is%2===0?Mt({f:120,f2:42,t:s,dur:.18,r:.08,peak:ai==="boss"?.5:.35,bus:en}):Qt({type:"highpass",f:7e3,t:s,dur:.05,peak:.05,bus:en}),is%4===2&&Qt({type:"bandpass",f:1800,q:.7,t:s,dur:.12,peak:.08,bus:en}),Math.random()<.35&&Xt(n[Math.floor(Math.random()*3)]+24,s+e/2,.035,en)}else Math.random()<.55&&Xt(n[Math.floor(Math.random()*3)]+24+(Math.random()<.3?12:0),s+Math.random()*e,.045,en);ar+=e,is++}function Yd(){clearInterval(oc),!(!ke||!ai)&&(ar=ke.currentTime+.1,oc=setInterval(()=>{if(!(!ke||ke.state!=="running"))for(;ar<ke.currentTime+.25;)bu()},60))}function rr(i){ai!==i&&(ai=i,is=0,ke&&Yd())}function Su(){ke&&ke.state==="running"&&ke.suspend()}function wu(){ke&&ke.state==="suspended"&&ke.resume()}const rn=(i,e,t,n,s,a,r,o,l)=>({id:i,name:{es:e,en:t},desc:{es:n,en:s},levels:a,boss:r,pool:o,props:l}),It=[rn("arboleda","Arboleda Astral","Astral Grove","Bosque nocturno con flores que brillan.","A night forest with glowing flowers.",[1,8],"ciervo",["ciervo","golem"],"flores"),rn("cantera","Cantera Rúnica","Runic Quarry","Ruinas con runas que abren atajos.","Ruins whose runes open shortcuts.",[6,14],"golem",["golem","tortuga","ciervo"],"pilares"),rn("pantano","Pantano Esmeralda","Emerald Marsh","Niebla tóxica y estatuas de aventureros petrificados.","Toxic fog and petrified adventurers.",[12,20],"basilisco",["basilisco","aracna","golem"],"estatuas"),rn("picos","Picos Helados","Frozen Peaks","Suelo resbaladizo y ventiscas que tapan la vista.","Slippery ground and blinding blizzards.",[18,26],"wyvern",["wyvern","grifo","tortuga"],"hielo"),rn("nido","Nido de Tormentas","Storm Nest","Islotes unidos por corrientes de viento.","Islets joined by wind currents.",[22,30],"grifo",["grifo","wyvern","fenix"],"rocas"),rn("desierto","Desierto de Cristal","Crystal Desert","Dunas que se mueven y cristales que reflejan ataques.","Shifting dunes and mirror crystals.",[26,34],"tortuga",["tortuga","basilisco","cerbero"],"cristales"),rn("forja","Forja Solar","Solar Forge","Volcán con ríos de luz y plataformas que arden.","A volcano with rivers of light.",[30,38],"fenix",["fenix","cerbero","golem"],"lava"),rn("fosa","Fosa Abisal","Abyssal Trench","Medio sumergida: la única luz es la de las criaturas.","Half-sunken: the only light is the creatures’.",[34,42],"kraken",["kraken","leviatan","wyvern"],"corales"),rn("telar","Telar Umbrío","Shadow Loom","Telarañas-sello que hay que cortar para avanzar.","Seal-webs you must cut to advance.",[38,46],"aracna",["aracna","basilisco","hidra"],"telas"),rn("puertas","Puertas del Inframundo","Underworld Gates","Arena de fuego con tres puertas y tres guardianes.","A fire arena with three gates.",[42,50],"cerbero",["cerbero","fenix","aracna"],"lava"),rn("mar","Mar de Estrellas","Sea of Stars","Islas en el cielo; se viaja montado en criaturas.","Islands in the sky, travelled on creatures.",[46,55],"leviatan",["leviatan","grifo","kraken"],"estrellas"),rn("corazon","Corazón del Vacío","Heart of the Void","Incursión final: el suelo se rompe en cada fase.","Final raid: the ground breaks each phase.",[55,60],"hidra",["hidra","aracna","leviatan"],"vacio")],Eu={es:["Lleva tres dominios distintos en tu equipo: así nunca te quedarás sin ventaja.","Abisal vence a Ígneo, Ígneo a Natural, Natural a Arcano y Arcano a Abisal.","Una criatura se puede sellar cuando su vida baja del 25 %.","Un trazo perfecto da +50 % de Esencia y un vínculo inicial alto.","La Tinta Rúnica se recarga sola: 1 cada 10 minutos, hasta 10.","Golpear llena la barra de Sello. Al 100 % libera la Definitiva (F).","Esquiva (Espacio) te vuelve intocable durante un instante.","Cambia de criatura (1 · 2 · 3) para aprovechar la ventaja de dominio.","Los círculos rojos en el suelo avisan de un ataque: sal de ellos.","En la tercera fase, rompe las cuatro anclas rúnicas para poder sellar al Primordial.","Las Crías evolucionan a Adultas en el nivel 20 con 30 Fragmentos de su elemento.","Completa contratos diarios para ganar Esencia y avanzar el Pase Arcano."],en:["Bring three different domains: you will never run out of advantage.","Abyssal beats Igneous, Igneous beats Natural, Natural beats Arcane and Arcane beats Abyssal.","A creature can be sealed once its HP drops below 25%.","A perfect trace grants +50% Essence and a strong starting bond.","Runic Ink refills on its own: 1 every 10 minutes, up to 10.","Hitting fills the Seal bar. At 100% it unleashes the Ultimate (F).","Dodge (Space) makes you untouchable for an instant.","Switch creatures (1 · 2 · 3) to exploit domain advantage.","Red circles on the ground warn of an attack: get out of them.","In the third phase, break the four rune anchors to seal the Primordial.","Hatchlings evolve into Adults at level 20 with 30 Fragments of their element.","Finish daily contracts to earn Essence and progress the Arcane Pass."]},Tu={"#ffd76a":{es:"Oro Astral",en:"Astral Gold"},"#ff3d3d":{es:"Carmesí",en:"Crimson"},"#4fb4ff":{es:"Azur",en:"Azure"},"#b06bff":{es:"Violeta del Vacío",en:"Void Violet"},"#3dff88":{es:"Esmeralda",en:"Emerald"},"#2ff2d6":{es:"Turquesa",en:"Turquoise"},"#ff7a2e":{es:"Ascua",en:"Ember"},"#9fefff":{es:"Escarcha",en:"Frost"},"#ffb23e":{es:"Ámbar",en:"Amber"},"#ff4fd2":{es:"Magenta",en:"Magenta"},"#b4ff4a":{es:"Lima",en:"Lime"},"#7f8cff":{es:"Índigo",en:"Indigo"},"#ffffff":{es:"Nieve",en:"Snow"}},Au={hidra:["#ff3d3d","#2ff2d6","#ff4fd2"],fenix:["#ffd76a","#ff3d3d","#4fb4ff"],kraken:["#4fb4ff","#b06bff","#3dff88"],grifo:["#9fefff","#ffd76a","#b06bff"],cerbero:["#ff7a2e","#b06bff","#3dff88"],basilisco:["#b4ff4a","#2ff2d6","#ff4fd2"],wyvern:["#4fb4ff","#7f8cff","#ffffff"],golem:["#ff3d3d","#2ff2d6","#b06bff"],leviatan:["#b06bff","#2ff2d6","#ffd76a"],aracna:["#b06bff","#ff3d3d","#3dff88"],ciervo:["#9fefff","#ff4fd2","#3dff88"],tortuga:["#2ff2d6","#ffb23e","#ff4fd2"]},Cu=[{id:"hidra_eclipse",creature:"hidra",color:"#ffcf5a",img:"hidra_eclipsedorado",price:400,name:{es:"Eclipse Dorado",en:"Golden Eclipse"}},{id:"cerbero_llamaazul",creature:"cerbero",color:"#3d9bff",img:"cerbero_llamaazul",price:250,name:{es:"Llama Azul",en:"Blue Flame"}},{id:"fenix_jade",creature:"fenix",color:"#5dffb0",img:"fenix_jade",price:250,name:{es:"Fénix de Jade",en:"Jade Phoenix"}},{id:"wyvern_aurora",creature:"wyvern",color:"aurora",img:"wyvern_aurora",price:250,name:{es:"Aurora",en:"Aurora"}}],ps=[];for(const[i,e]of Object.entries(Au))e.forEach(t=>{ps.push({id:`${i}_${t.slice(1)}`,creature:i,color:t,price:150,name:Tu[t]})}),ps.push({id:`${i}_prisma`,creature:i,color:"prisma",price:600,premium:!0,name:{es:"Prisma",en:"Prism"}});for(const i of Cu)ps.push({...i,season:!0});const Xs=Object.fromEntries(ps.map(i=>[i.id,i])),jd=[{id:"propio",price:0,name:{es:"Sello propio",en:"Own seal"},desc:{es:"El círculo original de cada criatura.",en:"Each creature’s original circle."}},{id:"hexagrama",price:150,name:{es:"Hexagrama",en:"Hexagram"},desc:{es:"Seis puntas para todas tus criaturas.",en:"Six points for all your creatures."}},{id:"heptagrama",price:150,name:{es:"Heptagrama",en:"Heptagram"},desc:{es:"Siete puntas para todas tus criaturas.",en:"Seven points for all your creatures."}},{id:"pentagrama",price:150,name:{es:"Pentagrama",en:"Pentagram"},desc:{es:"Cinco puntas para todas tus criaturas.",en:"Five points for all your creatures."}},{id:"corona",price:300,name:{es:"Corona Solar",en:"Solar Crown"},desc:{es:"Rayos que giran como un sol.",en:"Rays that spin like a sun."}},{id:"constelacion",price:300,name:{es:"Constelación",en:"Constellation"},desc:{es:"Estrellas unidas por hilos de luz.",en:"Stars joined by threads of light."}},{id:"eclipse",price:450,season:!0,name:{es:"Sello del Eclipse",en:"Eclipse Seal"},desc:{es:"Exclusivo de la temporada Eclipse.",en:"Eclipse season exclusive."}}],Ru=Object.fromEntries(jd.map(i=>[i.id,i])),Kd=[{id:"anillo",price:0,name:{es:"Anillo rúnico",en:"Rune ring"}},{id:"estrellas",price:200,name:{es:"Lluvia de estrellas",en:"Starfall"}},{id:"pilar",price:200,name:{es:"Pilar de luz",en:"Pillar of light"}},{id:"espiral",price:250,name:{es:"Espiral arcana",en:"Arcane spiral"}}],Pu=Object.fromEntries(Kd.map(i=>[i.id,i])),Zd=[{sku:"fundador",usd:2.99,once:!0,best:!0,name:{es:"Pack del Fundador",en:"Founder Pack"},desc:{es:"600 Cristales + tinte Prisma para tu inicial + Corona Solar + Lluvia de estrellas",en:"600 Crystals + Prism tint for your starter + Solar Crown + Starfall"},grant:{crystals:600,starterPrism:!0,seals:["corona"],effects:["estrellas"]}},{sku:"cristales_120",usd:.99,name:{es:"120 Cristales",en:"120 Crystals"},grant:{crystals:120}},{sku:"cristales_650",usd:4.99,tag:"popular",name:{es:"650 Cristales",en:"650 Crystals"},grant:{crystals:650}},{sku:"cristales_1400",usd:9.99,tag:"bonus",name:{es:"1400 Cristales",en:"1400 Crystals"},grant:{crystals:1400}},{sku:"cristales_3000",usd:19.99,tag:"value",name:{es:"3000 Cristales",en:"3000 Crystals"},grant:{crystals:3e3}},{sku:"pase_premium",usd:4.99,once:!0,name:{es:"Pase Arcano Premium",en:"Arcane Pass Premium"},desc:{es:"Desbloquea la pista premium de la temporada Eclipse",en:"Unlocks the Eclipse season premium track"},grant:{passPremium:!0}},{sku:"sin_anuncios",usd:3.99,once:!0,standaloneOnly:!0,name:{es:"Sin anuncios",en:"No ads"},desc:{es:"Quita los anuncios entre partidas. Los anuncios opcionales con premio siguen disponibles.",en:"Removes ads between runs. Optional reward ads stay available."},grant:{noAds:!0}}],xo=Object.fromEntries(Zd.map(i=>[i.sku,i])),ma=800,Ui=Array.from({length:30},(i,e)=>{const t=e+1,n=t%5===0?{crystals:15}:t%3===0?{ink:2}:{essence:150+t*20};let s;return t===30?s={seal:"eclipse"}:t===25?s={effect:"espiral"}:t===20?s={tint:"hidra_eclipse"}:t===15?s={effect:"pilar"}:t===10?s={tint:"wyvern_aurora"}:t===5?s={seal:"constelacion"}:t%2===0?s={crystals:40}:s={essence:400+t*30,ink:1},{n:t,free:n,prem:s}}),wl=100,Lu=[{essence:200},{ink:2},{essence:300,fragments:5},{essence:400,ink:3},{crystals:10},{essence:600},{crystals:30,ink:5}];/**
 * @license
 * Copyright 2010-2024 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const El="170",Du=0,uc=1,Iu=2,Jd=1,Uu=2,On=3,Yn=0,jt=1,Yt=2,$n=0,os=1,Vt=2,fc=3,pc=4,Nu=5,Ai=100,Fu=101,ku=102,Ou=103,Bu=104,zu=200,Hu=201,Gu=202,Vu=203,yo=204,Mo=205,$u=206,Wu=207,Xu=208,qu=209,Yu=210,ju=211,Ku=212,Zu=213,Ju=214,bo=0,So=1,wo=2,ms=3,Eo=4,To=5,Ao=6,Co=7,Qd=0,Qu=1,ef=2,oi=0,eh=1,th=2,nh=3,Tl=4,tf=5,ih=6,sh=7,ah=300,gs=301,vs=302,Ro=303,Po=304,vr=306,Lo=1e3,Li=1001,Do=1002,_n=1003,nf=1004,ga=1005,Tn=1006,Lr=1007,Di=1008,jn=1009,rh=1010,oh=1011,Js=1012,Al=1013,Fi=1014,Gn=1015,Wn=1016,Cl=1017,Rl=1018,_s=1020,lh=35902,ch=1021,dh=1022,vn=1023,hh=1024,uh=1025,ls=1026,xs=1027,fh=1028,Pl=1029,ph=1030,Ll=1031,Dl=1033,ja=33776,Ka=33777,Za=33778,Ja=33779,Io=35840,Uo=35841,No=35842,Fo=35843,ko=36196,Oo=37492,Bo=37496,zo=37808,Ho=37809,Go=37810,Vo=37811,$o=37812,Wo=37813,Xo=37814,qo=37815,Yo=37816,jo=37817,Ko=37818,Zo=37819,Jo=37820,Qo=37821,Qa=36492,el=36494,tl=36495,mh=36283,nl=36284,il=36285,sl=36286,sf=3200,af=3201,gh=0,rf=1,si="",Gt="srgb",ws="srgb-linear",_r="linear",ot="srgb",Oi=7680,mc=519,of=512,lf=513,cf=514,vh=515,df=516,hf=517,uf=518,ff=519,al=35044,Dr=35048,gc="300 es",Vn=2e3,or=2001;class Es{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;const n=this._listeners;return n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;const s=this._listeners[e];if(s!==void 0){const a=s.indexOf(t);a!==-1&&s.splice(a,1)}}dispatchEvent(e){if(this._listeners===void 0)return;const n=this._listeners[e.type];if(n!==void 0){e.target=this;const s=n.slice(0);for(let a=0,r=s.length;a<r;a++)s[a].call(this,e);e.target=null}}}const Nt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let vc=1234567;const qs=Math.PI/180,Qs=180/Math.PI;function Xn(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Nt[i&255]+Nt[i>>8&255]+Nt[i>>16&255]+Nt[i>>24&255]+"-"+Nt[e&255]+Nt[e>>8&255]+"-"+Nt[e>>16&15|64]+Nt[e>>24&255]+"-"+Nt[t&63|128]+Nt[t>>8&255]+"-"+Nt[t>>16&255]+Nt[t>>24&255]+Nt[n&255]+Nt[n>>8&255]+Nt[n>>16&255]+Nt[n>>24&255]).toLowerCase()}function $t(i,e,t){return Math.max(e,Math.min(t,i))}function Il(i,e){return(i%e+e)%e}function pf(i,e,t,n,s){return n+(i-e)*(s-n)/(t-e)}function mf(i,e,t){return i!==e?(t-i)/(e-i):0}function Ys(i,e,t){return(1-t)*i+t*e}function gf(i,e,t,n){return Ys(i,e,1-Math.exp(-t*n))}function vf(i,e=1){return e-Math.abs(Il(i,e*2)-e)}function _f(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function xf(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function yf(i,e){return i+Math.floor(Math.random()*(e-i+1))}function Mf(i,e){return i+Math.random()*(e-i)}function bf(i){return i*(.5-Math.random())}function Sf(i){i!==void 0&&(vc=i);let e=vc+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function wf(i){return i*qs}function Ef(i){return i*Qs}function Tf(i){return(i&i-1)===0&&i!==0}function Af(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Cf(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Rf(i,e,t,n,s){const a=Math.cos,r=Math.sin,o=a(t/2),l=r(t/2),c=a((e+n)/2),h=r((e+n)/2),d=a((e-n)/2),u=r((e-n)/2),m=a((n-e)/2),g=r((n-e)/2);switch(s){case"XYX":i.set(o*h,l*d,l*u,o*c);break;case"YZY":i.set(l*u,o*h,l*d,o*c);break;case"ZXZ":i.set(l*d,l*u,o*h,o*c);break;case"XZX":i.set(o*h,l*g,l*m,o*c);break;case"YXY":i.set(l*m,o*h,l*g,o*c);break;case"ZYZ":i.set(l*g,l*m,o*h,o*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function mn(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function lt(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}const ea={DEG2RAD:qs,RAD2DEG:Qs,generateUUID:Xn,clamp:$t,euclideanModulo:Il,mapLinear:pf,inverseLerp:mf,lerp:Ys,damp:gf,pingpong:vf,smoothstep:_f,smootherstep:xf,randInt:yf,randFloat:Mf,randFloatSpread:bf,seededRandom:Sf,degToRad:wf,radToDeg:Ef,isPowerOfTwo:Tf,ceilPowerOfTwo:Af,floorPowerOfTwo:Cf,setQuaternionFromProperEuler:Rf,normalize:lt,denormalize:mn};class Pe{constructor(e=0,t=0){Pe.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos($t(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),s=Math.sin(t),a=this.x-e.x,r=this.y-e.y;return this.x=a*n-r*s+e.x,this.y=a*s+r*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class We{constructor(e,t,n,s,a,r,o,l,c){We.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,a,r,o,l,c)}set(e,t,n,s,a,r,o,l,c){const h=this.elements;return h[0]=e,h[1]=s,h[2]=o,h[3]=t,h[4]=a,h[5]=l,h[6]=n,h[7]=r,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,a=this.elements,r=n[0],o=n[3],l=n[6],c=n[1],h=n[4],d=n[7],u=n[2],m=n[5],g=n[8],v=s[0],f=s[3],p=s[6],E=s[1],w=s[4],b=s[7],O=s[2],P=s[5],L=s[8];return a[0]=r*v+o*E+l*O,a[3]=r*f+o*w+l*P,a[6]=r*p+o*b+l*L,a[1]=c*v+h*E+d*O,a[4]=c*f+h*w+d*P,a[7]=c*p+h*b+d*L,a[2]=u*v+m*E+g*O,a[5]=u*f+m*w+g*P,a[8]=u*p+m*b+g*L,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],s=e[2],a=e[3],r=e[4],o=e[5],l=e[6],c=e[7],h=e[8];return t*r*h-t*o*c-n*a*h+n*o*l+s*a*c-s*r*l}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],a=e[3],r=e[4],o=e[5],l=e[6],c=e[7],h=e[8],d=h*r-o*c,u=o*l-h*a,m=c*a-r*l,g=t*d+n*u+s*m;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/g;return e[0]=d*v,e[1]=(s*c-h*n)*v,e[2]=(o*n-s*r)*v,e[3]=u*v,e[4]=(h*t-s*l)*v,e[5]=(s*a-o*t)*v,e[6]=m*v,e[7]=(n*l-c*t)*v,e[8]=(r*t-n*a)*v,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,a,r,o){const l=Math.cos(a),c=Math.sin(a);return this.set(n*l,n*c,-n*(l*r+c*o)+r+e,-s*c,s*l,-s*(-c*r+l*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(Ir.makeScale(e,t)),this}rotate(e){return this.premultiply(Ir.makeRotation(-e)),this}translate(e,t){return this.premultiply(Ir.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Ir=new We;function _h(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function ta(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Pf(){const i=ta("canvas");return i.style.display="block",i}const _c={};function $s(i){i in _c||(_c[i]=!0,console.warn(i))}function Lf(i,e,t){return new Promise(function(n,s){function a(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(a,t);break;default:n()}}setTimeout(a,t)})}function Df(i){const e=i.elements;e[2]=.5*e[2]+.5*e[3],e[6]=.5*e[6]+.5*e[7],e[10]=.5*e[10]+.5*e[11],e[14]=.5*e[14]+.5*e[15]}function If(i){const e=i.elements;e[11]===-1?(e[10]=-e[10]-1,e[14]=-e[14]):(e[10]=-e[10],e[14]=-e[14]+1)}const Qe={enabled:!0,workingColorSpace:ws,spaces:{},convert:function(i,e,t){return this.enabled===!1||e===t||!e||!t||(this.spaces[e].transfer===ot&&(i.r=qn(i.r),i.g=qn(i.g),i.b=qn(i.b)),this.spaces[e].primaries!==this.spaces[t].primaries&&(i.applyMatrix3(this.spaces[e].toXYZ),i.applyMatrix3(this.spaces[t].fromXYZ)),this.spaces[t].transfer===ot&&(i.r=cs(i.r),i.g=cs(i.g),i.b=cs(i.b))),i},fromWorkingColorSpace:function(i,e){return this.convert(i,this.workingColorSpace,e)},toWorkingColorSpace:function(i,e){return this.convert(i,e,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===si?_r:this.spaces[i].transfer},getLuminanceCoefficients:function(i,e=this.workingColorSpace){return i.fromArray(this.spaces[e].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,e,t){return i.copy(this.spaces[e].toXYZ).multiply(this.spaces[t].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace}};function qn(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function cs(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}const xc=[.64,.33,.3,.6,.15,.06],yc=[.2126,.7152,.0722],Mc=[.3127,.329],bc=new We().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Sc=new We().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);Qe.define({[ws]:{primaries:xc,whitePoint:Mc,transfer:_r,toXYZ:bc,fromXYZ:Sc,luminanceCoefficients:yc,workingColorSpaceConfig:{unpackColorSpace:Gt},outputColorSpaceConfig:{drawingBufferColorSpace:Gt}},[Gt]:{primaries:xc,whitePoint:Mc,transfer:ot,toXYZ:bc,fromXYZ:Sc,luminanceCoefficients:yc,outputColorSpaceConfig:{drawingBufferColorSpace:Gt}}});let Bi;class Uf{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{Bi===void 0&&(Bi=ta("canvas")),Bi.width=e.width,Bi.height=e.height;const n=Bi.getContext("2d");e instanceof ImageData?n.putImageData(e,0,0):n.drawImage(e,0,0,e.width,e.height),t=Bi}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=ta("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const s=n.getImageData(0,0,e.width,e.height),a=s.data;for(let r=0;r<a.length;r++)a[r]=qn(a[r]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(qn(t[n]/255)*255):t[n]=qn(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Nf=0;class xh{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Nf++}),this.uuid=Xn(),this.data=e,this.dataReady=!0,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let a;if(Array.isArray(s)){a=[];for(let r=0,o=s.length;r<o;r++)s[r].isDataTexture?a.push(Ur(s[r].image)):a.push(Ur(s[r]))}else a=Ur(s);n.url=a}return t||(e.images[this.uuid]=n),n}}function Ur(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?Uf.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Ff=0;class Bt extends Es{constructor(e=Bt.DEFAULT_IMAGE,t=Bt.DEFAULT_MAPPING,n=Li,s=Li,a=Tn,r=Di,o=vn,l=jn,c=Bt.DEFAULT_ANISOTROPY,h=si){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Ff++}),this.uuid=Xn(),this.name="",this.source=new xh(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=a,this.minFilter=r,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Pe(0,0),this.repeat=new Pe(1,1),this.center=new Pe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new We,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==ah)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Lo:e.x=e.x-Math.floor(e.x);break;case Li:e.x=e.x<0?0:1;break;case Do:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Lo:e.y=e.y-Math.floor(e.y);break;case Li:e.y=e.y<0?0:1;break;case Do:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Bt.DEFAULT_IMAGE=null;Bt.DEFAULT_MAPPING=ah;Bt.DEFAULT_ANISOTROPY=1;class dt{constructor(e=0,t=0,n=0,s=1){dt.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,a=this.w,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s+r[12]*a,this.y=r[1]*t+r[5]*n+r[9]*s+r[13]*a,this.z=r[2]*t+r[6]*n+r[10]*s+r[14]*a,this.w=r[3]*t+r[7]*n+r[11]*s+r[15]*a,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,a;const l=e.elements,c=l[0],h=l[4],d=l[8],u=l[1],m=l[5],g=l[9],v=l[2],f=l[6],p=l[10];if(Math.abs(h-u)<.01&&Math.abs(d-v)<.01&&Math.abs(g-f)<.01){if(Math.abs(h+u)<.1&&Math.abs(d+v)<.1&&Math.abs(g+f)<.1&&Math.abs(c+m+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const w=(c+1)/2,b=(m+1)/2,O=(p+1)/2,P=(h+u)/4,L=(d+v)/4,I=(g+f)/4;return w>b&&w>O?w<.01?(n=0,s=.707106781,a=.707106781):(n=Math.sqrt(w),s=P/n,a=L/n):b>O?b<.01?(n=.707106781,s=0,a=.707106781):(s=Math.sqrt(b),n=P/s,a=I/s):O<.01?(n=.707106781,s=.707106781,a=0):(a=Math.sqrt(O),n=L/a,s=I/a),this.set(n,s,a,t),this}let E=Math.sqrt((f-g)*(f-g)+(d-v)*(d-v)+(u-h)*(u-h));return Math.abs(E)<.001&&(E=1),this.x=(f-g)/E,this.y=(d-v)/E,this.z=(u-h)/E,this.w=Math.acos((c+m+p-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class kf extends Es{constructor(e=1,t=1,n={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new dt(0,0,e,t),this.scissorTest=!1,this.viewport=new dt(0,0,e,t);const s={width:e,height:t,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Tn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);const a=new Bt(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);a.flipY=!1,a.generateMipmaps=n.generateMipmaps,a.internalFormat=n.internalFormat,this.textures=[];const r=n.count;for(let o=0;o<r;o++)this.textures[o]=a.clone(),this.textures[o].isRenderTargetTexture=!0;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let s=0,a=this.textures.length;s<a;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=n;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let n=0,s=e.textures.length;n<s;n++)this.textures[n]=e.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0;const t=Object.assign({},e.texture.image);return this.texture.source=new xh(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class xn extends kf{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class yh extends Bt{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=_n,this.minFilter=_n,this.wrapR=Li,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Of extends Bt{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=_n,this.minFilter=_n,this.wrapR=Li,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class aa{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,a,r,o){let l=n[s+0],c=n[s+1],h=n[s+2],d=n[s+3];const u=a[r+0],m=a[r+1],g=a[r+2],v=a[r+3];if(o===0){e[t+0]=l,e[t+1]=c,e[t+2]=h,e[t+3]=d;return}if(o===1){e[t+0]=u,e[t+1]=m,e[t+2]=g,e[t+3]=v;return}if(d!==v||l!==u||c!==m||h!==g){let f=1-o;const p=l*u+c*m+h*g+d*v,E=p>=0?1:-1,w=1-p*p;if(w>Number.EPSILON){const O=Math.sqrt(w),P=Math.atan2(O,p*E);f=Math.sin(f*P)/O,o=Math.sin(o*P)/O}const b=o*E;if(l=l*f+u*b,c=c*f+m*b,h=h*f+g*b,d=d*f+v*b,f===1-o){const O=1/Math.sqrt(l*l+c*c+h*h+d*d);l*=O,c*=O,h*=O,d*=O}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=d}static multiplyQuaternionsFlat(e,t,n,s,a,r){const o=n[s],l=n[s+1],c=n[s+2],h=n[s+3],d=a[r],u=a[r+1],m=a[r+2],g=a[r+3];return e[t]=o*g+h*d+l*m-c*u,e[t+1]=l*g+h*u+c*d-o*m,e[t+2]=c*g+h*m+o*u-l*d,e[t+3]=h*g-o*d-l*u-c*m,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,s=e._y,a=e._z,r=e._order,o=Math.cos,l=Math.sin,c=o(n/2),h=o(s/2),d=o(a/2),u=l(n/2),m=l(s/2),g=l(a/2);switch(r){case"XYZ":this._x=u*h*d+c*m*g,this._y=c*m*d-u*h*g,this._z=c*h*g+u*m*d,this._w=c*h*d-u*m*g;break;case"YXZ":this._x=u*h*d+c*m*g,this._y=c*m*d-u*h*g,this._z=c*h*g-u*m*d,this._w=c*h*d+u*m*g;break;case"ZXY":this._x=u*h*d-c*m*g,this._y=c*m*d+u*h*g,this._z=c*h*g+u*m*d,this._w=c*h*d-u*m*g;break;case"ZYX":this._x=u*h*d-c*m*g,this._y=c*m*d+u*h*g,this._z=c*h*g-u*m*d,this._w=c*h*d+u*m*g;break;case"YZX":this._x=u*h*d+c*m*g,this._y=c*m*d+u*h*g,this._z=c*h*g-u*m*d,this._w=c*h*d-u*m*g;break;case"XZY":this._x=u*h*d-c*m*g,this._y=c*m*d-u*h*g,this._z=c*h*g+u*m*d,this._w=c*h*d+u*m*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+r)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],s=t[4],a=t[8],r=t[1],o=t[5],l=t[9],c=t[2],h=t[6],d=t[10],u=n+o+d;if(u>0){const m=.5/Math.sqrt(u+1);this._w=.25/m,this._x=(h-l)*m,this._y=(a-c)*m,this._z=(r-s)*m}else if(n>o&&n>d){const m=2*Math.sqrt(1+n-o-d);this._w=(h-l)/m,this._x=.25*m,this._y=(s+r)/m,this._z=(a+c)/m}else if(o>d){const m=2*Math.sqrt(1+o-n-d);this._w=(a-c)/m,this._x=(s+r)/m,this._y=.25*m,this._z=(l+h)/m}else{const m=2*Math.sqrt(1+d-n-o);this._w=(r-s)/m,this._x=(a+c)/m,this._y=(l+h)/m,this._z=.25*m}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<Number.EPSILON?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs($t(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,s=e._y,a=e._z,r=e._w,o=t._x,l=t._y,c=t._z,h=t._w;return this._x=n*h+r*o+s*c-a*l,this._y=s*h+r*l+a*o-n*c,this._z=a*h+r*c+n*l-s*o,this._w=r*h-n*o-s*l-a*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const n=this._x,s=this._y,a=this._z,r=this._w;let o=r*e._w+n*e._x+s*e._y+a*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=r,this._x=n,this._y=s,this._z=a,this;const l=1-o*o;if(l<=Number.EPSILON){const m=1-t;return this._w=m*r+t*this._w,this._x=m*n+t*this._x,this._y=m*s+t*this._y,this._z=m*a+t*this._z,this.normalize(),this}const c=Math.sqrt(l),h=Math.atan2(c,o),d=Math.sin((1-t)*h)/c,u=Math.sin(t*h)/c;return this._w=r*d+this._w*u,this._x=n*d+this._x*u,this._y=s*d+this._y*u,this._z=a*d+this._z*u,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),a=Math.sqrt(n);return this.set(s*Math.sin(e),s*Math.cos(e),a*Math.sin(t),a*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class R{constructor(e=0,t=0,n=0){R.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(wc.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(wc.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,s=this.z,a=e.elements;return this.x=a[0]*t+a[3]*n+a[6]*s,this.y=a[1]*t+a[4]*n+a[7]*s,this.z=a[2]*t+a[5]*n+a[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,a=e.elements,r=1/(a[3]*t+a[7]*n+a[11]*s+a[15]);return this.x=(a[0]*t+a[4]*n+a[8]*s+a[12])*r,this.y=(a[1]*t+a[5]*n+a[9]*s+a[13])*r,this.z=(a[2]*t+a[6]*n+a[10]*s+a[14])*r,this}applyQuaternion(e){const t=this.x,n=this.y,s=this.z,a=e.x,r=e.y,o=e.z,l=e.w,c=2*(r*s-o*n),h=2*(o*t-a*s),d=2*(a*n-r*t);return this.x=t+l*c+r*d-o*h,this.y=n+l*h+o*c-a*d,this.z=s+l*d+a*h-r*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,s=this.z,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*s,this.y=a[1]*t+a[5]*n+a[9]*s,this.z=a[2]*t+a[6]*n+a[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,s=e.y,a=e.z,r=t.x,o=t.y,l=t.z;return this.x=s*l-a*o,this.y=a*r-n*l,this.z=n*o-s*r,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Nr.copy(this).projectOnVector(e),this.sub(Nr)}reflect(e){return this.sub(Nr.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos($t(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Nr=new R,wc=new aa;class ra{constructor(e=new R(1/0,1/0,1/0),t=new R(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(hn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(hn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=hn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const a=n.getAttribute("position");if(t===!0&&a!==void 0&&e.isInstancedMesh!==!0)for(let r=0,o=a.count;r<o;r++)e.isMesh===!0?e.getVertexPosition(r,hn):hn.fromBufferAttribute(a,r),hn.applyMatrix4(e.matrixWorld),this.expandByPoint(hn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),va.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),va.copy(n.boundingBox)),va.applyMatrix4(e.matrixWorld),this.union(va)}const s=e.children;for(let a=0,r=s.length;a<r;a++)this.expandByObject(s[a],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,hn),hn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Us),_a.subVectors(this.max,Us),zi.subVectors(e.a,Us),Hi.subVectors(e.b,Us),Gi.subVectors(e.c,Us),Jn.subVectors(Hi,zi),Qn.subVectors(Gi,Hi),gi.subVectors(zi,Gi);let t=[0,-Jn.z,Jn.y,0,-Qn.z,Qn.y,0,-gi.z,gi.y,Jn.z,0,-Jn.x,Qn.z,0,-Qn.x,gi.z,0,-gi.x,-Jn.y,Jn.x,0,-Qn.y,Qn.x,0,-gi.y,gi.x,0];return!Fr(t,zi,Hi,Gi,_a)||(t=[1,0,0,0,1,0,0,0,1],!Fr(t,zi,Hi,Gi,_a))?!1:(xa.crossVectors(Jn,Qn),t=[xa.x,xa.y,xa.z],Fr(t,zi,Hi,Gi,_a))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,hn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(hn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Dn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Dn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Dn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Dn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Dn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Dn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Dn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Dn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Dn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const Dn=[new R,new R,new R,new R,new R,new R,new R,new R],hn=new R,va=new ra,zi=new R,Hi=new R,Gi=new R,Jn=new R,Qn=new R,gi=new R,Us=new R,_a=new R,xa=new R,vi=new R;function Fr(i,e,t,n,s){for(let a=0,r=i.length-3;a<=r;a+=3){vi.fromArray(i,a);const o=s.x*Math.abs(vi.x)+s.y*Math.abs(vi.y)+s.z*Math.abs(vi.z),l=e.dot(vi),c=t.dot(vi),h=n.dot(vi);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}const Bf=new ra,Ns=new R,kr=new R;class oa{constructor(e=new R,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):Bf.setFromPoints(e).getCenter(n);let s=0;for(let a=0,r=e.length;a<r;a++)s=Math.max(s,n.distanceToSquared(e[a]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ns.subVectors(e,this.center);const t=Ns.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(Ns,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(kr.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ns.copy(e.center).add(kr)),this.expandByPoint(Ns.copy(e.center).sub(kr))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const In=new R,Or=new R,ya=new R,ei=new R,Br=new R,Ma=new R,zr=new R;class Ul{constructor(e=new R,t=new R(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,In)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=In.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(In.copy(this.origin).addScaledVector(this.direction,t),In.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){Or.copy(e).add(t).multiplyScalar(.5),ya.copy(t).sub(e).normalize(),ei.copy(this.origin).sub(Or);const a=e.distanceTo(t)*.5,r=-this.direction.dot(ya),o=ei.dot(this.direction),l=-ei.dot(ya),c=ei.lengthSq(),h=Math.abs(1-r*r);let d,u,m,g;if(h>0)if(d=r*l-o,u=r*o-l,g=a*h,d>=0)if(u>=-g)if(u<=g){const v=1/h;d*=v,u*=v,m=d*(d+r*u+2*o)+u*(r*d+u+2*l)+c}else u=a,d=Math.max(0,-(r*u+o)),m=-d*d+u*(u+2*l)+c;else u=-a,d=Math.max(0,-(r*u+o)),m=-d*d+u*(u+2*l)+c;else u<=-g?(d=Math.max(0,-(-r*a+o)),u=d>0?-a:Math.min(Math.max(-a,-l),a),m=-d*d+u*(u+2*l)+c):u<=g?(d=0,u=Math.min(Math.max(-a,-l),a),m=u*(u+2*l)+c):(d=Math.max(0,-(r*a+o)),u=d>0?a:Math.min(Math.max(-a,-l),a),m=-d*d+u*(u+2*l)+c);else u=r>0?-a:a,d=Math.max(0,-(r*u+o)),m=-d*d+u*(u+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,d),s&&s.copy(Or).addScaledVector(ya,u),m}intersectSphere(e,t){In.subVectors(e.center,this.origin);const n=In.dot(this.direction),s=In.dot(In)-n*n,a=e.radius*e.radius;if(s>a)return null;const r=Math.sqrt(a-s),o=n-r,l=n+r;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,a,r,o,l;const c=1/this.direction.x,h=1/this.direction.y,d=1/this.direction.z,u=this.origin;return c>=0?(n=(e.min.x-u.x)*c,s=(e.max.x-u.x)*c):(n=(e.max.x-u.x)*c,s=(e.min.x-u.x)*c),h>=0?(a=(e.min.y-u.y)*h,r=(e.max.y-u.y)*h):(a=(e.max.y-u.y)*h,r=(e.min.y-u.y)*h),n>r||a>s||((a>n||isNaN(n))&&(n=a),(r<s||isNaN(s))&&(s=r),d>=0?(o=(e.min.z-u.z)*d,l=(e.max.z-u.z)*d):(o=(e.max.z-u.z)*d,l=(e.min.z-u.z)*d),n>l||o>s)||((o>n||n!==n)&&(n=o),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,In)!==null}intersectTriangle(e,t,n,s,a){Br.subVectors(t,e),Ma.subVectors(n,e),zr.crossVectors(Br,Ma);let r=this.direction.dot(zr),o;if(r>0){if(s)return null;o=1}else if(r<0)o=-1,r=-r;else return null;ei.subVectors(this.origin,e);const l=o*this.direction.dot(Ma.crossVectors(ei,Ma));if(l<0)return null;const c=o*this.direction.dot(Br.cross(ei));if(c<0||l+c>r)return null;const h=-o*ei.dot(zr);return h<0?null:this.at(h/r,a)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class pt{constructor(e,t,n,s,a,r,o,l,c,h,d,u,m,g,v,f){pt.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,a,r,o,l,c,h,d,u,m,g,v,f)}set(e,t,n,s,a,r,o,l,c,h,d,u,m,g,v,f){const p=this.elements;return p[0]=e,p[4]=t,p[8]=n,p[12]=s,p[1]=a,p[5]=r,p[9]=o,p[13]=l,p[2]=c,p[6]=h,p[10]=d,p[14]=u,p[3]=m,p[7]=g,p[11]=v,p[15]=f,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new pt().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,n=e.elements,s=1/Vi.setFromMatrixColumn(e,0).length(),a=1/Vi.setFromMatrixColumn(e,1).length(),r=1/Vi.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*a,t[5]=n[5]*a,t[6]=n[6]*a,t[7]=0,t[8]=n[8]*r,t[9]=n[9]*r,t[10]=n[10]*r,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,s=e.y,a=e.z,r=Math.cos(n),o=Math.sin(n),l=Math.cos(s),c=Math.sin(s),h=Math.cos(a),d=Math.sin(a);if(e.order==="XYZ"){const u=r*h,m=r*d,g=o*h,v=o*d;t[0]=l*h,t[4]=-l*d,t[8]=c,t[1]=m+g*c,t[5]=u-v*c,t[9]=-o*l,t[2]=v-u*c,t[6]=g+m*c,t[10]=r*l}else if(e.order==="YXZ"){const u=l*h,m=l*d,g=c*h,v=c*d;t[0]=u+v*o,t[4]=g*o-m,t[8]=r*c,t[1]=r*d,t[5]=r*h,t[9]=-o,t[2]=m*o-g,t[6]=v+u*o,t[10]=r*l}else if(e.order==="ZXY"){const u=l*h,m=l*d,g=c*h,v=c*d;t[0]=u-v*o,t[4]=-r*d,t[8]=g+m*o,t[1]=m+g*o,t[5]=r*h,t[9]=v-u*o,t[2]=-r*c,t[6]=o,t[10]=r*l}else if(e.order==="ZYX"){const u=r*h,m=r*d,g=o*h,v=o*d;t[0]=l*h,t[4]=g*c-m,t[8]=u*c+v,t[1]=l*d,t[5]=v*c+u,t[9]=m*c-g,t[2]=-c,t[6]=o*l,t[10]=r*l}else if(e.order==="YZX"){const u=r*l,m=r*c,g=o*l,v=o*c;t[0]=l*h,t[4]=v-u*d,t[8]=g*d+m,t[1]=d,t[5]=r*h,t[9]=-o*h,t[2]=-c*h,t[6]=m*d+g,t[10]=u-v*d}else if(e.order==="XZY"){const u=r*l,m=r*c,g=o*l,v=o*c;t[0]=l*h,t[4]=-d,t[8]=c*h,t[1]=u*d+v,t[5]=r*h,t[9]=m*d-g,t[2]=g*d-m,t[6]=o*h,t[10]=v*d+u}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(zf,e,Hf)}lookAt(e,t,n){const s=this.elements;return Zt.subVectors(e,t),Zt.lengthSq()===0&&(Zt.z=1),Zt.normalize(),ti.crossVectors(n,Zt),ti.lengthSq()===0&&(Math.abs(n.z)===1?Zt.x+=1e-4:Zt.z+=1e-4,Zt.normalize(),ti.crossVectors(n,Zt)),ti.normalize(),ba.crossVectors(Zt,ti),s[0]=ti.x,s[4]=ba.x,s[8]=Zt.x,s[1]=ti.y,s[5]=ba.y,s[9]=Zt.y,s[2]=ti.z,s[6]=ba.z,s[10]=Zt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,a=this.elements,r=n[0],o=n[4],l=n[8],c=n[12],h=n[1],d=n[5],u=n[9],m=n[13],g=n[2],v=n[6],f=n[10],p=n[14],E=n[3],w=n[7],b=n[11],O=n[15],P=s[0],L=s[4],I=s[8],S=s[12],y=s[1],D=s[5],V=s[9],z=s[13],X=s[2],J=s[6],q=s[10],ne=s[14],$=s[3],ce=s[7],ee=s[11],ie=s[15];return a[0]=r*P+o*y+l*X+c*$,a[4]=r*L+o*D+l*J+c*ce,a[8]=r*I+o*V+l*q+c*ee,a[12]=r*S+o*z+l*ne+c*ie,a[1]=h*P+d*y+u*X+m*$,a[5]=h*L+d*D+u*J+m*ce,a[9]=h*I+d*V+u*q+m*ee,a[13]=h*S+d*z+u*ne+m*ie,a[2]=g*P+v*y+f*X+p*$,a[6]=g*L+v*D+f*J+p*ce,a[10]=g*I+v*V+f*q+p*ee,a[14]=g*S+v*z+f*ne+p*ie,a[3]=E*P+w*y+b*X+O*$,a[7]=E*L+w*D+b*J+O*ce,a[11]=E*I+w*V+b*q+O*ee,a[15]=E*S+w*z+b*ne+O*ie,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],s=e[8],a=e[12],r=e[1],o=e[5],l=e[9],c=e[13],h=e[2],d=e[6],u=e[10],m=e[14],g=e[3],v=e[7],f=e[11],p=e[15];return g*(+a*l*d-s*c*d-a*o*u+n*c*u+s*o*m-n*l*m)+v*(+t*l*m-t*c*u+a*r*u-s*r*m+s*c*h-a*l*h)+f*(+t*c*d-t*o*m-a*r*d+n*r*m+a*o*h-n*c*h)+p*(-s*o*h-t*l*d+t*o*u+s*r*d-n*r*u+n*l*h)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],a=e[3],r=e[4],o=e[5],l=e[6],c=e[7],h=e[8],d=e[9],u=e[10],m=e[11],g=e[12],v=e[13],f=e[14],p=e[15],E=d*f*c-v*u*c+v*l*m-o*f*m-d*l*p+o*u*p,w=g*u*c-h*f*c-g*l*m+r*f*m+h*l*p-r*u*p,b=h*v*c-g*d*c+g*o*m-r*v*m-h*o*p+r*d*p,O=g*d*l-h*v*l-g*o*u+r*v*u+h*o*f-r*d*f,P=t*E+n*w+s*b+a*O;if(P===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const L=1/P;return e[0]=E*L,e[1]=(v*u*a-d*f*a-v*s*m+n*f*m+d*s*p-n*u*p)*L,e[2]=(o*f*a-v*l*a+v*s*c-n*f*c-o*s*p+n*l*p)*L,e[3]=(d*l*a-o*u*a-d*s*c+n*u*c+o*s*m-n*l*m)*L,e[4]=w*L,e[5]=(h*f*a-g*u*a+g*s*m-t*f*m-h*s*p+t*u*p)*L,e[6]=(g*l*a-r*f*a-g*s*c+t*f*c+r*s*p-t*l*p)*L,e[7]=(r*u*a-h*l*a+h*s*c-t*u*c-r*s*m+t*l*m)*L,e[8]=b*L,e[9]=(g*d*a-h*v*a-g*n*m+t*v*m+h*n*p-t*d*p)*L,e[10]=(r*v*a-g*o*a+g*n*c-t*v*c-r*n*p+t*o*p)*L,e[11]=(h*o*a-r*d*a-h*n*c+t*d*c+r*n*m-t*o*m)*L,e[12]=O*L,e[13]=(h*v*s-g*d*s+g*n*u-t*v*u-h*n*f+t*d*f)*L,e[14]=(g*o*s-r*v*s-g*n*l+t*v*l+r*n*f-t*o*f)*L,e[15]=(r*d*s-h*o*s+h*n*l-t*d*l-r*n*u+t*o*u)*L,this}scale(e){const t=this.elements,n=e.x,s=e.y,a=e.z;return t[0]*=n,t[4]*=s,t[8]*=a,t[1]*=n,t[5]*=s,t[9]*=a,t[2]*=n,t[6]*=s,t[10]*=a,t[3]*=n,t[7]*=s,t[11]*=a,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),s=Math.sin(t),a=1-n,r=e.x,o=e.y,l=e.z,c=a*r,h=a*o;return this.set(c*r+n,c*o-s*l,c*l+s*o,0,c*o+s*l,h*o+n,h*l-s*r,0,c*l-s*o,h*l+s*r,a*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,a,r){return this.set(1,n,a,0,e,1,r,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){const s=this.elements,a=t._x,r=t._y,o=t._z,l=t._w,c=a+a,h=r+r,d=o+o,u=a*c,m=a*h,g=a*d,v=r*h,f=r*d,p=o*d,E=l*c,w=l*h,b=l*d,O=n.x,P=n.y,L=n.z;return s[0]=(1-(v+p))*O,s[1]=(m+b)*O,s[2]=(g-w)*O,s[3]=0,s[4]=(m-b)*P,s[5]=(1-(u+p))*P,s[6]=(f+E)*P,s[7]=0,s[8]=(g+w)*L,s[9]=(f-E)*L,s[10]=(1-(u+v))*L,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){const s=this.elements;let a=Vi.set(s[0],s[1],s[2]).length();const r=Vi.set(s[4],s[5],s[6]).length(),o=Vi.set(s[8],s[9],s[10]).length();this.determinant()<0&&(a=-a),e.x=s[12],e.y=s[13],e.z=s[14],un.copy(this);const c=1/a,h=1/r,d=1/o;return un.elements[0]*=c,un.elements[1]*=c,un.elements[2]*=c,un.elements[4]*=h,un.elements[5]*=h,un.elements[6]*=h,un.elements[8]*=d,un.elements[9]*=d,un.elements[10]*=d,t.setFromRotationMatrix(un),n.x=a,n.y=r,n.z=o,this}makePerspective(e,t,n,s,a,r,o=Vn){const l=this.elements,c=2*a/(t-e),h=2*a/(n-s),d=(t+e)/(t-e),u=(n+s)/(n-s);let m,g;if(o===Vn)m=-(r+a)/(r-a),g=-2*r*a/(r-a);else if(o===or)m=-r/(r-a),g=-r*a/(r-a);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=c,l[4]=0,l[8]=d,l[12]=0,l[1]=0,l[5]=h,l[9]=u,l[13]=0,l[2]=0,l[6]=0,l[10]=m,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,n,s,a,r,o=Vn){const l=this.elements,c=1/(t-e),h=1/(n-s),d=1/(r-a),u=(t+e)*c,m=(n+s)*h;let g,v;if(o===Vn)g=(r+a)*d,v=-2*d;else if(o===or)g=a*d,v=-1*d;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-u,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-m,l[2]=0,l[6]=0,l[10]=v,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const Vi=new R,un=new pt,zf=new R(0,0,0),Hf=new R(1,1,1),ti=new R,ba=new R,Zt=new R,Ec=new pt,Tc=new aa;class Cn{constructor(e=0,t=0,n=0,s=Cn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const s=e.elements,a=s[0],r=s[4],o=s[8],l=s[1],c=s[5],h=s[9],d=s[2],u=s[6],m=s[10];switch(t){case"XYZ":this._y=Math.asin($t(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,m),this._z=Math.atan2(-r,a)):(this._x=Math.atan2(u,c),this._z=0);break;case"YXZ":this._x=Math.asin(-$t(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,m),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-d,a),this._z=0);break;case"ZXY":this._x=Math.asin($t(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-d,m),this._z=Math.atan2(-r,c)):(this._y=0,this._z=Math.atan2(l,a));break;case"ZYX":this._y=Math.asin(-$t(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(u,m),this._z=Math.atan2(l,a)):(this._x=0,this._z=Math.atan2(-r,c));break;case"YZX":this._z=Math.asin($t(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-d,a)):(this._x=0,this._y=Math.atan2(o,m));break;case"XZY":this._z=Math.asin(-$t(r,-1,1)),Math.abs(r)<.9999999?(this._x=Math.atan2(u,c),this._y=Math.atan2(o,a)):(this._x=Math.atan2(-h,m),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Ec.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Ec,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Tc.setFromEuler(this),this.setFromQuaternion(Tc,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Cn.DEFAULT_ORDER="XYZ";class Mh{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Gf=0;const Ac=new R,$i=new aa,Un=new pt,Sa=new R,Fs=new R,Vf=new R,$f=new aa,Cc=new R(1,0,0),Rc=new R(0,1,0),Pc=new R(0,0,1),Lc={type:"added"},Wf={type:"removed"},Wi={type:"childadded",child:null},Hr={type:"childremoved",child:null};class Ct extends Es{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Gf++}),this.uuid=Xn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Ct.DEFAULT_UP.clone();const e=new R,t=new Cn,n=new aa,s=new R(1,1,1);function a(){n.setFromEuler(t,!1)}function r(){t.setFromQuaternion(n,void 0,!1)}t._onChange(a),n._onChange(r),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new pt},normalMatrix:{value:new We}}),this.matrix=new pt,this.matrixWorld=new pt,this.matrixAutoUpdate=Ct.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Ct.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Mh,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return $i.setFromAxisAngle(e,t),this.quaternion.multiply($i),this}rotateOnWorldAxis(e,t){return $i.setFromAxisAngle(e,t),this.quaternion.premultiply($i),this}rotateX(e){return this.rotateOnAxis(Cc,e)}rotateY(e){return this.rotateOnAxis(Rc,e)}rotateZ(e){return this.rotateOnAxis(Pc,e)}translateOnAxis(e,t){return Ac.copy(e).applyQuaternion(this.quaternion),this.position.add(Ac.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Cc,e)}translateY(e){return this.translateOnAxis(Rc,e)}translateZ(e){return this.translateOnAxis(Pc,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Un.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Sa.copy(e):Sa.set(e,t,n);const s=this.parent;this.updateWorldMatrix(!0,!1),Fs.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Un.lookAt(Fs,Sa,this.up):Un.lookAt(Sa,Fs,this.up),this.quaternion.setFromRotationMatrix(Un),s&&(Un.extractRotation(s.matrixWorld),$i.setFromRotationMatrix(Un),this.quaternion.premultiply($i.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Lc),Wi.child=e,this.dispatchEvent(Wi),Wi.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Wf),Hr.child=e,this.dispatchEvent(Hr),Hr.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Un.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Un.multiply(e.parent.matrixWorld)),e.applyMatrix4(Un),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Lc),Wi.child=e,this.dispatchEvent(Wi),Wi.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){const r=this.children[n].getObjectByProperty(e,t);if(r!==void 0)return r}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const s=this.children;for(let a=0,r=s.length;a<r;a++)s[a].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Fs,e,Vf),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Fs,$f,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const s=this.children;for(let a=0,r=s.length;a<r;a++)s[a].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function a(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=a(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){const d=l[c];a(e.shapes,d)}else a(e.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(a(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(a(e.materials,this.material[l]));s.material=o}else s.material=a(e.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];s.animations.push(a(e.animations,l))}}if(t){const o=r(e.geometries),l=r(e.materials),c=r(e.textures),h=r(e.images),d=r(e.shapes),u=r(e.skeletons),m=r(e.animations),g=r(e.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),d.length>0&&(n.shapes=d),u.length>0&&(n.skeletons=u),m.length>0&&(n.animations=m),g.length>0&&(n.nodes=g)}return n.object=s,n;function r(o){const l=[];for(const c in o){const h=o[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const s=e.children[n];this.add(s.clone())}return this}}Ct.DEFAULT_UP=new R(0,1,0);Ct.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ct.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const fn=new R,Nn=new R,Gr=new R,Fn=new R,Xi=new R,qi=new R,Dc=new R,Vr=new R,$r=new R,Wr=new R,Xr=new dt,qr=new dt,Yr=new dt;class ln{constructor(e=new R,t=new R,n=new R){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),fn.subVectors(e,t),s.cross(fn);const a=s.lengthSq();return a>0?s.multiplyScalar(1/Math.sqrt(a)):s.set(0,0,0)}static getBarycoord(e,t,n,s,a){fn.subVectors(s,t),Nn.subVectors(n,t),Gr.subVectors(e,t);const r=fn.dot(fn),o=fn.dot(Nn),l=fn.dot(Gr),c=Nn.dot(Nn),h=Nn.dot(Gr),d=r*c-o*o;if(d===0)return a.set(0,0,0),null;const u=1/d,m=(c*l-o*h)*u,g=(r*h-o*l)*u;return a.set(1-m-g,g,m)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,Fn)===null?!1:Fn.x>=0&&Fn.y>=0&&Fn.x+Fn.y<=1}static getInterpolation(e,t,n,s,a,r,o,l){return this.getBarycoord(e,t,n,s,Fn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(a,Fn.x),l.addScaledVector(r,Fn.y),l.addScaledVector(o,Fn.z),l)}static getInterpolatedAttribute(e,t,n,s,a,r){return Xr.setScalar(0),qr.setScalar(0),Yr.setScalar(0),Xr.fromBufferAttribute(e,t),qr.fromBufferAttribute(e,n),Yr.fromBufferAttribute(e,s),r.setScalar(0),r.addScaledVector(Xr,a.x),r.addScaledVector(qr,a.y),r.addScaledVector(Yr,a.z),r}static isFrontFacing(e,t,n,s){return fn.subVectors(n,t),Nn.subVectors(e,t),fn.cross(Nn).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return fn.subVectors(this.c,this.b),Nn.subVectors(this.a,this.b),fn.cross(Nn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return ln.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return ln.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,s,a){return ln.getInterpolation(e,this.a,this.b,this.c,t,n,s,a)}containsPoint(e){return ln.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return ln.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,s=this.b,a=this.c;let r,o;Xi.subVectors(s,n),qi.subVectors(a,n),Vr.subVectors(e,n);const l=Xi.dot(Vr),c=qi.dot(Vr);if(l<=0&&c<=0)return t.copy(n);$r.subVectors(e,s);const h=Xi.dot($r),d=qi.dot($r);if(h>=0&&d<=h)return t.copy(s);const u=l*d-h*c;if(u<=0&&l>=0&&h<=0)return r=l/(l-h),t.copy(n).addScaledVector(Xi,r);Wr.subVectors(e,a);const m=Xi.dot(Wr),g=qi.dot(Wr);if(g>=0&&m<=g)return t.copy(a);const v=m*c-l*g;if(v<=0&&c>=0&&g<=0)return o=c/(c-g),t.copy(n).addScaledVector(qi,o);const f=h*g-m*d;if(f<=0&&d-h>=0&&m-g>=0)return Dc.subVectors(a,s),o=(d-h)/(d-h+(m-g)),t.copy(s).addScaledVector(Dc,o);const p=1/(f+v+u);return r=v*p,o=u*p,t.copy(n).addScaledVector(Xi,r).addScaledVector(qi,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const bh={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ni={h:0,s:0,l:0},wa={h:0,s:0,l:0};function jr(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class pe{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Gt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Qe.toWorkingColorSpace(this,t),this}setRGB(e,t,n,s=Qe.workingColorSpace){return this.r=e,this.g=t,this.b=n,Qe.toWorkingColorSpace(this,s),this}setHSL(e,t,n,s=Qe.workingColorSpace){if(e=Il(e,1),t=$t(t,0,1),n=$t(n,0,1),t===0)this.r=this.g=this.b=n;else{const a=n<=.5?n*(1+t):n+t-n*t,r=2*n-a;this.r=jr(r,a,e+1/3),this.g=jr(r,a,e),this.b=jr(r,a,e-1/3)}return Qe.toWorkingColorSpace(this,s),this}setStyle(e,t=Gt){function n(a){a!==void 0&&parseFloat(a)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let a;const r=s[1],o=s[2];switch(r){case"rgb":case"rgba":if(a=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(a[4]),this.setRGB(Math.min(255,parseInt(a[1],10))/255,Math.min(255,parseInt(a[2],10))/255,Math.min(255,parseInt(a[3],10))/255,t);if(a=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(a[4]),this.setRGB(Math.min(100,parseInt(a[1],10))/100,Math.min(100,parseInt(a[2],10))/100,Math.min(100,parseInt(a[3],10))/100,t);break;case"hsl":case"hsla":if(a=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(a[4]),this.setHSL(parseFloat(a[1])/360,parseFloat(a[2])/100,parseFloat(a[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const a=s[1],r=a.length;if(r===3)return this.setRGB(parseInt(a.charAt(0),16)/15,parseInt(a.charAt(1),16)/15,parseInt(a.charAt(2),16)/15,t);if(r===6)return this.setHex(parseInt(a,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Gt){const n=bh[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=qn(e.r),this.g=qn(e.g),this.b=qn(e.b),this}copyLinearToSRGB(e){return this.r=cs(e.r),this.g=cs(e.g),this.b=cs(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Gt){return Qe.fromWorkingColorSpace(Ft.copy(this),e),Math.round($t(Ft.r*255,0,255))*65536+Math.round($t(Ft.g*255,0,255))*256+Math.round($t(Ft.b*255,0,255))}getHexString(e=Gt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Qe.workingColorSpace){Qe.fromWorkingColorSpace(Ft.copy(this),t);const n=Ft.r,s=Ft.g,a=Ft.b,r=Math.max(n,s,a),o=Math.min(n,s,a);let l,c;const h=(o+r)/2;if(o===r)l=0,c=0;else{const d=r-o;switch(c=h<=.5?d/(r+o):d/(2-r-o),r){case n:l=(s-a)/d+(s<a?6:0);break;case s:l=(a-n)/d+2;break;case a:l=(n-s)/d+4;break}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=Qe.workingColorSpace){return Qe.fromWorkingColorSpace(Ft.copy(this),t),e.r=Ft.r,e.g=Ft.g,e.b=Ft.b,e}getStyle(e=Gt){Qe.fromWorkingColorSpace(Ft.copy(this),e);const t=Ft.r,n=Ft.g,s=Ft.b;return e!==Gt?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(ni),this.setHSL(ni.h+e,ni.s+t,ni.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(ni),e.getHSL(wa);const n=Ys(ni.h,wa.h,t),s=Ys(ni.s,wa.s,t),a=Ys(ni.l,wa.l,t);return this.setHSL(n,s,a),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,s=this.b,a=e.elements;return this.r=a[0]*t+a[3]*n+a[6]*s,this.g=a[1]*t+a[4]*n+a[7]*s,this.b=a[2]*t+a[5]*n+a[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ft=new pe;pe.NAMES=bh;let Xf=0;class fi extends Es{static get type(){return"Material"}get type(){return this.constructor.type}set type(e){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Xf++}),this.uuid=Xn(),this.name="",this.blending=os,this.side=Yn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=yo,this.blendDst=Mo,this.blendEquation=Ai,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new pe(0,0,0),this.blendAlpha=0,this.depthFunc=ms,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=mc,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Oi,this.stencilZFail=Oi,this.stencilZPass=Oi,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==os&&(n.blending=this.blending),this.side!==Yn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==yo&&(n.blendSrc=this.blendSrc),this.blendDst!==Mo&&(n.blendDst=this.blendDst),this.blendEquation!==Ai&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==ms&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==mc&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Oi&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Oi&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Oi&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(a){const r=[];for(const o in a){const l=a[o];delete l.metadata,r.push(l)}return r}if(t){const a=s(e.textures),r=s(e.images);a.length>0&&(n.textures=a),r.length>0&&(n.images=r)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const s=t.length;n=new Array(s);for(let a=0;a!==s;++a)n[a]=t[a].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}}class kt extends fi{static get type(){return"MeshBasicMaterial"}constructor(e){super(),this.isMeshBasicMaterial=!0,this.color=new pe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Cn,this.combine=Qd,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Tt=new R,Ea=new Pe;class Dt{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=al,this.updateRanges=[],this.gpuType=Gn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,a=this.itemSize;s<a;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)Ea.fromBufferAttribute(this,t),Ea.applyMatrix3(e),this.setXY(t,Ea.x,Ea.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Tt.fromBufferAttribute(this,t),Tt.applyMatrix3(e),this.setXYZ(t,Tt.x,Tt.y,Tt.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Tt.fromBufferAttribute(this,t),Tt.applyMatrix4(e),this.setXYZ(t,Tt.x,Tt.y,Tt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Tt.fromBufferAttribute(this,t),Tt.applyNormalMatrix(e),this.setXYZ(t,Tt.x,Tt.y,Tt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Tt.fromBufferAttribute(this,t),Tt.transformDirection(e),this.setXYZ(t,Tt.x,Tt.y,Tt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=mn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=lt(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=mn(t,this.array)),t}setX(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=mn(t,this.array)),t}setY(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=mn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=mn(t,this.array)),t}setW(e,t){return this.normalized&&(t=lt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,a){return e*=this.itemSize,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array),a=lt(a,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=a,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==al&&(e.usage=this.usage),e}}class Sh extends Dt{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class wh extends Dt{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class mt extends Dt{constructor(e,t,n){super(new Float32Array(e),t,n)}}let qf=0;const on=new pt,Kr=new Ct,Yi=new R,Jt=new ra,ks=new ra,Lt=new R;class bt extends Es{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:qf++}),this.uuid=Xn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(_h(e)?wh:Sh)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const a=new We().getNormalMatrix(e);n.applyNormalMatrix(a),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return on.makeRotationFromQuaternion(e),this.applyMatrix4(on),this}rotateX(e){return on.makeRotationX(e),this.applyMatrix4(on),this}rotateY(e){return on.makeRotationY(e),this.applyMatrix4(on),this}rotateZ(e){return on.makeRotationZ(e),this.applyMatrix4(on),this}translate(e,t,n){return on.makeTranslation(e,t,n),this.applyMatrix4(on),this}scale(e,t,n){return on.makeScale(e,t,n),this.applyMatrix4(on),this}lookAt(e){return Kr.lookAt(e),Kr.updateMatrix(),this.applyMatrix4(Kr.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Yi).negate(),this.translate(Yi.x,Yi.y,Yi.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let s=0,a=e.length;s<a;s++){const r=e[s];n.push(r.x,r.y,r.z||0)}this.setAttribute("position",new mt(n,3))}else{for(let n=0,s=t.count;n<s;n++){const a=e[n];t.setXYZ(n,a.x,a.y,a.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ra);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new R(-1/0,-1/0,-1/0),new R(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){const a=t[n];Jt.setFromBufferAttribute(a),this.morphTargetsRelative?(Lt.addVectors(this.boundingBox.min,Jt.min),this.boundingBox.expandByPoint(Lt),Lt.addVectors(this.boundingBox.max,Jt.max),this.boundingBox.expandByPoint(Lt)):(this.boundingBox.expandByPoint(Jt.min),this.boundingBox.expandByPoint(Jt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new oa);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new R,1/0);return}if(e){const n=this.boundingSphere.center;if(Jt.setFromBufferAttribute(e),t)for(let a=0,r=t.length;a<r;a++){const o=t[a];ks.setFromBufferAttribute(o),this.morphTargetsRelative?(Lt.addVectors(Jt.min,ks.min),Jt.expandByPoint(Lt),Lt.addVectors(Jt.max,ks.max),Jt.expandByPoint(Lt)):(Jt.expandByPoint(ks.min),Jt.expandByPoint(ks.max))}Jt.getCenter(n);let s=0;for(let a=0,r=e.count;a<r;a++)Lt.fromBufferAttribute(e,a),s=Math.max(s,n.distanceToSquared(Lt));if(t)for(let a=0,r=t.length;a<r;a++){const o=t[a],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)Lt.fromBufferAttribute(o,c),l&&(Yi.fromBufferAttribute(e,c),Lt.add(Yi)),s=Math.max(s,n.distanceToSquared(Lt))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,s=t.normal,a=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Dt(new Float32Array(4*n.count),4));const r=this.getAttribute("tangent"),o=[],l=[];for(let I=0;I<n.count;I++)o[I]=new R,l[I]=new R;const c=new R,h=new R,d=new R,u=new Pe,m=new Pe,g=new Pe,v=new R,f=new R;function p(I,S,y){c.fromBufferAttribute(n,I),h.fromBufferAttribute(n,S),d.fromBufferAttribute(n,y),u.fromBufferAttribute(a,I),m.fromBufferAttribute(a,S),g.fromBufferAttribute(a,y),h.sub(c),d.sub(c),m.sub(u),g.sub(u);const D=1/(m.x*g.y-g.x*m.y);isFinite(D)&&(v.copy(h).multiplyScalar(g.y).addScaledVector(d,-m.y).multiplyScalar(D),f.copy(d).multiplyScalar(m.x).addScaledVector(h,-g.x).multiplyScalar(D),o[I].add(v),o[S].add(v),o[y].add(v),l[I].add(f),l[S].add(f),l[y].add(f))}let E=this.groups;E.length===0&&(E=[{start:0,count:e.count}]);for(let I=0,S=E.length;I<S;++I){const y=E[I],D=y.start,V=y.count;for(let z=D,X=D+V;z<X;z+=3)p(e.getX(z+0),e.getX(z+1),e.getX(z+2))}const w=new R,b=new R,O=new R,P=new R;function L(I){O.fromBufferAttribute(s,I),P.copy(O);const S=o[I];w.copy(S),w.sub(O.multiplyScalar(O.dot(S))).normalize(),b.crossVectors(P,S);const D=b.dot(l[I])<0?-1:1;r.setXYZW(I,w.x,w.y,w.z,D)}for(let I=0,S=E.length;I<S;++I){const y=E[I],D=y.start,V=y.count;for(let z=D,X=D+V;z<X;z+=3)L(e.getX(z+0)),L(e.getX(z+1)),L(e.getX(z+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Dt(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let u=0,m=n.count;u<m;u++)n.setXYZ(u,0,0,0);const s=new R,a=new R,r=new R,o=new R,l=new R,c=new R,h=new R,d=new R;if(e)for(let u=0,m=e.count;u<m;u+=3){const g=e.getX(u+0),v=e.getX(u+1),f=e.getX(u+2);s.fromBufferAttribute(t,g),a.fromBufferAttribute(t,v),r.fromBufferAttribute(t,f),h.subVectors(r,a),d.subVectors(s,a),h.cross(d),o.fromBufferAttribute(n,g),l.fromBufferAttribute(n,v),c.fromBufferAttribute(n,f),o.add(h),l.add(h),c.add(h),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(v,l.x,l.y,l.z),n.setXYZ(f,c.x,c.y,c.z)}else for(let u=0,m=t.count;u<m;u+=3)s.fromBufferAttribute(t,u+0),a.fromBufferAttribute(t,u+1),r.fromBufferAttribute(t,u+2),h.subVectors(r,a),d.subVectors(s,a),h.cross(d),n.setXYZ(u+0,h.x,h.y,h.z),n.setXYZ(u+1,h.x,h.y,h.z),n.setXYZ(u+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Lt.fromBufferAttribute(e,t),Lt.normalize(),e.setXYZ(t,Lt.x,Lt.y,Lt.z)}toNonIndexed(){function e(o,l){const c=o.array,h=o.itemSize,d=o.normalized,u=new c.constructor(l.length*h);let m=0,g=0;for(let v=0,f=l.length;v<f;v++){o.isInterleavedBufferAttribute?m=l[v]*o.data.stride+o.offset:m=l[v]*h;for(let p=0;p<h;p++)u[g++]=c[m++]}return new Dt(u,h,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new bt,n=this.index.array,s=this.attributes;for(const o in s){const l=s[o],c=e(l,n);t.setAttribute(o,c)}const a=this.morphAttributes;for(const o in a){const l=[],c=a[o];for(let h=0,d=c.length;h<d;h++){const u=c[h],m=e(u,n);l.push(m)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;const r=this.groups;for(let o=0,l=r.length;o<l;o++){const c=r[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const l in n){const c=n[l];e.data.attributes[l]=c.toJSON(e.data)}const s={};let a=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],h=[];for(let d=0,u=c.length;d<u;d++){const m=c[d];h.push(m.toJSON(e.data))}h.length>0&&(s[l]=h,a=!0)}a&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const r=this.groups;r.length>0&&(e.data.groups=JSON.parse(JSON.stringify(r)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone(t));const s=e.attributes;for(const c in s){const h=s[c];this.setAttribute(c,h.clone(t))}const a=e.morphAttributes;for(const c in a){const h=[],d=a[c];for(let u=0,m=d.length;u<m;u++)h.push(d[u].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;const r=e.groups;for(let c=0,h=r.length;c<h;c++){const d=r[c];this.addGroup(d.start,d.count,d.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Ic=new pt,_i=new Ul,Ta=new oa,Uc=new R,Aa=new R,Ca=new R,Ra=new R,Zr=new R,Pa=new R,Nc=new R,La=new R;class Ge extends Ct{constructor(e=new bt,t=new kt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let a=0,r=s.length;a<r;a++){const o=s[a].name||String(a);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=a}}}}getVertexPosition(e,t){const n=this.geometry,s=n.attributes.position,a=n.morphAttributes.position,r=n.morphTargetsRelative;t.fromBufferAttribute(s,e);const o=this.morphTargetInfluences;if(a&&o){Pa.set(0,0,0);for(let l=0,c=a.length;l<c;l++){const h=o[l],d=a[l];h!==0&&(Zr.fromBufferAttribute(d,e),r?Pa.addScaledVector(Zr,h):Pa.addScaledVector(Zr.sub(t),h))}t.add(Pa)}return t}raycast(e,t){const n=this.geometry,s=this.material,a=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Ta.copy(n.boundingSphere),Ta.applyMatrix4(a),_i.copy(e.ray).recast(e.near),!(Ta.containsPoint(_i.origin)===!1&&(_i.intersectSphere(Ta,Uc)===null||_i.origin.distanceToSquared(Uc)>(e.far-e.near)**2))&&(Ic.copy(a).invert(),_i.copy(e.ray).applyMatrix4(Ic),!(n.boundingBox!==null&&_i.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,_i)))}_computeIntersections(e,t,n){let s;const a=this.geometry,r=this.material,o=a.index,l=a.attributes.position,c=a.attributes.uv,h=a.attributes.uv1,d=a.attributes.normal,u=a.groups,m=a.drawRange;if(o!==null)if(Array.isArray(r))for(let g=0,v=u.length;g<v;g++){const f=u[g],p=r[f.materialIndex],E=Math.max(f.start,m.start),w=Math.min(o.count,Math.min(f.start+f.count,m.start+m.count));for(let b=E,O=w;b<O;b+=3){const P=o.getX(b),L=o.getX(b+1),I=o.getX(b+2);s=Da(this,p,e,n,c,h,d,P,L,I),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=f.materialIndex,t.push(s))}}else{const g=Math.max(0,m.start),v=Math.min(o.count,m.start+m.count);for(let f=g,p=v;f<p;f+=3){const E=o.getX(f),w=o.getX(f+1),b=o.getX(f+2);s=Da(this,r,e,n,c,h,d,E,w,b),s&&(s.faceIndex=Math.floor(f/3),t.push(s))}}else if(l!==void 0)if(Array.isArray(r))for(let g=0,v=u.length;g<v;g++){const f=u[g],p=r[f.materialIndex],E=Math.max(f.start,m.start),w=Math.min(l.count,Math.min(f.start+f.count,m.start+m.count));for(let b=E,O=w;b<O;b+=3){const P=b,L=b+1,I=b+2;s=Da(this,p,e,n,c,h,d,P,L,I),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=f.materialIndex,t.push(s))}}else{const g=Math.max(0,m.start),v=Math.min(l.count,m.start+m.count);for(let f=g,p=v;f<p;f+=3){const E=f,w=f+1,b=f+2;s=Da(this,r,e,n,c,h,d,E,w,b),s&&(s.faceIndex=Math.floor(f/3),t.push(s))}}}}function Yf(i,e,t,n,s,a,r,o){let l;if(e.side===jt?l=n.intersectTriangle(r,a,s,!0,o):l=n.intersectTriangle(s,a,r,e.side===Yn,o),l===null)return null;La.copy(o),La.applyMatrix4(i.matrixWorld);const c=t.ray.origin.distanceTo(La);return c<t.near||c>t.far?null:{distance:c,point:La.clone(),object:i}}function Da(i,e,t,n,s,a,r,o,l,c){i.getVertexPosition(o,Aa),i.getVertexPosition(l,Ca),i.getVertexPosition(c,Ra);const h=Yf(i,e,t,n,Aa,Ca,Ra,Nc);if(h){const d=new R;ln.getBarycoord(Nc,Aa,Ca,Ra,d),s&&(h.uv=ln.getInterpolatedAttribute(s,o,l,c,d,new Pe)),a&&(h.uv1=ln.getInterpolatedAttribute(a,o,l,c,d,new Pe)),r&&(h.normal=ln.getInterpolatedAttribute(r,o,l,c,d,new R),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const u={a:o,b:l,c,normal:new R,materialIndex:0};ln.getNormal(Aa,Ca,Ra,u.normal),h.face=u,h.barycoord=d}return h}class li extends bt{constructor(e=1,t=1,n=1,s=1,a=1,r=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:a,depthSegments:r};const o=this;s=Math.floor(s),a=Math.floor(a),r=Math.floor(r);const l=[],c=[],h=[],d=[];let u=0,m=0;g("z","y","x",-1,-1,n,t,e,r,a,0),g("z","y","x",1,-1,n,t,-e,r,a,1),g("x","z","y",1,1,e,n,t,s,r,2),g("x","z","y",1,-1,e,n,-t,s,r,3),g("x","y","z",1,-1,e,t,n,s,a,4),g("x","y","z",-1,-1,e,t,-n,s,a,5),this.setIndex(l),this.setAttribute("position",new mt(c,3)),this.setAttribute("normal",new mt(h,3)),this.setAttribute("uv",new mt(d,2));function g(v,f,p,E,w,b,O,P,L,I,S){const y=b/L,D=O/I,V=b/2,z=O/2,X=P/2,J=L+1,q=I+1;let ne=0,$=0;const ce=new R;for(let ee=0;ee<q;ee++){const ie=ee*D-z;for(let ve=0;ve<J;ve++){const Te=ve*y-V;ce[v]=Te*E,ce[f]=ie*w,ce[p]=X,c.push(ce.x,ce.y,ce.z),ce[v]=0,ce[f]=0,ce[p]=P>0?1:-1,h.push(ce.x,ce.y,ce.z),d.push(ve/L),d.push(1-ee/I),ne+=1}}for(let ee=0;ee<I;ee++)for(let ie=0;ie<L;ie++){const ve=u+ie+J*ee,Te=u+ie+J*(ee+1),Y=u+(ie+1)+J*(ee+1),te=u+(ie+1)+J*ee;l.push(ve,Te,te),l.push(Te,Y,te),$+=6}o.addGroup(m,$,S),m+=$,u+=ne}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new li(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function ys(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const s=i[t][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone():Array.isArray(s)?e[t][n]=s.slice():e[t][n]=s}}return e}function Ht(i){const e={};for(let t=0;t<i.length;t++){const n=ys(i[t]);for(const s in n)e[s]=n[s]}return e}function jf(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function Eh(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Qe.workingColorSpace}const na={clone:ys,merge:Ht};var Kf=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Zf=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Ot extends fi{static get type(){return"ShaderMaterial"}constructor(e){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Kf,this.fragmentShader=Zf,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=ys(e.uniforms),this.uniformsGroups=jf(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const r=this.uniforms[s].value;r&&r.isTexture?t.uniforms[s]={type:"t",value:r.toJSON(e).uuid}:r&&r.isColor?t.uniforms[s]={type:"c",value:r.getHex()}:r&&r.isVector2?t.uniforms[s]={type:"v2",value:r.toArray()}:r&&r.isVector3?t.uniforms[s]={type:"v3",value:r.toArray()}:r&&r.isVector4?t.uniforms[s]={type:"v4",value:r.toArray()}:r&&r.isMatrix3?t.uniforms[s]={type:"m3",value:r.toArray()}:r&&r.isMatrix4?t.uniforms[s]={type:"m4",value:r.toArray()}:t.uniforms[s]={value:r}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class Th extends Ct{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new pt,this.projectionMatrix=new pt,this.projectionMatrixInverse=new pt,this.coordinateSystem=Vn}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const ii=new R,Fc=new Pe,kc=new Pe;class qt extends Th{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Qs*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(qs*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Qs*2*Math.atan(Math.tan(qs*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){ii.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(ii.x,ii.y).multiplyScalar(-e/ii.z),ii.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(ii.x,ii.y).multiplyScalar(-e/ii.z)}getViewSize(e,t){return this.getViewBounds(e,Fc,kc),t.subVectors(kc,Fc)}setViewOffset(e,t,n,s,a,r){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=a,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(qs*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,a=-.5*s;const r=this.view;if(this.view!==null&&this.view.enabled){const l=r.fullWidth,c=r.fullHeight;a+=r.offsetX*s/l,t-=r.offsetY*n/c,s*=r.width/l,n*=r.height/c}const o=this.filmOffset;o!==0&&(a+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(a,a+s,t,t-n,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const ji=-90,Ki=1;class Jf extends Ct{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new qt(ji,Ki,e,t);s.layers=this.layers,this.add(s);const a=new qt(ji,Ki,e,t);a.layers=this.layers,this.add(a);const r=new qt(ji,Ki,e,t);r.layers=this.layers,this.add(r);const o=new qt(ji,Ki,e,t);o.layers=this.layers,this.add(o);const l=new qt(ji,Ki,e,t);l.layers=this.layers,this.add(l);const c=new qt(ji,Ki,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,s,a,r,o,l]=t;for(const c of t)this.remove(c);if(e===Vn)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),a.up.set(0,0,-1),a.lookAt(0,1,0),r.up.set(0,0,1),r.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===or)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),a.up.set(0,0,1),a.lookAt(0,1,0),r.up.set(0,0,-1),r.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[a,r,o,l,c,h]=this.children,d=e.getRenderTarget(),u=e.getActiveCubeFace(),m=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const v=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,s),e.render(t,a),e.setRenderTarget(n,1,s),e.render(t,r),e.setRenderTarget(n,2,s),e.render(t,o),e.setRenderTarget(n,3,s),e.render(t,l),e.setRenderTarget(n,4,s),e.render(t,c),n.texture.generateMipmaps=v,e.setRenderTarget(n,5,s),e.render(t,h),e.setRenderTarget(d,u,m),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class Ah extends Bt{constructor(e,t,n,s,a,r,o,l,c,h){e=e!==void 0?e:[],t=t!==void 0?t:gs,super(e,t,n,s,a,r,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Qf extends xn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];this.texture=new Ah(s,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:Tn}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new li(5,5,5),a=new Ot({name:"CubemapFromEquirect",uniforms:ys(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:jt,blending:$n});a.uniforms.tEquirect.value=t;const r=new Ge(s,a),o=t.minFilter;return t.minFilter===Di&&(t.minFilter=Tn),new Jf(1,10,this).update(e,r),t.minFilter=o,r.geometry.dispose(),r.material.dispose(),this}clear(e,t,n,s){const a=e.getRenderTarget();for(let r=0;r<6;r++)e.setRenderTarget(this,r),e.clear(t,n,s);e.setRenderTarget(a)}}const Jr=new R,ep=new R,tp=new We;class Ei{constructor(e=new R(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const s=Jr.subVectors(n,t).cross(ep.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(Jr),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const a=-(e.start.dot(this.normal)+this.constant)/s;return a<0||a>1?null:t.copy(e.start).addScaledVector(n,a)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||tp.getNormalMatrix(e),s=this.coplanarPoint(Jr).applyMatrix4(e),a=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(a),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const xi=new oa,Ia=new R;class Nl{constructor(e=new Ei,t=new Ei,n=new Ei,s=new Ei,a=new Ei,r=new Ei){this.planes=[e,t,n,s,a,r]}set(e,t,n,s,a,r){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(s),o[4].copy(a),o[5].copy(r),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=Vn){const n=this.planes,s=e.elements,a=s[0],r=s[1],o=s[2],l=s[3],c=s[4],h=s[5],d=s[6],u=s[7],m=s[8],g=s[9],v=s[10],f=s[11],p=s[12],E=s[13],w=s[14],b=s[15];if(n[0].setComponents(l-a,u-c,f-m,b-p).normalize(),n[1].setComponents(l+a,u+c,f+m,b+p).normalize(),n[2].setComponents(l+r,u+h,f+g,b+E).normalize(),n[3].setComponents(l-r,u-h,f-g,b-E).normalize(),n[4].setComponents(l-o,u-d,f-v,b-w).normalize(),t===Vn)n[5].setComponents(l+o,u+d,f+v,b+w).normalize();else if(t===or)n[5].setComponents(o,d,v,w).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),xi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),xi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(xi)}intersectsSprite(e){return xi.center.set(0,0,0),xi.radius=.7071067811865476,xi.applyMatrix4(e.matrixWorld),this.intersectsSphere(xi)}intersectsSphere(e){const t=this.planes,n=e.center,s=-e.radius;for(let a=0;a<6;a++)if(t[a].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const s=t[n];if(Ia.x=s.normal.x>0?e.max.x:e.min.x,Ia.y=s.normal.y>0?e.max.y:e.min.y,Ia.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(Ia)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function Ch(){let i=null,e=!1,t=null,n=null;function s(a,r){t(a,r),n=i.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(a){t=a},setContext:function(a){i=a}}}function np(i){const e=new WeakMap;function t(o,l){const c=o.array,h=o.usage,d=c.byteLength,u=i.createBuffer();i.bindBuffer(l,u),i.bufferData(l,c,h),o.onUploadCallback();let m;if(c instanceof Float32Array)m=i.FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?m=i.HALF_FLOAT:m=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)m=i.SHORT;else if(c instanceof Uint32Array)m=i.UNSIGNED_INT;else if(c instanceof Int32Array)m=i.INT;else if(c instanceof Int8Array)m=i.BYTE;else if(c instanceof Uint8Array)m=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)m=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:u,type:m,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:d}}function n(o,l,c){const h=l.array,d=l.updateRanges;if(i.bindBuffer(c,o),d.length===0)i.bufferSubData(c,0,h);else{d.sort((m,g)=>m.start-g.start);let u=0;for(let m=1;m<d.length;m++){const g=d[u],v=d[m];v.start<=g.start+g.count+1?g.count=Math.max(g.count,v.start+v.count-g.start):(++u,d[u]=v)}d.length=u+1;for(let m=0,g=d.length;m<g;m++){const v=d[m];i.bufferSubData(c,v.start*h.BYTES_PER_ELEMENT,h,v.start,v.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(o){return o.isInterleavedBufferAttribute&&(o=o.data),e.get(o)}function a(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=e.get(o);l&&(i.deleteBuffer(l.buffer),e.delete(o))}function r(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const h=e.get(o);(!h||h.version<o.version)&&e.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=e.get(o);if(c===void 0)e.set(o,t(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:s,remove:a,update:r}}class Ts extends bt{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};const a=e/2,r=t/2,o=Math.floor(n),l=Math.floor(s),c=o+1,h=l+1,d=e/o,u=t/l,m=[],g=[],v=[],f=[];for(let p=0;p<h;p++){const E=p*u-r;for(let w=0;w<c;w++){const b=w*d-a;g.push(b,-E,0),v.push(0,0,1),f.push(w/o),f.push(1-p/l)}}for(let p=0;p<l;p++)for(let E=0;E<o;E++){const w=E+c*p,b=E+c*(p+1),O=E+1+c*(p+1),P=E+1+c*p;m.push(w,b,P),m.push(b,O,P)}this.setIndex(m),this.setAttribute("position",new mt(g,3)),this.setAttribute("normal",new mt(v,3)),this.setAttribute("uv",new mt(f,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ts(e.width,e.height,e.widthSegments,e.heightSegments)}}var ip=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,sp=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,ap=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,rp=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,op=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,lp=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,cp=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,dp=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,hp=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,up=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,fp=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,pp=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,mp=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,gp=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,vp=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,_p=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,xp=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,yp=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Mp=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,bp=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Sp=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,wp=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Ep=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Tp=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Ap=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Cp=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Rp=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Pp=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Lp=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Dp=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Ip="gl_FragColor = linearToOutputTexel( gl_FragColor );",Up=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Np=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Fp=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,kp=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Op=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Bp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,zp=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Hp=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Gp=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Vp=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,$p=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Wp=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Xp=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,qp=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Yp=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,jp=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Kp=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Zp=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Jp=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Qp=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,em=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,tm=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,nm=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,im=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,sm=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,am=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,rm=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,om=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,lm=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,cm=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,dm=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,hm=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,um=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,fm=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,pm=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,mm=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,gm=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,vm=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,_m=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,xm=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,ym=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Mm=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,bm=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Sm=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,wm=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Em=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Tm=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Am=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Cm=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Rm=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Pm=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Lm=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Dm=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Im=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Um=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Nm=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Fm=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,km=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Om=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Bm=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,zm=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Hm=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Gm=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Vm=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,$m=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Wm=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Xm=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,qm=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Ym=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,jm=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Km=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Zm=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Jm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Qm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,eg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,tg=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const ng=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,ig=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,sg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,ag=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,rg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,og=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,lg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,cg=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,dg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,hg=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,ug=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,fg=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pg=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,mg=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,gg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,vg=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_g=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,xg=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,yg=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Mg=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,bg=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Sg=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,wg=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Eg=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Ag=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Cg=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Rg=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Pg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Lg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Dg=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ig=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ug=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Ng=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,qe={alphahash_fragment:ip,alphahash_pars_fragment:sp,alphamap_fragment:ap,alphamap_pars_fragment:rp,alphatest_fragment:op,alphatest_pars_fragment:lp,aomap_fragment:cp,aomap_pars_fragment:dp,batching_pars_vertex:hp,batching_vertex:up,begin_vertex:fp,beginnormal_vertex:pp,bsdfs:mp,iridescence_fragment:gp,bumpmap_pars_fragment:vp,clipping_planes_fragment:_p,clipping_planes_pars_fragment:xp,clipping_planes_pars_vertex:yp,clipping_planes_vertex:Mp,color_fragment:bp,color_pars_fragment:Sp,color_pars_vertex:wp,color_vertex:Ep,common:Tp,cube_uv_reflection_fragment:Ap,defaultnormal_vertex:Cp,displacementmap_pars_vertex:Rp,displacementmap_vertex:Pp,emissivemap_fragment:Lp,emissivemap_pars_fragment:Dp,colorspace_fragment:Ip,colorspace_pars_fragment:Up,envmap_fragment:Np,envmap_common_pars_fragment:Fp,envmap_pars_fragment:kp,envmap_pars_vertex:Op,envmap_physical_pars_fragment:jp,envmap_vertex:Bp,fog_vertex:zp,fog_pars_vertex:Hp,fog_fragment:Gp,fog_pars_fragment:Vp,gradientmap_pars_fragment:$p,lightmap_pars_fragment:Wp,lights_lambert_fragment:Xp,lights_lambert_pars_fragment:qp,lights_pars_begin:Yp,lights_toon_fragment:Kp,lights_toon_pars_fragment:Zp,lights_phong_fragment:Jp,lights_phong_pars_fragment:Qp,lights_physical_fragment:em,lights_physical_pars_fragment:tm,lights_fragment_begin:nm,lights_fragment_maps:im,lights_fragment_end:sm,logdepthbuf_fragment:am,logdepthbuf_pars_fragment:rm,logdepthbuf_pars_vertex:om,logdepthbuf_vertex:lm,map_fragment:cm,map_pars_fragment:dm,map_particle_fragment:hm,map_particle_pars_fragment:um,metalnessmap_fragment:fm,metalnessmap_pars_fragment:pm,morphinstance_vertex:mm,morphcolor_vertex:gm,morphnormal_vertex:vm,morphtarget_pars_vertex:_m,morphtarget_vertex:xm,normal_fragment_begin:ym,normal_fragment_maps:Mm,normal_pars_fragment:bm,normal_pars_vertex:Sm,normal_vertex:wm,normalmap_pars_fragment:Em,clearcoat_normal_fragment_begin:Tm,clearcoat_normal_fragment_maps:Am,clearcoat_pars_fragment:Cm,iridescence_pars_fragment:Rm,opaque_fragment:Pm,packing:Lm,premultiplied_alpha_fragment:Dm,project_vertex:Im,dithering_fragment:Um,dithering_pars_fragment:Nm,roughnessmap_fragment:Fm,roughnessmap_pars_fragment:km,shadowmap_pars_fragment:Om,shadowmap_pars_vertex:Bm,shadowmap_vertex:zm,shadowmask_pars_fragment:Hm,skinbase_vertex:Gm,skinning_pars_vertex:Vm,skinning_vertex:$m,skinnormal_vertex:Wm,specularmap_fragment:Xm,specularmap_pars_fragment:qm,tonemapping_fragment:Ym,tonemapping_pars_fragment:jm,transmission_fragment:Km,transmission_pars_fragment:Zm,uv_pars_fragment:Jm,uv_pars_vertex:Qm,uv_vertex:eg,worldpos_vertex:tg,background_vert:ng,background_frag:ig,backgroundCube_vert:sg,backgroundCube_frag:ag,cube_vert:rg,cube_frag:og,depth_vert:lg,depth_frag:cg,distanceRGBA_vert:dg,distanceRGBA_frag:hg,equirect_vert:ug,equirect_frag:fg,linedashed_vert:pg,linedashed_frag:mg,meshbasic_vert:gg,meshbasic_frag:vg,meshlambert_vert:_g,meshlambert_frag:xg,meshmatcap_vert:yg,meshmatcap_frag:Mg,meshnormal_vert:bg,meshnormal_frag:Sg,meshphong_vert:wg,meshphong_frag:Eg,meshphysical_vert:Tg,meshphysical_frag:Ag,meshtoon_vert:Cg,meshtoon_frag:Rg,points_vert:Pg,points_frag:Lg,shadow_vert:Dg,shadow_frag:Ig,sprite_vert:Ug,sprite_frag:Ng},oe={common:{diffuse:{value:new pe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new We},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new We}},envmap:{envMap:{value:null},envMapRotation:{value:new We},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new We}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new We}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new We},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new We},normalScale:{value:new Pe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new We},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new We}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new We}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new We}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new pe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new pe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0},uvTransform:{value:new We}},sprite:{diffuse:{value:new pe(16777215)},opacity:{value:1},center:{value:new Pe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new We},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0}}},Sn={basic:{uniforms:Ht([oe.common,oe.specularmap,oe.envmap,oe.aomap,oe.lightmap,oe.fog]),vertexShader:qe.meshbasic_vert,fragmentShader:qe.meshbasic_frag},lambert:{uniforms:Ht([oe.common,oe.specularmap,oe.envmap,oe.aomap,oe.lightmap,oe.emissivemap,oe.bumpmap,oe.normalmap,oe.displacementmap,oe.fog,oe.lights,{emissive:{value:new pe(0)}}]),vertexShader:qe.meshlambert_vert,fragmentShader:qe.meshlambert_frag},phong:{uniforms:Ht([oe.common,oe.specularmap,oe.envmap,oe.aomap,oe.lightmap,oe.emissivemap,oe.bumpmap,oe.normalmap,oe.displacementmap,oe.fog,oe.lights,{emissive:{value:new pe(0)},specular:{value:new pe(1118481)},shininess:{value:30}}]),vertexShader:qe.meshphong_vert,fragmentShader:qe.meshphong_frag},standard:{uniforms:Ht([oe.common,oe.envmap,oe.aomap,oe.lightmap,oe.emissivemap,oe.bumpmap,oe.normalmap,oe.displacementmap,oe.roughnessmap,oe.metalnessmap,oe.fog,oe.lights,{emissive:{value:new pe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag},toon:{uniforms:Ht([oe.common,oe.aomap,oe.lightmap,oe.emissivemap,oe.bumpmap,oe.normalmap,oe.displacementmap,oe.gradientmap,oe.fog,oe.lights,{emissive:{value:new pe(0)}}]),vertexShader:qe.meshtoon_vert,fragmentShader:qe.meshtoon_frag},matcap:{uniforms:Ht([oe.common,oe.bumpmap,oe.normalmap,oe.displacementmap,oe.fog,{matcap:{value:null}}]),vertexShader:qe.meshmatcap_vert,fragmentShader:qe.meshmatcap_frag},points:{uniforms:Ht([oe.points,oe.fog]),vertexShader:qe.points_vert,fragmentShader:qe.points_frag},dashed:{uniforms:Ht([oe.common,oe.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:qe.linedashed_vert,fragmentShader:qe.linedashed_frag},depth:{uniforms:Ht([oe.common,oe.displacementmap]),vertexShader:qe.depth_vert,fragmentShader:qe.depth_frag},normal:{uniforms:Ht([oe.common,oe.bumpmap,oe.normalmap,oe.displacementmap,{opacity:{value:1}}]),vertexShader:qe.meshnormal_vert,fragmentShader:qe.meshnormal_frag},sprite:{uniforms:Ht([oe.sprite,oe.fog]),vertexShader:qe.sprite_vert,fragmentShader:qe.sprite_frag},background:{uniforms:{uvTransform:{value:new We},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:qe.background_vert,fragmentShader:qe.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new We}},vertexShader:qe.backgroundCube_vert,fragmentShader:qe.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:qe.cube_vert,fragmentShader:qe.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:qe.equirect_vert,fragmentShader:qe.equirect_frag},distanceRGBA:{uniforms:Ht([oe.common,oe.displacementmap,{referencePosition:{value:new R},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:qe.distanceRGBA_vert,fragmentShader:qe.distanceRGBA_frag},shadow:{uniforms:Ht([oe.lights,oe.fog,{color:{value:new pe(0)},opacity:{value:1}}]),vertexShader:qe.shadow_vert,fragmentShader:qe.shadow_frag}};Sn.physical={uniforms:Ht([Sn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new We},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new We},clearcoatNormalScale:{value:new Pe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new We},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new We},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new We},sheen:{value:0},sheenColor:{value:new pe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new We},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new We},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new We},transmissionSamplerSize:{value:new Pe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new We},attenuationDistance:{value:0},attenuationColor:{value:new pe(0)},specularColor:{value:new pe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new We},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new We},anisotropyVector:{value:new Pe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new We}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag};const Ua={r:0,b:0,g:0},yi=new Cn,Fg=new pt;function kg(i,e,t,n,s,a,r){const o=new pe(0);let l=a===!0?0:1,c,h,d=null,u=0,m=null;function g(E){let w=E.isScene===!0?E.background:null;return w&&w.isTexture&&(w=(E.backgroundBlurriness>0?t:e).get(w)),w}function v(E){let w=!1;const b=g(E);b===null?p(o,l):b&&b.isColor&&(p(b,1),w=!0);const O=i.xr.getEnvironmentBlendMode();O==="additive"?n.buffers.color.setClear(0,0,0,1,r):O==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,r),(i.autoClear||w)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function f(E,w){const b=g(w);b&&(b.isCubeTexture||b.mapping===vr)?(h===void 0&&(h=new Ge(new li(1,1,1),new Ot({name:"BackgroundCubeMaterial",uniforms:ys(Sn.backgroundCube.uniforms),vertexShader:Sn.backgroundCube.vertexShader,fragmentShader:Sn.backgroundCube.fragmentShader,side:jt,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(O,P,L){this.matrixWorld.copyPosition(L.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),yi.copy(w.backgroundRotation),yi.x*=-1,yi.y*=-1,yi.z*=-1,b.isCubeTexture&&b.isRenderTargetTexture===!1&&(yi.y*=-1,yi.z*=-1),h.material.uniforms.envMap.value=b,h.material.uniforms.flipEnvMap.value=b.isCubeTexture&&b.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=w.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=w.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(Fg.makeRotationFromEuler(yi)),h.material.toneMapped=Qe.getTransfer(b.colorSpace)!==ot,(d!==b||u!==b.version||m!==i.toneMapping)&&(h.material.needsUpdate=!0,d=b,u=b.version,m=i.toneMapping),h.layers.enableAll(),E.unshift(h,h.geometry,h.material,0,0,null)):b&&b.isTexture&&(c===void 0&&(c=new Ge(new Ts(2,2),new Ot({name:"BackgroundMaterial",uniforms:ys(Sn.background.uniforms),vertexShader:Sn.background.vertexShader,fragmentShader:Sn.background.fragmentShader,side:Yn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=b,c.material.uniforms.backgroundIntensity.value=w.backgroundIntensity,c.material.toneMapped=Qe.getTransfer(b.colorSpace)!==ot,b.matrixAutoUpdate===!0&&b.updateMatrix(),c.material.uniforms.uvTransform.value.copy(b.matrix),(d!==b||u!==b.version||m!==i.toneMapping)&&(c.material.needsUpdate=!0,d=b,u=b.version,m=i.toneMapping),c.layers.enableAll(),E.unshift(c,c.geometry,c.material,0,0,null))}function p(E,w){E.getRGB(Ua,Eh(i)),n.buffers.color.setClear(Ua.r,Ua.g,Ua.b,w,r)}return{getClearColor:function(){return o},setClearColor:function(E,w=1){o.set(E),l=w,p(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(E){l=E,p(o,l)},render:v,addToRenderList:f}}function Og(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=u(null);let a=s,r=!1;function o(y,D,V,z,X){let J=!1;const q=d(z,V,D);a!==q&&(a=q,c(a.object)),J=m(y,z,V,X),J&&g(y,z,V,X),X!==null&&e.update(X,i.ELEMENT_ARRAY_BUFFER),(J||r)&&(r=!1,b(y,D,V,z),X!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(X).buffer))}function l(){return i.createVertexArray()}function c(y){return i.bindVertexArray(y)}function h(y){return i.deleteVertexArray(y)}function d(y,D,V){const z=V.wireframe===!0;let X=n[y.id];X===void 0&&(X={},n[y.id]=X);let J=X[D.id];J===void 0&&(J={},X[D.id]=J);let q=J[z];return q===void 0&&(q=u(l()),J[z]=q),q}function u(y){const D=[],V=[],z=[];for(let X=0;X<t;X++)D[X]=0,V[X]=0,z[X]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:D,enabledAttributes:V,attributeDivisors:z,object:y,attributes:{},index:null}}function m(y,D,V,z){const X=a.attributes,J=D.attributes;let q=0;const ne=V.getAttributes();for(const $ in ne)if(ne[$].location>=0){const ee=X[$];let ie=J[$];if(ie===void 0&&($==="instanceMatrix"&&y.instanceMatrix&&(ie=y.instanceMatrix),$==="instanceColor"&&y.instanceColor&&(ie=y.instanceColor)),ee===void 0||ee.attribute!==ie||ie&&ee.data!==ie.data)return!0;q++}return a.attributesNum!==q||a.index!==z}function g(y,D,V,z){const X={},J=D.attributes;let q=0;const ne=V.getAttributes();for(const $ in ne)if(ne[$].location>=0){let ee=J[$];ee===void 0&&($==="instanceMatrix"&&y.instanceMatrix&&(ee=y.instanceMatrix),$==="instanceColor"&&y.instanceColor&&(ee=y.instanceColor));const ie={};ie.attribute=ee,ee&&ee.data&&(ie.data=ee.data),X[$]=ie,q++}a.attributes=X,a.attributesNum=q,a.index=z}function v(){const y=a.newAttributes;for(let D=0,V=y.length;D<V;D++)y[D]=0}function f(y){p(y,0)}function p(y,D){const V=a.newAttributes,z=a.enabledAttributes,X=a.attributeDivisors;V[y]=1,z[y]===0&&(i.enableVertexAttribArray(y),z[y]=1),X[y]!==D&&(i.vertexAttribDivisor(y,D),X[y]=D)}function E(){const y=a.newAttributes,D=a.enabledAttributes;for(let V=0,z=D.length;V<z;V++)D[V]!==y[V]&&(i.disableVertexAttribArray(V),D[V]=0)}function w(y,D,V,z,X,J,q){q===!0?i.vertexAttribIPointer(y,D,V,X,J):i.vertexAttribPointer(y,D,V,z,X,J)}function b(y,D,V,z){v();const X=z.attributes,J=V.getAttributes(),q=D.defaultAttributeValues;for(const ne in J){const $=J[ne];if($.location>=0){let ce=X[ne];if(ce===void 0&&(ne==="instanceMatrix"&&y.instanceMatrix&&(ce=y.instanceMatrix),ne==="instanceColor"&&y.instanceColor&&(ce=y.instanceColor)),ce!==void 0){const ee=ce.normalized,ie=ce.itemSize,ve=e.get(ce);if(ve===void 0)continue;const Te=ve.buffer,Y=ve.type,te=ve.bytesPerElement,Me=Y===i.INT||Y===i.UNSIGNED_INT||ce.gpuType===Al;if(ce.isInterleavedBufferAttribute){const le=ce.data,De=le.stride,ze=ce.offset;if(le.isInstancedInterleavedBuffer){for(let Ye=0;Ye<$.locationSize;Ye++)p($.location+Ye,le.meshPerAttribute);y.isInstancedMesh!==!0&&z._maxInstanceCount===void 0&&(z._maxInstanceCount=le.meshPerAttribute*le.count)}else for(let Ye=0;Ye<$.locationSize;Ye++)f($.location+Ye);i.bindBuffer(i.ARRAY_BUFFER,Te);for(let Ye=0;Ye<$.locationSize;Ye++)w($.location+Ye,ie/$.locationSize,Y,ee,De*te,(ze+ie/$.locationSize*Ye)*te,Me)}else{if(ce.isInstancedBufferAttribute){for(let le=0;le<$.locationSize;le++)p($.location+le,ce.meshPerAttribute);y.isInstancedMesh!==!0&&z._maxInstanceCount===void 0&&(z._maxInstanceCount=ce.meshPerAttribute*ce.count)}else for(let le=0;le<$.locationSize;le++)f($.location+le);i.bindBuffer(i.ARRAY_BUFFER,Te);for(let le=0;le<$.locationSize;le++)w($.location+le,ie/$.locationSize,Y,ee,ie*te,ie/$.locationSize*le*te,Me)}}else if(q!==void 0){const ee=q[ne];if(ee!==void 0)switch(ee.length){case 2:i.vertexAttrib2fv($.location,ee);break;case 3:i.vertexAttrib3fv($.location,ee);break;case 4:i.vertexAttrib4fv($.location,ee);break;default:i.vertexAttrib1fv($.location,ee)}}}}E()}function O(){I();for(const y in n){const D=n[y];for(const V in D){const z=D[V];for(const X in z)h(z[X].object),delete z[X];delete D[V]}delete n[y]}}function P(y){if(n[y.id]===void 0)return;const D=n[y.id];for(const V in D){const z=D[V];for(const X in z)h(z[X].object),delete z[X];delete D[V]}delete n[y.id]}function L(y){for(const D in n){const V=n[D];if(V[y.id]===void 0)continue;const z=V[y.id];for(const X in z)h(z[X].object),delete z[X];delete V[y.id]}}function I(){S(),r=!0,a!==s&&(a=s,c(a.object))}function S(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:o,reset:I,resetDefaultState:S,dispose:O,releaseStatesOfGeometry:P,releaseStatesOfProgram:L,initAttributes:v,enableAttribute:f,disableUnusedAttributes:E}}function Bg(i,e,t){let n;function s(c){n=c}function a(c,h){i.drawArrays(n,c,h),t.update(h,n,1)}function r(c,h,d){d!==0&&(i.drawArraysInstanced(n,c,h,d),t.update(h,n,d))}function o(c,h,d){if(d===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,d);let m=0;for(let g=0;g<d;g++)m+=h[g];t.update(m,n,1)}function l(c,h,d,u){if(d===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let g=0;g<c.length;g++)r(c[g],h[g],u[g]);else{m.multiDrawArraysInstancedWEBGL(n,c,0,h,0,u,0,d);let g=0;for(let v=0;v<d;v++)g+=h[v]*u[v];t.update(g,n,1)}}this.setMode=s,this.render=a,this.renderInstances=r,this.renderMultiDraw=o,this.renderMultiDrawInstances=l}function zg(i,e,t,n){let s;function a(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const L=e.get("EXT_texture_filter_anisotropic");s=i.getParameter(L.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function r(L){return!(L!==vn&&n.convert(L)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(L){const I=L===Wn&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(L!==jn&&n.convert(L)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&L!==Gn&&!I)}function l(L){if(L==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";L="mediump"}return L==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);const d=t.logarithmicDepthBuffer===!0,u=t.reverseDepthBuffer===!0&&e.has("EXT_clip_control"),m=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=i.getParameter(i.MAX_TEXTURE_SIZE),f=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),p=i.getParameter(i.MAX_VERTEX_ATTRIBS),E=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),w=i.getParameter(i.MAX_VARYING_VECTORS),b=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),O=g>0,P=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:a,getMaxPrecision:l,textureFormatReadable:r,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:d,reverseDepthBuffer:u,maxTextures:m,maxVertexTextures:g,maxTextureSize:v,maxCubemapSize:f,maxAttributes:p,maxVertexUniforms:E,maxVaryings:w,maxFragmentUniforms:b,vertexTextures:O,maxSamples:P}}function Hg(i){const e=this;let t=null,n=0,s=!1,a=!1;const r=new Ei,o=new We,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(d,u){const m=d.length!==0||u||n!==0||s;return s=u,n=d.length,m},this.beginShadows=function(){a=!0,h(null)},this.endShadows=function(){a=!1},this.setGlobalState=function(d,u){t=h(d,u,0)},this.setState=function(d,u,m){const g=d.clippingPlanes,v=d.clipIntersection,f=d.clipShadows,p=i.get(d);if(!s||g===null||g.length===0||a&&!f)a?h(null):c();else{const E=a?0:n,w=E*4;let b=p.clippingState||null;l.value=b,b=h(g,u,w,m);for(let O=0;O!==w;++O)b[O]=t[O];p.clippingState=b,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=E}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function h(d,u,m,g){const v=d!==null?d.length:0;let f=null;if(v!==0){if(f=l.value,g!==!0||f===null){const p=m+v*4,E=u.matrixWorldInverse;o.getNormalMatrix(E),(f===null||f.length<p)&&(f=new Float32Array(p));for(let w=0,b=m;w!==v;++w,b+=4)r.copy(d[w]).applyMatrix4(E,o),r.normal.toArray(f,b),f[b+3]=r.constant}l.value=f,l.needsUpdate=!0}return e.numPlanes=v,e.numIntersection=0,f}}function Gg(i){let e=new WeakMap;function t(r,o){return o===Ro?r.mapping=gs:o===Po&&(r.mapping=vs),r}function n(r){if(r&&r.isTexture){const o=r.mapping;if(o===Ro||o===Po)if(e.has(r)){const l=e.get(r).texture;return t(l,r.mapping)}else{const l=r.image;if(l&&l.height>0){const c=new Qf(l.height);return c.fromEquirectangularTexture(i,r),e.set(r,c),r.addEventListener("dispose",s),t(c.texture,r.mapping)}else return null}}return r}function s(r){const o=r.target;o.removeEventListener("dispose",s);const l=e.get(o);l!==void 0&&(e.delete(o),l.dispose())}function a(){e=new WeakMap}return{get:n,dispose:a}}class Fl extends Th{constructor(e=-1,t=1,n=1,s=-1,a=.1,r=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=a,this.far=r,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,a,r){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=a,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let a=n-e,r=n+e,o=s+t,l=s-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;a+=c*this.view.offsetX,r=a+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(a,r,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const rs=4,Oc=[.125,.215,.35,.446,.526,.582],Ci=20,Qr=new Fl,Bc=new pe;let eo=null,to=0,no=0,io=!1;const Ti=(1+Math.sqrt(5))/2,Zi=1/Ti,zc=[new R(-Ti,Zi,0),new R(Ti,Zi,0),new R(-Zi,0,Ti),new R(Zi,0,Ti),new R(0,Ti,-Zi),new R(0,Ti,Zi),new R(-1,1,-1),new R(1,1,-1),new R(-1,1,1),new R(1,1,1)];class Hc{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,s=100){eo=this._renderer.getRenderTarget(),to=this._renderer.getActiveCubeFace(),no=this._renderer.getActiveMipmapLevel(),io=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);const a=this._allocateTargets();return a.depthBuffer=!0,this._sceneToCubeUV(e,n,s,a),t>0&&this._blur(a,0,0,t),this._applyPMREM(a),this._cleanup(a),a}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=$c(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Vc(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(eo,to,no),this._renderer.xr.enabled=io,e.scissorTest=!1,Na(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===gs||e.mapping===vs?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),eo=this._renderer.getRenderTarget(),to=this._renderer.getActiveCubeFace(),no=this._renderer.getActiveMipmapLevel(),io=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:Tn,minFilter:Tn,generateMipmaps:!1,type:Wn,format:vn,colorSpace:ws,depthBuffer:!1},s=Gc(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Gc(e,t,n);const{_lodMax:a}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Vg(a)),this._blurMaterial=$g(a,e,t)}return s}_compileMaterial(e){const t=new Ge(this._lodPlanes[0],e);this._renderer.compile(t,Qr)}_sceneToCubeUV(e,t,n,s){const o=new qt(90,1,t,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,d=h.autoClear,u=h.toneMapping;h.getClearColor(Bc),h.toneMapping=oi,h.autoClear=!1;const m=new kt({name:"PMREM.Background",side:jt,depthWrite:!1,depthTest:!1}),g=new Ge(new li,m);let v=!1;const f=e.background;f?f.isColor&&(m.color.copy(f),e.background=null,v=!0):(m.color.copy(Bc),v=!0);for(let p=0;p<6;p++){const E=p%3;E===0?(o.up.set(0,l[p],0),o.lookAt(c[p],0,0)):E===1?(o.up.set(0,0,l[p]),o.lookAt(0,c[p],0)):(o.up.set(0,l[p],0),o.lookAt(0,0,c[p]));const w=this._cubeSize;Na(s,E*w,p>2?w:0,w,w),h.setRenderTarget(s),v&&h.render(g,o),h.render(e,o)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=u,h.autoClear=d,e.background=f}_textureToCubeUV(e,t){const n=this._renderer,s=e.mapping===gs||e.mapping===vs;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=$c()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Vc());const a=s?this._cubemapMaterial:this._equirectMaterial,r=new Ge(this._lodPlanes[0],a),o=a.uniforms;o.envMap.value=e;const l=this._cubeSize;Na(t,0,0,3*l,2*l),n.setRenderTarget(t),n.render(r,Qr)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const s=this._lodPlanes.length;for(let a=1;a<s;a++){const r=Math.sqrt(this._sigmas[a]*this._sigmas[a]-this._sigmas[a-1]*this._sigmas[a-1]),o=zc[(s-a-1)%zc.length];this._blur(e,a-1,a,r,o)}t.autoClear=n}_blur(e,t,n,s,a){const r=this._pingPongRenderTarget;this._halfBlur(e,r,t,n,s,"latitudinal",a),this._halfBlur(r,e,n,n,s,"longitudinal",a)}_halfBlur(e,t,n,s,a,r,o){const l=this._renderer,c=this._blurMaterial;r!=="latitudinal"&&r!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const h=3,d=new Ge(this._lodPlanes[s],c),u=c.uniforms,m=this._sizeLods[n]-1,g=isFinite(a)?Math.PI/(2*m):2*Math.PI/(2*Ci-1),v=a/g,f=isFinite(a)?1+Math.floor(h*v):Ci;f>Ci&&console.warn(`sigmaRadians, ${a}, is too large and will clip, as it requested ${f} samples when the maximum is set to ${Ci}`);const p=[];let E=0;for(let L=0;L<Ci;++L){const I=L/v,S=Math.exp(-I*I/2);p.push(S),L===0?E+=S:L<f&&(E+=2*S)}for(let L=0;L<p.length;L++)p[L]=p[L]/E;u.envMap.value=e.texture,u.samples.value=f,u.weights.value=p,u.latitudinal.value=r==="latitudinal",o&&(u.poleAxis.value=o);const{_lodMax:w}=this;u.dTheta.value=g,u.mipInt.value=w-n;const b=this._sizeLods[s],O=3*b*(s>w-rs?s-w+rs:0),P=4*(this._cubeSize-b);Na(t,O,P,3*b,2*b),l.setRenderTarget(t),l.render(d,Qr)}}function Vg(i){const e=[],t=[],n=[];let s=i;const a=i-rs+1+Oc.length;for(let r=0;r<a;r++){const o=Math.pow(2,s);t.push(o);let l=1/o;r>i-rs?l=Oc[r-i+rs-1]:r===0&&(l=0),n.push(l);const c=1/(o-2),h=-c,d=1+c,u=[h,h,d,h,d,d,h,h,d,d,h,d],m=6,g=6,v=3,f=2,p=1,E=new Float32Array(v*g*m),w=new Float32Array(f*g*m),b=new Float32Array(p*g*m);for(let P=0;P<m;P++){const L=P%3*2/3-1,I=P>2?0:-1,S=[L,I,0,L+2/3,I,0,L+2/3,I+1,0,L,I,0,L+2/3,I+1,0,L,I+1,0];E.set(S,v*g*P),w.set(u,f*g*P);const y=[P,P,P,P,P,P];b.set(y,p*g*P)}const O=new bt;O.setAttribute("position",new Dt(E,v)),O.setAttribute("uv",new Dt(w,f)),O.setAttribute("faceIndex",new Dt(b,p)),e.push(O),s>rs&&s--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function Gc(i,e,t){const n=new xn(i,e,t);return n.texture.mapping=vr,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Na(i,e,t,n,s){i.viewport.set(e,t,n,s),i.scissor.set(e,t,n,s)}function $g(i,e,t){const n=new Float32Array(Ci),s=new R(0,1,0);return new Ot({name:"SphericalGaussianBlur",defines:{n:Ci,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:kl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function Vc(){return new Ot({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:kl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function $c(){return new Ot({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:kl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function kl(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Wg(i){let e=new WeakMap,t=null;function n(o){if(o&&o.isTexture){const l=o.mapping,c=l===Ro||l===Po,h=l===gs||l===vs;if(c||h){let d=e.get(o);const u=d!==void 0?d.texture.pmremVersion:0;if(o.isRenderTargetTexture&&o.pmremVersion!==u)return t===null&&(t=new Hc(i)),d=c?t.fromEquirectangular(o,d):t.fromCubemap(o,d),d.texture.pmremVersion=o.pmremVersion,e.set(o,d),d.texture;if(d!==void 0)return d.texture;{const m=o.image;return c&&m&&m.height>0||h&&m&&s(m)?(t===null&&(t=new Hc(i)),d=c?t.fromEquirectangular(o):t.fromCubemap(o),d.texture.pmremVersion=o.pmremVersion,e.set(o,d),o.addEventListener("dispose",a),d.texture):null}}}return o}function s(o){let l=0;const c=6;for(let h=0;h<c;h++)o[h]!==void 0&&l++;return l===c}function a(o){const l=o.target;l.removeEventListener("dispose",a);const c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function r(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:r}}function Xg(i){const e={};function t(n){if(e[n]!==void 0)return e[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const s=t(n);return s===null&&$s("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function qg(i,e,t,n){const s={},a=new WeakMap;function r(d){const u=d.target;u.index!==null&&e.remove(u.index);for(const g in u.attributes)e.remove(u.attributes[g]);for(const g in u.morphAttributes){const v=u.morphAttributes[g];for(let f=0,p=v.length;f<p;f++)e.remove(v[f])}u.removeEventListener("dispose",r),delete s[u.id];const m=a.get(u);m&&(e.remove(m),a.delete(u)),n.releaseStatesOfGeometry(u),u.isInstancedBufferGeometry===!0&&delete u._maxInstanceCount,t.memory.geometries--}function o(d,u){return s[u.id]===!0||(u.addEventListener("dispose",r),s[u.id]=!0,t.memory.geometries++),u}function l(d){const u=d.attributes;for(const g in u)e.update(u[g],i.ARRAY_BUFFER);const m=d.morphAttributes;for(const g in m){const v=m[g];for(let f=0,p=v.length;f<p;f++)e.update(v[f],i.ARRAY_BUFFER)}}function c(d){const u=[],m=d.index,g=d.attributes.position;let v=0;if(m!==null){const E=m.array;v=m.version;for(let w=0,b=E.length;w<b;w+=3){const O=E[w+0],P=E[w+1],L=E[w+2];u.push(O,P,P,L,L,O)}}else if(g!==void 0){const E=g.array;v=g.version;for(let w=0,b=E.length/3-1;w<b;w+=3){const O=w+0,P=w+1,L=w+2;u.push(O,P,P,L,L,O)}}else return;const f=new(_h(u)?wh:Sh)(u,1);f.version=v;const p=a.get(d);p&&e.remove(p),a.set(d,f)}function h(d){const u=a.get(d);if(u){const m=d.index;m!==null&&u.version<m.version&&c(d)}else c(d);return a.get(d)}return{get:o,update:l,getWireframeAttribute:h}}function Yg(i,e,t){let n;function s(u){n=u}let a,r;function o(u){a=u.type,r=u.bytesPerElement}function l(u,m){i.drawElements(n,m,a,u*r),t.update(m,n,1)}function c(u,m,g){g!==0&&(i.drawElementsInstanced(n,m,a,u*r,g),t.update(m,n,g))}function h(u,m,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,m,0,a,u,0,g);let f=0;for(let p=0;p<g;p++)f+=m[p];t.update(f,n,1)}function d(u,m,g,v){if(g===0)return;const f=e.get("WEBGL_multi_draw");if(f===null)for(let p=0;p<u.length;p++)c(u[p]/r,m[p],v[p]);else{f.multiDrawElementsInstancedWEBGL(n,m,0,a,u,0,v,0,g);let p=0;for(let E=0;E<g;E++)p+=m[E]*v[E];t.update(p,n,1)}}this.setMode=s,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=d}function jg(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(a,r,o){switch(t.calls++,r){case i.TRIANGLES:t.triangles+=o*(a/3);break;case i.LINES:t.lines+=o*(a/2);break;case i.LINE_STRIP:t.lines+=o*(a-1);break;case i.LINE_LOOP:t.lines+=o*a;break;case i.POINTS:t.points+=o*a;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",r);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function Kg(i,e,t){const n=new WeakMap,s=new dt;function a(r,o,l){const c=r.morphTargetInfluences,h=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,d=h!==void 0?h.length:0;let u=n.get(o);if(u===void 0||u.count!==d){let S=function(){L.dispose(),n.delete(o),o.removeEventListener("dispose",S)};u!==void 0&&u.texture.dispose();const m=o.morphAttributes.position!==void 0,g=o.morphAttributes.normal!==void 0,v=o.morphAttributes.color!==void 0,f=o.morphAttributes.position||[],p=o.morphAttributes.normal||[],E=o.morphAttributes.color||[];let w=0;m===!0&&(w=1),g===!0&&(w=2),v===!0&&(w=3);let b=o.attributes.position.count*w,O=1;b>e.maxTextureSize&&(O=Math.ceil(b/e.maxTextureSize),b=e.maxTextureSize);const P=new Float32Array(b*O*4*d),L=new yh(P,b,O,d);L.type=Gn,L.needsUpdate=!0;const I=w*4;for(let y=0;y<d;y++){const D=f[y],V=p[y],z=E[y],X=b*O*4*y;for(let J=0;J<D.count;J++){const q=J*I;m===!0&&(s.fromBufferAttribute(D,J),P[X+q+0]=s.x,P[X+q+1]=s.y,P[X+q+2]=s.z,P[X+q+3]=0),g===!0&&(s.fromBufferAttribute(V,J),P[X+q+4]=s.x,P[X+q+5]=s.y,P[X+q+6]=s.z,P[X+q+7]=0),v===!0&&(s.fromBufferAttribute(z,J),P[X+q+8]=s.x,P[X+q+9]=s.y,P[X+q+10]=s.z,P[X+q+11]=z.itemSize===4?s.w:1)}}u={count:d,texture:L,size:new Pe(b,O)},n.set(o,u),o.addEventListener("dispose",S)}if(r.isInstancedMesh===!0&&r.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",r.morphTexture,t);else{let m=0;for(let v=0;v<c.length;v++)m+=c[v];const g=o.morphTargetsRelative?1:1-m;l.getUniforms().setValue(i,"morphTargetBaseInfluence",g),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",u.texture,t),l.getUniforms().setValue(i,"morphTargetsTextureSize",u.size)}return{update:a}}function Zg(i,e,t,n){let s=new WeakMap;function a(l){const c=n.render.frame,h=l.geometry,d=e.get(l,h);if(s.get(d)!==c&&(e.update(d),s.set(d,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),s.get(l)!==c&&(t.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){const u=l.skeleton;s.get(u)!==c&&(u.update(),s.set(u,c))}return d}function r(){s=new WeakMap}function o(l){const c=l.target;c.removeEventListener("dispose",o),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:a,dispose:r}}class Rh extends Bt{constructor(e,t,n,s,a,r,o,l,c,h=ls){if(h!==ls&&h!==xs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===ls&&(n=Fi),n===void 0&&h===xs&&(n=_s),super(null,s,a,r,o,l,h,n,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=o!==void 0?o:_n,this.minFilter=l!==void 0?l:_n,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}const Ph=new Bt,Wc=new Rh(1,1),Lh=new yh,Dh=new Of,Ih=new Ah,Xc=[],qc=[],Yc=new Float32Array(16),jc=new Float32Array(9),Kc=new Float32Array(4);function As(i,e,t){const n=i[0];if(n<=0||n>0)return i;const s=e*t;let a=Xc[s];if(a===void 0&&(a=new Float32Array(s),Xc[s]=a),e!==0){n.toArray(a,0);for(let r=1,o=0;r!==e;++r)o+=t,i[r].toArray(a,o)}return a}function Rt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function Pt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function xr(i,e){let t=qc[e];t===void 0&&(t=new Int32Array(e),qc[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function Jg(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function Qg(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Rt(t,e))return;i.uniform2fv(this.addr,e),Pt(t,e)}}function e0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Rt(t,e))return;i.uniform3fv(this.addr,e),Pt(t,e)}}function t0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Rt(t,e))return;i.uniform4fv(this.addr,e),Pt(t,e)}}function n0(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Rt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),Pt(t,e)}else{if(Rt(t,n))return;Kc.set(n),i.uniformMatrix2fv(this.addr,!1,Kc),Pt(t,n)}}function i0(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Rt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),Pt(t,e)}else{if(Rt(t,n))return;jc.set(n),i.uniformMatrix3fv(this.addr,!1,jc),Pt(t,n)}}function s0(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Rt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),Pt(t,e)}else{if(Rt(t,n))return;Yc.set(n),i.uniformMatrix4fv(this.addr,!1,Yc),Pt(t,n)}}function a0(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function r0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Rt(t,e))return;i.uniform2iv(this.addr,e),Pt(t,e)}}function o0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Rt(t,e))return;i.uniform3iv(this.addr,e),Pt(t,e)}}function l0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Rt(t,e))return;i.uniform4iv(this.addr,e),Pt(t,e)}}function c0(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function d0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Rt(t,e))return;i.uniform2uiv(this.addr,e),Pt(t,e)}}function h0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Rt(t,e))return;i.uniform3uiv(this.addr,e),Pt(t,e)}}function u0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Rt(t,e))return;i.uniform4uiv(this.addr,e),Pt(t,e)}}function f0(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let a;this.type===i.SAMPLER_2D_SHADOW?(Wc.compareFunction=vh,a=Wc):a=Ph,t.setTexture2D(e||a,s)}function p0(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||Dh,s)}function m0(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTextureCube(e||Ih,s)}function g0(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||Lh,s)}function v0(i){switch(i){case 5126:return Jg;case 35664:return Qg;case 35665:return e0;case 35666:return t0;case 35674:return n0;case 35675:return i0;case 35676:return s0;case 5124:case 35670:return a0;case 35667:case 35671:return r0;case 35668:case 35672:return o0;case 35669:case 35673:return l0;case 5125:return c0;case 36294:return d0;case 36295:return h0;case 36296:return u0;case 35678:case 36198:case 36298:case 36306:case 35682:return f0;case 35679:case 36299:case 36307:return p0;case 35680:case 36300:case 36308:case 36293:return m0;case 36289:case 36303:case 36311:case 36292:return g0}}function _0(i,e){i.uniform1fv(this.addr,e)}function x0(i,e){const t=As(e,this.size,2);i.uniform2fv(this.addr,t)}function y0(i,e){const t=As(e,this.size,3);i.uniform3fv(this.addr,t)}function M0(i,e){const t=As(e,this.size,4);i.uniform4fv(this.addr,t)}function b0(i,e){const t=As(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function S0(i,e){const t=As(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function w0(i,e){const t=As(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function E0(i,e){i.uniform1iv(this.addr,e)}function T0(i,e){i.uniform2iv(this.addr,e)}function A0(i,e){i.uniform3iv(this.addr,e)}function C0(i,e){i.uniform4iv(this.addr,e)}function R0(i,e){i.uniform1uiv(this.addr,e)}function P0(i,e){i.uniform2uiv(this.addr,e)}function L0(i,e){i.uniform3uiv(this.addr,e)}function D0(i,e){i.uniform4uiv(this.addr,e)}function I0(i,e,t){const n=this.cache,s=e.length,a=xr(t,s);Rt(n,a)||(i.uniform1iv(this.addr,a),Pt(n,a));for(let r=0;r!==s;++r)t.setTexture2D(e[r]||Ph,a[r])}function U0(i,e,t){const n=this.cache,s=e.length,a=xr(t,s);Rt(n,a)||(i.uniform1iv(this.addr,a),Pt(n,a));for(let r=0;r!==s;++r)t.setTexture3D(e[r]||Dh,a[r])}function N0(i,e,t){const n=this.cache,s=e.length,a=xr(t,s);Rt(n,a)||(i.uniform1iv(this.addr,a),Pt(n,a));for(let r=0;r!==s;++r)t.setTextureCube(e[r]||Ih,a[r])}function F0(i,e,t){const n=this.cache,s=e.length,a=xr(t,s);Rt(n,a)||(i.uniform1iv(this.addr,a),Pt(n,a));for(let r=0;r!==s;++r)t.setTexture2DArray(e[r]||Lh,a[r])}function k0(i){switch(i){case 5126:return _0;case 35664:return x0;case 35665:return y0;case 35666:return M0;case 35674:return b0;case 35675:return S0;case 35676:return w0;case 5124:case 35670:return E0;case 35667:case 35671:return T0;case 35668:case 35672:return A0;case 35669:case 35673:return C0;case 5125:return R0;case 36294:return P0;case 36295:return L0;case 36296:return D0;case 35678:case 36198:case 36298:case 36306:case 35682:return I0;case 35679:case 36299:case 36307:return U0;case 35680:case 36300:case 36308:case 36293:return N0;case 36289:case 36303:case 36311:case 36292:return F0}}class O0{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=v0(t.type)}}class B0{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=k0(t.type)}}class z0{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const s=this.seq;for(let a=0,r=s.length;a!==r;++a){const o=s[a];o.setValue(e,t[o.id],n)}}}const so=/(\w+)(\])?(\[|\.)?/g;function Zc(i,e){i.seq.push(e),i.map[e.id]=e}function H0(i,e,t){const n=i.name,s=n.length;for(so.lastIndex=0;;){const a=so.exec(n),r=so.lastIndex;let o=a[1];const l=a[2]==="]",c=a[3];if(l&&(o=o|0),c===void 0||c==="["&&r+2===s){Zc(t,c===void 0?new O0(o,i,e):new B0(o,i,e));break}else{let d=t.map[o];d===void 0&&(d=new z0(o),Zc(t,d)),t=d}}}class er{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){const a=e.getActiveUniform(t,s),r=e.getUniformLocation(t,a.name);H0(a,r,this)}}setValue(e,t,n,s){const a=this.map[t];a!==void 0&&a.setValue(e,n,s)}setOptional(e,t,n){const s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let a=0,r=t.length;a!==r;++a){const o=t[a],l=n[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,s)}}static seqWithValue(e,t){const n=[];for(let s=0,a=e.length;s!==a;++s){const r=e[s];r.id in t&&n.push(r)}return n}}function Jc(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const G0=37297;let V0=0;function $0(i,e){const t=i.split(`
`),n=[],s=Math.max(e-6,0),a=Math.min(e+6,t.length);for(let r=s;r<a;r++){const o=r+1;n.push(`${o===e?">":" "} ${o}: ${t[r]}`)}return n.join(`
`)}const Qc=new We;function W0(i){Qe._getMatrix(Qc,Qe.workingColorSpace,i);const e=`mat3( ${Qc.elements.map(t=>t.toFixed(4))} )`;switch(Qe.getTransfer(i)){case _r:return[e,"LinearTransferOETF"];case ot:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function ed(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),s=i.getShaderInfoLog(e).trim();if(n&&s==="")return"";const a=/ERROR: 0:(\d+)/.exec(s);if(a){const r=parseInt(a[1]);return t.toUpperCase()+`

`+s+`

`+$0(i.getShaderSource(e),r)}else return s}function X0(i,e){const t=W0(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function q0(i,e){let t;switch(e){case eh:t="Linear";break;case th:t="Reinhard";break;case nh:t="Cineon";break;case Tl:t="ACESFilmic";break;case ih:t="AgX";break;case sh:t="Neutral";break;case tf:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const Fa=new R;function Y0(){Qe.getLuminanceCoefficients(Fa);const i=Fa.x.toFixed(4),e=Fa.y.toFixed(4),t=Fa.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function j0(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Ws).join(`
`)}function K0(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function Z0(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const a=i.getActiveAttrib(e,s),r=a.name;let o=1;a.type===i.FLOAT_MAT2&&(o=2),a.type===i.FLOAT_MAT3&&(o=3),a.type===i.FLOAT_MAT4&&(o=4),t[r]={type:a.type,location:i.getAttribLocation(e,r),locationSize:o}}return t}function Ws(i){return i!==""}function td(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function nd(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const J0=/^[ \t]*#include +<([\w\d./]+)>/gm;function rl(i){return i.replace(J0,ev)}const Q0=new Map;function ev(i,e){let t=qe[e];if(t===void 0){const n=Q0.get(e);if(n!==void 0)t=qe[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return rl(t)}const tv=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function id(i){return i.replace(tv,nv)}function nv(i,e,t,n){let s="";for(let a=parseInt(e);a<parseInt(t);a++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+a+" ]").replace(/UNROLLED_LOOP_INDEX/g,a);return s}function sd(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function iv(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Jd?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===Uu?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===On&&(e="SHADOWMAP_TYPE_VSM"),e}function sv(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case gs:case vs:e="ENVMAP_TYPE_CUBE";break;case vr:e="ENVMAP_TYPE_CUBE_UV";break}return e}function av(i){let e="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case vs:e="ENVMAP_MODE_REFRACTION";break}return e}function rv(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case Qd:e="ENVMAP_BLENDING_MULTIPLY";break;case Qu:e="ENVMAP_BLENDING_MIX";break;case ef:e="ENVMAP_BLENDING_ADD";break}return e}function ov(i){const e=i.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),7*16)),texelHeight:n,maxMip:t}}function lv(i,e,t,n){const s=i.getContext(),a=t.defines;let r=t.vertexShader,o=t.fragmentShader;const l=iv(t),c=sv(t),h=av(t),d=rv(t),u=ov(t),m=j0(t),g=K0(a),v=s.createProgram();let f,p,E=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Ws).join(`
`),f.length>0&&(f+=`
`),p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Ws).join(`
`),p.length>0&&(p+=`
`)):(f=[sd(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ws).join(`
`),p=[sd(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+d:"",u?"#define CUBEUV_TEXEL_WIDTH "+u.texelWidth:"",u?"#define CUBEUV_TEXEL_HEIGHT "+u.texelHeight:"",u?"#define CUBEUV_MAX_MIP "+u.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==oi?"#define TONE_MAPPING":"",t.toneMapping!==oi?qe.tonemapping_pars_fragment:"",t.toneMapping!==oi?q0("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",qe.colorspace_pars_fragment,X0("linearToOutputTexel",t.outputColorSpace),Y0(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Ws).join(`
`)),r=rl(r),r=td(r,t),r=nd(r,t),o=rl(o),o=td(o,t),o=nd(o,t),r=id(r),o=id(o),t.isRawShaderMaterial!==!0&&(E=`#version 300 es
`,f=[m,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,p=["#define varying in",t.glslVersion===gc?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===gc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);const w=E+f+r,b=E+p+o,O=Jc(s,s.VERTEX_SHADER,w),P=Jc(s,s.FRAGMENT_SHADER,b);s.attachShader(v,O),s.attachShader(v,P),t.index0AttributeName!==void 0?s.bindAttribLocation(v,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(v,0,"position"),s.linkProgram(v);function L(D){if(i.debug.checkShaderErrors){const V=s.getProgramInfoLog(v).trim(),z=s.getShaderInfoLog(O).trim(),X=s.getShaderInfoLog(P).trim();let J=!0,q=!0;if(s.getProgramParameter(v,s.LINK_STATUS)===!1)if(J=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,v,O,P);else{const ne=ed(s,O,"vertex"),$=ed(s,P,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(v,s.VALIDATE_STATUS)+`

Material Name: `+D.name+`
Material Type: `+D.type+`

Program Info Log: `+V+`
`+ne+`
`+$)}else V!==""?console.warn("THREE.WebGLProgram: Program Info Log:",V):(z===""||X==="")&&(q=!1);q&&(D.diagnostics={runnable:J,programLog:V,vertexShader:{log:z,prefix:f},fragmentShader:{log:X,prefix:p}})}s.deleteShader(O),s.deleteShader(P),I=new er(s,v),S=Z0(s,v)}let I;this.getUniforms=function(){return I===void 0&&L(this),I};let S;this.getAttributes=function(){return S===void 0&&L(this),S};let y=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return y===!1&&(y=s.getProgramParameter(v,G0)),y},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(v),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=V0++,this.cacheKey=e,this.usedTimes=1,this.program=v,this.vertexShader=O,this.fragmentShader=P,this}let cv=0;class dv{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,s=this._getShaderStage(t),a=this._getShaderStage(n),r=this._getShaderCacheForMaterial(e);return r.has(s)===!1&&(r.add(s),s.usedTimes++),r.has(a)===!1&&(r.add(a),a.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new hv(e),t.set(e,n)),n}}class hv{constructor(e){this.id=cv++,this.code=e,this.usedTimes=0}}function uv(i,e,t,n,s,a,r){const o=new Mh,l=new dv,c=new Set,h=[],d=s.logarithmicDepthBuffer,u=s.vertexTextures;let m=s.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function v(S){return c.add(S),S===0?"uv":`uv${S}`}function f(S,y,D,V,z){const X=V.fog,J=z.geometry,q=S.isMeshStandardMaterial?V.environment:null,ne=(S.isMeshStandardMaterial?t:e).get(S.envMap||q),$=ne&&ne.mapping===vr?ne.image.height:null,ce=g[S.type];S.precision!==null&&(m=s.getMaxPrecision(S.precision),m!==S.precision&&console.warn("THREE.WebGLProgram.getParameters:",S.precision,"not supported, using",m,"instead."));const ee=J.morphAttributes.position||J.morphAttributes.normal||J.morphAttributes.color,ie=ee!==void 0?ee.length:0;let ve=0;J.morphAttributes.position!==void 0&&(ve=1),J.morphAttributes.normal!==void 0&&(ve=2),J.morphAttributes.color!==void 0&&(ve=3);let Te,Y,te,Me;if(ce){const rt=Sn[ce];Te=rt.vertexShader,Y=rt.fragmentShader}else Te=S.vertexShader,Y=S.fragmentShader,l.update(S),te=l.getVertexShaderID(S),Me=l.getFragmentShaderID(S);const le=i.getRenderTarget(),De=i.state.buffers.depth.getReversed(),ze=z.isInstancedMesh===!0,Ye=z.isBatchedMesh===!0,yt=!!S.map,et=!!S.matcap,wt=!!ne,k=!!S.aoMap,sn=!!S.lightMap,Ke=!!S.bumpMap,Ze=!!S.normalMap,Ie=!!S.displacementMap,gt=!!S.emissiveMap,Le=!!S.metalnessMap,A=!!S.roughnessMap,_=S.anisotropy>0,B=S.clearcoat>0,K=S.dispersion>0,Q=S.iridescence>0,j=S.sheen>0,Ae=S.transmission>0,he=_&&!!S.anisotropyMap,ge=B&&!!S.clearcoatMap,tt=B&&!!S.clearcoatNormalMap,se=B&&!!S.clearcoatRoughnessMap,_e=Q&&!!S.iridescenceMap,Ue=Q&&!!S.iridescenceThicknessMap,Fe=j&&!!S.sheenColorMap,xe=j&&!!S.sheenRoughnessMap,Je=!!S.specularMap,Xe=!!S.specularColorMap,ut=!!S.specularIntensityMap,U=Ae&&!!S.transmissionMap,de=Ae&&!!S.thicknessMap,W=!!S.gradientMap,Z=!!S.alphaMap,me=S.alphaTest>0,ue=!!S.alphaHash,Ve=!!S.extensions;let St=oi;S.toneMapped&&(le===null||le.isXRRenderTarget===!0)&&(St=i.toneMapping);const Ut={shaderID:ce,shaderType:S.type,shaderName:S.name,vertexShader:Te,fragmentShader:Y,defines:S.defines,customVertexShaderID:te,customFragmentShaderID:Me,isRawShaderMaterial:S.isRawShaderMaterial===!0,glslVersion:S.glslVersion,precision:m,batching:Ye,batchingColor:Ye&&z._colorsTexture!==null,instancing:ze,instancingColor:ze&&z.instanceColor!==null,instancingMorph:ze&&z.morphTexture!==null,supportsVertexTextures:u,outputColorSpace:le===null?i.outputColorSpace:le.isXRRenderTarget===!0?le.texture.colorSpace:ws,alphaToCoverage:!!S.alphaToCoverage,map:yt,matcap:et,envMap:wt,envMapMode:wt&&ne.mapping,envMapCubeUVHeight:$,aoMap:k,lightMap:sn,bumpMap:Ke,normalMap:Ze,displacementMap:u&&Ie,emissiveMap:gt,normalMapObjectSpace:Ze&&S.normalMapType===rf,normalMapTangentSpace:Ze&&S.normalMapType===gh,metalnessMap:Le,roughnessMap:A,anisotropy:_,anisotropyMap:he,clearcoat:B,clearcoatMap:ge,clearcoatNormalMap:tt,clearcoatRoughnessMap:se,dispersion:K,iridescence:Q,iridescenceMap:_e,iridescenceThicknessMap:Ue,sheen:j,sheenColorMap:Fe,sheenRoughnessMap:xe,specularMap:Je,specularColorMap:Xe,specularIntensityMap:ut,transmission:Ae,transmissionMap:U,thicknessMap:de,gradientMap:W,opaque:S.transparent===!1&&S.blending===os&&S.alphaToCoverage===!1,alphaMap:Z,alphaTest:me,alphaHash:ue,combine:S.combine,mapUv:yt&&v(S.map.channel),aoMapUv:k&&v(S.aoMap.channel),lightMapUv:sn&&v(S.lightMap.channel),bumpMapUv:Ke&&v(S.bumpMap.channel),normalMapUv:Ze&&v(S.normalMap.channel),displacementMapUv:Ie&&v(S.displacementMap.channel),emissiveMapUv:gt&&v(S.emissiveMap.channel),metalnessMapUv:Le&&v(S.metalnessMap.channel),roughnessMapUv:A&&v(S.roughnessMap.channel),anisotropyMapUv:he&&v(S.anisotropyMap.channel),clearcoatMapUv:ge&&v(S.clearcoatMap.channel),clearcoatNormalMapUv:tt&&v(S.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:se&&v(S.clearcoatRoughnessMap.channel),iridescenceMapUv:_e&&v(S.iridescenceMap.channel),iridescenceThicknessMapUv:Ue&&v(S.iridescenceThicknessMap.channel),sheenColorMapUv:Fe&&v(S.sheenColorMap.channel),sheenRoughnessMapUv:xe&&v(S.sheenRoughnessMap.channel),specularMapUv:Je&&v(S.specularMap.channel),specularColorMapUv:Xe&&v(S.specularColorMap.channel),specularIntensityMapUv:ut&&v(S.specularIntensityMap.channel),transmissionMapUv:U&&v(S.transmissionMap.channel),thicknessMapUv:de&&v(S.thicknessMap.channel),alphaMapUv:Z&&v(S.alphaMap.channel),vertexTangents:!!J.attributes.tangent&&(Ze||_),vertexColors:S.vertexColors,vertexAlphas:S.vertexColors===!0&&!!J.attributes.color&&J.attributes.color.itemSize===4,pointsUvs:z.isPoints===!0&&!!J.attributes.uv&&(yt||Z),fog:!!X,useFog:S.fog===!0,fogExp2:!!X&&X.isFogExp2,flatShading:S.flatShading===!0,sizeAttenuation:S.sizeAttenuation===!0,logarithmicDepthBuffer:d,reverseDepthBuffer:De,skinning:z.isSkinnedMesh===!0,morphTargets:J.morphAttributes.position!==void 0,morphNormals:J.morphAttributes.normal!==void 0,morphColors:J.morphAttributes.color!==void 0,morphTargetsCount:ie,morphTextureStride:ve,numDirLights:y.directional.length,numPointLights:y.point.length,numSpotLights:y.spot.length,numSpotLightMaps:y.spotLightMap.length,numRectAreaLights:y.rectArea.length,numHemiLights:y.hemi.length,numDirLightShadows:y.directionalShadowMap.length,numPointLightShadows:y.pointShadowMap.length,numSpotLightShadows:y.spotShadowMap.length,numSpotLightShadowsWithMaps:y.numSpotLightShadowsWithMaps,numLightProbes:y.numLightProbes,numClippingPlanes:r.numPlanes,numClipIntersection:r.numIntersection,dithering:S.dithering,shadowMapEnabled:i.shadowMap.enabled&&D.length>0,shadowMapType:i.shadowMap.type,toneMapping:St,decodeVideoTexture:yt&&S.map.isVideoTexture===!0&&Qe.getTransfer(S.map.colorSpace)===ot,decodeVideoTextureEmissive:gt&&S.emissiveMap.isVideoTexture===!0&&Qe.getTransfer(S.emissiveMap.colorSpace)===ot,premultipliedAlpha:S.premultipliedAlpha,doubleSided:S.side===Yt,flipSided:S.side===jt,useDepthPacking:S.depthPacking>=0,depthPacking:S.depthPacking||0,index0AttributeName:S.index0AttributeName,extensionClipCullDistance:Ve&&S.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Ve&&S.extensions.multiDraw===!0||Ye)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:S.customProgramCacheKey()};return Ut.vertexUv1s=c.has(1),Ut.vertexUv2s=c.has(2),Ut.vertexUv3s=c.has(3),c.clear(),Ut}function p(S){const y=[];if(S.shaderID?y.push(S.shaderID):(y.push(S.customVertexShaderID),y.push(S.customFragmentShaderID)),S.defines!==void 0)for(const D in S.defines)y.push(D),y.push(S.defines[D]);return S.isRawShaderMaterial===!1&&(E(y,S),w(y,S),y.push(i.outputColorSpace)),y.push(S.customProgramCacheKey),y.join()}function E(S,y){S.push(y.precision),S.push(y.outputColorSpace),S.push(y.envMapMode),S.push(y.envMapCubeUVHeight),S.push(y.mapUv),S.push(y.alphaMapUv),S.push(y.lightMapUv),S.push(y.aoMapUv),S.push(y.bumpMapUv),S.push(y.normalMapUv),S.push(y.displacementMapUv),S.push(y.emissiveMapUv),S.push(y.metalnessMapUv),S.push(y.roughnessMapUv),S.push(y.anisotropyMapUv),S.push(y.clearcoatMapUv),S.push(y.clearcoatNormalMapUv),S.push(y.clearcoatRoughnessMapUv),S.push(y.iridescenceMapUv),S.push(y.iridescenceThicknessMapUv),S.push(y.sheenColorMapUv),S.push(y.sheenRoughnessMapUv),S.push(y.specularMapUv),S.push(y.specularColorMapUv),S.push(y.specularIntensityMapUv),S.push(y.transmissionMapUv),S.push(y.thicknessMapUv),S.push(y.combine),S.push(y.fogExp2),S.push(y.sizeAttenuation),S.push(y.morphTargetsCount),S.push(y.morphAttributeCount),S.push(y.numDirLights),S.push(y.numPointLights),S.push(y.numSpotLights),S.push(y.numSpotLightMaps),S.push(y.numHemiLights),S.push(y.numRectAreaLights),S.push(y.numDirLightShadows),S.push(y.numPointLightShadows),S.push(y.numSpotLightShadows),S.push(y.numSpotLightShadowsWithMaps),S.push(y.numLightProbes),S.push(y.shadowMapType),S.push(y.toneMapping),S.push(y.numClippingPlanes),S.push(y.numClipIntersection),S.push(y.depthPacking)}function w(S,y){o.disableAll(),y.supportsVertexTextures&&o.enable(0),y.instancing&&o.enable(1),y.instancingColor&&o.enable(2),y.instancingMorph&&o.enable(3),y.matcap&&o.enable(4),y.envMap&&o.enable(5),y.normalMapObjectSpace&&o.enable(6),y.normalMapTangentSpace&&o.enable(7),y.clearcoat&&o.enable(8),y.iridescence&&o.enable(9),y.alphaTest&&o.enable(10),y.vertexColors&&o.enable(11),y.vertexAlphas&&o.enable(12),y.vertexUv1s&&o.enable(13),y.vertexUv2s&&o.enable(14),y.vertexUv3s&&o.enable(15),y.vertexTangents&&o.enable(16),y.anisotropy&&o.enable(17),y.alphaHash&&o.enable(18),y.batching&&o.enable(19),y.dispersion&&o.enable(20),y.batchingColor&&o.enable(21),S.push(o.mask),o.disableAll(),y.fog&&o.enable(0),y.useFog&&o.enable(1),y.flatShading&&o.enable(2),y.logarithmicDepthBuffer&&o.enable(3),y.reverseDepthBuffer&&o.enable(4),y.skinning&&o.enable(5),y.morphTargets&&o.enable(6),y.morphNormals&&o.enable(7),y.morphColors&&o.enable(8),y.premultipliedAlpha&&o.enable(9),y.shadowMapEnabled&&o.enable(10),y.doubleSided&&o.enable(11),y.flipSided&&o.enable(12),y.useDepthPacking&&o.enable(13),y.dithering&&o.enable(14),y.transmission&&o.enable(15),y.sheen&&o.enable(16),y.opaque&&o.enable(17),y.pointsUvs&&o.enable(18),y.decodeVideoTexture&&o.enable(19),y.decodeVideoTextureEmissive&&o.enable(20),y.alphaToCoverage&&o.enable(21),S.push(o.mask)}function b(S){const y=g[S.type];let D;if(y){const V=Sn[y];D=na.clone(V.uniforms)}else D=S.uniforms;return D}function O(S,y){let D;for(let V=0,z=h.length;V<z;V++){const X=h[V];if(X.cacheKey===y){D=X,++D.usedTimes;break}}return D===void 0&&(D=new lv(i,y,S,a),h.push(D)),D}function P(S){if(--S.usedTimes===0){const y=h.indexOf(S);h[y]=h[h.length-1],h.pop(),S.destroy()}}function L(S){l.remove(S)}function I(){l.dispose()}return{getParameters:f,getProgramCacheKey:p,getUniforms:b,acquireProgram:O,releaseProgram:P,releaseShaderCache:L,programs:h,dispose:I}}function fv(){let i=new WeakMap;function e(r){return i.has(r)}function t(r){let o=i.get(r);return o===void 0&&(o={},i.set(r,o)),o}function n(r){i.delete(r)}function s(r,o,l){i.get(r)[o]=l}function a(){i=new WeakMap}return{has:e,get:t,remove:n,update:s,dispose:a}}function pv(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function ad(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function rd(){const i=[];let e=0;const t=[],n=[],s=[];function a(){e=0,t.length=0,n.length=0,s.length=0}function r(d,u,m,g,v,f){let p=i[e];return p===void 0?(p={id:d.id,object:d,geometry:u,material:m,groupOrder:g,renderOrder:d.renderOrder,z:v,group:f},i[e]=p):(p.id=d.id,p.object=d,p.geometry=u,p.material=m,p.groupOrder=g,p.renderOrder=d.renderOrder,p.z=v,p.group=f),e++,p}function o(d,u,m,g,v,f){const p=r(d,u,m,g,v,f);m.transmission>0?n.push(p):m.transparent===!0?s.push(p):t.push(p)}function l(d,u,m,g,v,f){const p=r(d,u,m,g,v,f);m.transmission>0?n.unshift(p):m.transparent===!0?s.unshift(p):t.unshift(p)}function c(d,u){t.length>1&&t.sort(d||pv),n.length>1&&n.sort(u||ad),s.length>1&&s.sort(u||ad)}function h(){for(let d=e,u=i.length;d<u;d++){const m=i[d];if(m.id===null)break;m.id=null,m.object=null,m.geometry=null,m.material=null,m.group=null}}return{opaque:t,transmissive:n,transparent:s,init:a,push:o,unshift:l,finish:h,sort:c}}function mv(){let i=new WeakMap;function e(n,s){const a=i.get(n);let r;return a===void 0?(r=new rd,i.set(n,[r])):s>=a.length?(r=new rd,a.push(r)):r=a[s],r}function t(){i=new WeakMap}return{get:e,dispose:t}}function gv(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new R,color:new pe};break;case"SpotLight":t={position:new R,direction:new R,color:new pe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new R,color:new pe,distance:0,decay:0};break;case"HemisphereLight":t={direction:new R,skyColor:new pe,groundColor:new pe};break;case"RectAreaLight":t={color:new pe,position:new R,halfWidth:new R,halfHeight:new R};break}return i[e.id]=t,t}}}function vv(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pe};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pe};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pe,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let _v=0;function xv(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function yv(i){const e=new gv,t=vv(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new R);const s=new R,a=new pt,r=new pt;function o(c){let h=0,d=0,u=0;for(let S=0;S<9;S++)n.probe[S].set(0,0,0);let m=0,g=0,v=0,f=0,p=0,E=0,w=0,b=0,O=0,P=0,L=0;c.sort(xv);for(let S=0,y=c.length;S<y;S++){const D=c[S],V=D.color,z=D.intensity,X=D.distance,J=D.shadow&&D.shadow.map?D.shadow.map.texture:null;if(D.isAmbientLight)h+=V.r*z,d+=V.g*z,u+=V.b*z;else if(D.isLightProbe){for(let q=0;q<9;q++)n.probe[q].addScaledVector(D.sh.coefficients[q],z);L++}else if(D.isDirectionalLight){const q=e.get(D);if(q.color.copy(D.color).multiplyScalar(D.intensity),D.castShadow){const ne=D.shadow,$=t.get(D);$.shadowIntensity=ne.intensity,$.shadowBias=ne.bias,$.shadowNormalBias=ne.normalBias,$.shadowRadius=ne.radius,$.shadowMapSize=ne.mapSize,n.directionalShadow[m]=$,n.directionalShadowMap[m]=J,n.directionalShadowMatrix[m]=D.shadow.matrix,E++}n.directional[m]=q,m++}else if(D.isSpotLight){const q=e.get(D);q.position.setFromMatrixPosition(D.matrixWorld),q.color.copy(V).multiplyScalar(z),q.distance=X,q.coneCos=Math.cos(D.angle),q.penumbraCos=Math.cos(D.angle*(1-D.penumbra)),q.decay=D.decay,n.spot[v]=q;const ne=D.shadow;if(D.map&&(n.spotLightMap[O]=D.map,O++,ne.updateMatrices(D),D.castShadow&&P++),n.spotLightMatrix[v]=ne.matrix,D.castShadow){const $=t.get(D);$.shadowIntensity=ne.intensity,$.shadowBias=ne.bias,$.shadowNormalBias=ne.normalBias,$.shadowRadius=ne.radius,$.shadowMapSize=ne.mapSize,n.spotShadow[v]=$,n.spotShadowMap[v]=J,b++}v++}else if(D.isRectAreaLight){const q=e.get(D);q.color.copy(V).multiplyScalar(z),q.halfWidth.set(D.width*.5,0,0),q.halfHeight.set(0,D.height*.5,0),n.rectArea[f]=q,f++}else if(D.isPointLight){const q=e.get(D);if(q.color.copy(D.color).multiplyScalar(D.intensity),q.distance=D.distance,q.decay=D.decay,D.castShadow){const ne=D.shadow,$=t.get(D);$.shadowIntensity=ne.intensity,$.shadowBias=ne.bias,$.shadowNormalBias=ne.normalBias,$.shadowRadius=ne.radius,$.shadowMapSize=ne.mapSize,$.shadowCameraNear=ne.camera.near,$.shadowCameraFar=ne.camera.far,n.pointShadow[g]=$,n.pointShadowMap[g]=J,n.pointShadowMatrix[g]=D.shadow.matrix,w++}n.point[g]=q,g++}else if(D.isHemisphereLight){const q=e.get(D);q.skyColor.copy(D.color).multiplyScalar(z),q.groundColor.copy(D.groundColor).multiplyScalar(z),n.hemi[p]=q,p++}}f>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=oe.LTC_FLOAT_1,n.rectAreaLTC2=oe.LTC_FLOAT_2):(n.rectAreaLTC1=oe.LTC_HALF_1,n.rectAreaLTC2=oe.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=d,n.ambient[2]=u;const I=n.hash;(I.directionalLength!==m||I.pointLength!==g||I.spotLength!==v||I.rectAreaLength!==f||I.hemiLength!==p||I.numDirectionalShadows!==E||I.numPointShadows!==w||I.numSpotShadows!==b||I.numSpotMaps!==O||I.numLightProbes!==L)&&(n.directional.length=m,n.spot.length=v,n.rectArea.length=f,n.point.length=g,n.hemi.length=p,n.directionalShadow.length=E,n.directionalShadowMap.length=E,n.pointShadow.length=w,n.pointShadowMap.length=w,n.spotShadow.length=b,n.spotShadowMap.length=b,n.directionalShadowMatrix.length=E,n.pointShadowMatrix.length=w,n.spotLightMatrix.length=b+O-P,n.spotLightMap.length=O,n.numSpotLightShadowsWithMaps=P,n.numLightProbes=L,I.directionalLength=m,I.pointLength=g,I.spotLength=v,I.rectAreaLength=f,I.hemiLength=p,I.numDirectionalShadows=E,I.numPointShadows=w,I.numSpotShadows=b,I.numSpotMaps=O,I.numLightProbes=L,n.version=_v++)}function l(c,h){let d=0,u=0,m=0,g=0,v=0;const f=h.matrixWorldInverse;for(let p=0,E=c.length;p<E;p++){const w=c[p];if(w.isDirectionalLight){const b=n.directional[d];b.direction.setFromMatrixPosition(w.matrixWorld),s.setFromMatrixPosition(w.target.matrixWorld),b.direction.sub(s),b.direction.transformDirection(f),d++}else if(w.isSpotLight){const b=n.spot[m];b.position.setFromMatrixPosition(w.matrixWorld),b.position.applyMatrix4(f),b.direction.setFromMatrixPosition(w.matrixWorld),s.setFromMatrixPosition(w.target.matrixWorld),b.direction.sub(s),b.direction.transformDirection(f),m++}else if(w.isRectAreaLight){const b=n.rectArea[g];b.position.setFromMatrixPosition(w.matrixWorld),b.position.applyMatrix4(f),r.identity(),a.copy(w.matrixWorld),a.premultiply(f),r.extractRotation(a),b.halfWidth.set(w.width*.5,0,0),b.halfHeight.set(0,w.height*.5,0),b.halfWidth.applyMatrix4(r),b.halfHeight.applyMatrix4(r),g++}else if(w.isPointLight){const b=n.point[u];b.position.setFromMatrixPosition(w.matrixWorld),b.position.applyMatrix4(f),u++}else if(w.isHemisphereLight){const b=n.hemi[v];b.direction.setFromMatrixPosition(w.matrixWorld),b.direction.transformDirection(f),v++}}}return{setup:o,setupView:l,state:n}}function od(i){const e=new yv(i),t=[],n=[];function s(h){c.camera=h,t.length=0,n.length=0}function a(h){t.push(h)}function r(h){n.push(h)}function o(){e.setup(t)}function l(h){e.setupView(t,h)}const c={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:s,state:c,setupLights:o,setupLightsView:l,pushLight:a,pushShadow:r}}function Mv(i){let e=new WeakMap;function t(s,a=0){const r=e.get(s);let o;return r===void 0?(o=new od(i),e.set(s,[o])):a>=r.length?(o=new od(i),r.push(o)):o=r[a],o}function n(){e=new WeakMap}return{get:t,dispose:n}}class bv extends fi{static get type(){return"MeshDepthMaterial"}constructor(e){super(),this.isMeshDepthMaterial=!0,this.depthPacking=sf,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Sv extends fi{static get type(){return"MeshDistanceMaterial"}constructor(e){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const wv=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Ev=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function Tv(i,e,t){let n=new Nl;const s=new Pe,a=new Pe,r=new dt,o=new bv({depthPacking:af}),l=new Sv,c={},h=t.maxTextureSize,d={[Yn]:jt,[jt]:Yn,[Yt]:Yt},u=new Ot({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Pe},radius:{value:4}},vertexShader:wv,fragmentShader:Ev}),m=u.clone();m.defines.HORIZONTAL_PASS=1;const g=new bt;g.setAttribute("position",new Dt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new Ge(g,u),f=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Jd;let p=this.type;this.render=function(P,L,I){if(f.enabled===!1||f.autoUpdate===!1&&f.needsUpdate===!1||P.length===0)return;const S=i.getRenderTarget(),y=i.getActiveCubeFace(),D=i.getActiveMipmapLevel(),V=i.state;V.setBlending($n),V.buffers.color.setClear(1,1,1,1),V.buffers.depth.setTest(!0),V.setScissorTest(!1);const z=p!==On&&this.type===On,X=p===On&&this.type!==On;for(let J=0,q=P.length;J<q;J++){const ne=P[J],$=ne.shadow;if($===void 0){console.warn("THREE.WebGLShadowMap:",ne,"has no shadow.");continue}if($.autoUpdate===!1&&$.needsUpdate===!1)continue;s.copy($.mapSize);const ce=$.getFrameExtents();if(s.multiply(ce),a.copy($.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(a.x=Math.floor(h/ce.x),s.x=a.x*ce.x,$.mapSize.x=a.x),s.y>h&&(a.y=Math.floor(h/ce.y),s.y=a.y*ce.y,$.mapSize.y=a.y)),$.map===null||z===!0||X===!0){const ie=this.type!==On?{minFilter:_n,magFilter:_n}:{};$.map!==null&&$.map.dispose(),$.map=new xn(s.x,s.y,ie),$.map.texture.name=ne.name+".shadowMap",$.camera.updateProjectionMatrix()}i.setRenderTarget($.map),i.clear();const ee=$.getViewportCount();for(let ie=0;ie<ee;ie++){const ve=$.getViewport(ie);r.set(a.x*ve.x,a.y*ve.y,a.x*ve.z,a.y*ve.w),V.viewport(r),$.updateMatrices(ne,ie),n=$.getFrustum(),b(L,I,$.camera,ne,this.type)}$.isPointLightShadow!==!0&&this.type===On&&E($,I),$.needsUpdate=!1}p=this.type,f.needsUpdate=!1,i.setRenderTarget(S,y,D)};function E(P,L){const I=e.update(v);u.defines.VSM_SAMPLES!==P.blurSamples&&(u.defines.VSM_SAMPLES=P.blurSamples,m.defines.VSM_SAMPLES=P.blurSamples,u.needsUpdate=!0,m.needsUpdate=!0),P.mapPass===null&&(P.mapPass=new xn(s.x,s.y)),u.uniforms.shadow_pass.value=P.map.texture,u.uniforms.resolution.value=P.mapSize,u.uniforms.radius.value=P.radius,i.setRenderTarget(P.mapPass),i.clear(),i.renderBufferDirect(L,null,I,u,v,null),m.uniforms.shadow_pass.value=P.mapPass.texture,m.uniforms.resolution.value=P.mapSize,m.uniforms.radius.value=P.radius,i.setRenderTarget(P.map),i.clear(),i.renderBufferDirect(L,null,I,m,v,null)}function w(P,L,I,S){let y=null;const D=I.isPointLight===!0?P.customDistanceMaterial:P.customDepthMaterial;if(D!==void 0)y=D;else if(y=I.isPointLight===!0?l:o,i.localClippingEnabled&&L.clipShadows===!0&&Array.isArray(L.clippingPlanes)&&L.clippingPlanes.length!==0||L.displacementMap&&L.displacementScale!==0||L.alphaMap&&L.alphaTest>0||L.map&&L.alphaTest>0){const V=y.uuid,z=L.uuid;let X=c[V];X===void 0&&(X={},c[V]=X);let J=X[z];J===void 0&&(J=y.clone(),X[z]=J,L.addEventListener("dispose",O)),y=J}if(y.visible=L.visible,y.wireframe=L.wireframe,S===On?y.side=L.shadowSide!==null?L.shadowSide:L.side:y.side=L.shadowSide!==null?L.shadowSide:d[L.side],y.alphaMap=L.alphaMap,y.alphaTest=L.alphaTest,y.map=L.map,y.clipShadows=L.clipShadows,y.clippingPlanes=L.clippingPlanes,y.clipIntersection=L.clipIntersection,y.displacementMap=L.displacementMap,y.displacementScale=L.displacementScale,y.displacementBias=L.displacementBias,y.wireframeLinewidth=L.wireframeLinewidth,y.linewidth=L.linewidth,I.isPointLight===!0&&y.isMeshDistanceMaterial===!0){const V=i.properties.get(y);V.light=I}return y}function b(P,L,I,S,y){if(P.visible===!1)return;if(P.layers.test(L.layers)&&(P.isMesh||P.isLine||P.isPoints)&&(P.castShadow||P.receiveShadow&&y===On)&&(!P.frustumCulled||n.intersectsObject(P))){P.modelViewMatrix.multiplyMatrices(I.matrixWorldInverse,P.matrixWorld);const z=e.update(P),X=P.material;if(Array.isArray(X)){const J=z.groups;for(let q=0,ne=J.length;q<ne;q++){const $=J[q],ce=X[$.materialIndex];if(ce&&ce.visible){const ee=w(P,ce,S,y);P.onBeforeShadow(i,P,L,I,z,ee,$),i.renderBufferDirect(I,null,z,ee,P,$),P.onAfterShadow(i,P,L,I,z,ee,$)}}}else if(X.visible){const J=w(P,X,S,y);P.onBeforeShadow(i,P,L,I,z,J,null),i.renderBufferDirect(I,null,z,J,P,null),P.onAfterShadow(i,P,L,I,z,J,null)}}const V=P.children;for(let z=0,X=V.length;z<X;z++)b(V[z],L,I,S,y)}function O(P){P.target.removeEventListener("dispose",O);for(const I in c){const S=c[I],y=P.target.uuid;y in S&&(S[y].dispose(),delete S[y])}}}const Av={[bo]:So,[wo]:Ao,[Eo]:Co,[ms]:To,[So]:bo,[Ao]:wo,[Co]:Eo,[To]:ms};function Cv(i,e){function t(){let U=!1;const de=new dt;let W=null;const Z=new dt(0,0,0,0);return{setMask:function(me){W!==me&&!U&&(i.colorMask(me,me,me,me),W=me)},setLocked:function(me){U=me},setClear:function(me,ue,Ve,St,Ut){Ut===!0&&(me*=St,ue*=St,Ve*=St),de.set(me,ue,Ve,St),Z.equals(de)===!1&&(i.clearColor(me,ue,Ve,St),Z.copy(de))},reset:function(){U=!1,W=null,Z.set(-1,0,0,0)}}}function n(){let U=!1,de=!1,W=null,Z=null,me=null;return{setReversed:function(ue){if(de!==ue){const Ve=e.get("EXT_clip_control");de?Ve.clipControlEXT(Ve.LOWER_LEFT_EXT,Ve.ZERO_TO_ONE_EXT):Ve.clipControlEXT(Ve.LOWER_LEFT_EXT,Ve.NEGATIVE_ONE_TO_ONE_EXT);const St=me;me=null,this.setClear(St)}de=ue},getReversed:function(){return de},setTest:function(ue){ue?le(i.DEPTH_TEST):De(i.DEPTH_TEST)},setMask:function(ue){W!==ue&&!U&&(i.depthMask(ue),W=ue)},setFunc:function(ue){if(de&&(ue=Av[ue]),Z!==ue){switch(ue){case bo:i.depthFunc(i.NEVER);break;case So:i.depthFunc(i.ALWAYS);break;case wo:i.depthFunc(i.LESS);break;case ms:i.depthFunc(i.LEQUAL);break;case Eo:i.depthFunc(i.EQUAL);break;case To:i.depthFunc(i.GEQUAL);break;case Ao:i.depthFunc(i.GREATER);break;case Co:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}Z=ue}},setLocked:function(ue){U=ue},setClear:function(ue){me!==ue&&(de&&(ue=1-ue),i.clearDepth(ue),me=ue)},reset:function(){U=!1,W=null,Z=null,me=null,de=!1}}}function s(){let U=!1,de=null,W=null,Z=null,me=null,ue=null,Ve=null,St=null,Ut=null;return{setTest:function(rt){U||(rt?le(i.STENCIL_TEST):De(i.STENCIL_TEST))},setMask:function(rt){de!==rt&&!U&&(i.stencilMask(rt),de=rt)},setFunc:function(rt,cn,Pn){(W!==rt||Z!==cn||me!==Pn)&&(i.stencilFunc(rt,cn,Pn),W=rt,Z=cn,me=Pn)},setOp:function(rt,cn,Pn){(ue!==rt||Ve!==cn||St!==Pn)&&(i.stencilOp(rt,cn,Pn),ue=rt,Ve=cn,St=Pn)},setLocked:function(rt){U=rt},setClear:function(rt){Ut!==rt&&(i.clearStencil(rt),Ut=rt)},reset:function(){U=!1,de=null,W=null,Z=null,me=null,ue=null,Ve=null,St=null,Ut=null}}}const a=new t,r=new n,o=new s,l=new WeakMap,c=new WeakMap;let h={},d={},u=new WeakMap,m=[],g=null,v=!1,f=null,p=null,E=null,w=null,b=null,O=null,P=null,L=new pe(0,0,0),I=0,S=!1,y=null,D=null,V=null,z=null,X=null;const J=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let q=!1,ne=0;const $=i.getParameter(i.VERSION);$.indexOf("WebGL")!==-1?(ne=parseFloat(/^WebGL (\d)/.exec($)[1]),q=ne>=1):$.indexOf("OpenGL ES")!==-1&&(ne=parseFloat(/^OpenGL ES (\d)/.exec($)[1]),q=ne>=2);let ce=null,ee={};const ie=i.getParameter(i.SCISSOR_BOX),ve=i.getParameter(i.VIEWPORT),Te=new dt().fromArray(ie),Y=new dt().fromArray(ve);function te(U,de,W,Z){const me=new Uint8Array(4),ue=i.createTexture();i.bindTexture(U,ue),i.texParameteri(U,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(U,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Ve=0;Ve<W;Ve++)U===i.TEXTURE_3D||U===i.TEXTURE_2D_ARRAY?i.texImage3D(de,0,i.RGBA,1,1,Z,0,i.RGBA,i.UNSIGNED_BYTE,me):i.texImage2D(de+Ve,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,me);return ue}const Me={};Me[i.TEXTURE_2D]=te(i.TEXTURE_2D,i.TEXTURE_2D,1),Me[i.TEXTURE_CUBE_MAP]=te(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Me[i.TEXTURE_2D_ARRAY]=te(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Me[i.TEXTURE_3D]=te(i.TEXTURE_3D,i.TEXTURE_3D,1,1),a.setClear(0,0,0,1),r.setClear(1),o.setClear(0),le(i.DEPTH_TEST),r.setFunc(ms),Ke(!1),Ze(uc),le(i.CULL_FACE),k($n);function le(U){h[U]!==!0&&(i.enable(U),h[U]=!0)}function De(U){h[U]!==!1&&(i.disable(U),h[U]=!1)}function ze(U,de){return d[U]!==de?(i.bindFramebuffer(U,de),d[U]=de,U===i.DRAW_FRAMEBUFFER&&(d[i.FRAMEBUFFER]=de),U===i.FRAMEBUFFER&&(d[i.DRAW_FRAMEBUFFER]=de),!0):!1}function Ye(U,de){let W=m,Z=!1;if(U){W=u.get(de),W===void 0&&(W=[],u.set(de,W));const me=U.textures;if(W.length!==me.length||W[0]!==i.COLOR_ATTACHMENT0){for(let ue=0,Ve=me.length;ue<Ve;ue++)W[ue]=i.COLOR_ATTACHMENT0+ue;W.length=me.length,Z=!0}}else W[0]!==i.BACK&&(W[0]=i.BACK,Z=!0);Z&&i.drawBuffers(W)}function yt(U){return g!==U?(i.useProgram(U),g=U,!0):!1}const et={[Ai]:i.FUNC_ADD,[Fu]:i.FUNC_SUBTRACT,[ku]:i.FUNC_REVERSE_SUBTRACT};et[Ou]=i.MIN,et[Bu]=i.MAX;const wt={[zu]:i.ZERO,[Hu]:i.ONE,[Gu]:i.SRC_COLOR,[yo]:i.SRC_ALPHA,[Yu]:i.SRC_ALPHA_SATURATE,[Xu]:i.DST_COLOR,[$u]:i.DST_ALPHA,[Vu]:i.ONE_MINUS_SRC_COLOR,[Mo]:i.ONE_MINUS_SRC_ALPHA,[qu]:i.ONE_MINUS_DST_COLOR,[Wu]:i.ONE_MINUS_DST_ALPHA,[ju]:i.CONSTANT_COLOR,[Ku]:i.ONE_MINUS_CONSTANT_COLOR,[Zu]:i.CONSTANT_ALPHA,[Ju]:i.ONE_MINUS_CONSTANT_ALPHA};function k(U,de,W,Z,me,ue,Ve,St,Ut,rt){if(U===$n){v===!0&&(De(i.BLEND),v=!1);return}if(v===!1&&(le(i.BLEND),v=!0),U!==Nu){if(U!==f||rt!==S){if((p!==Ai||b!==Ai)&&(i.blendEquation(i.FUNC_ADD),p=Ai,b=Ai),rt)switch(U){case os:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Vt:i.blendFunc(i.ONE,i.ONE);break;case fc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case pc:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}else switch(U){case os:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Vt:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case fc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case pc:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}E=null,w=null,O=null,P=null,L.set(0,0,0),I=0,f=U,S=rt}return}me=me||de,ue=ue||W,Ve=Ve||Z,(de!==p||me!==b)&&(i.blendEquationSeparate(et[de],et[me]),p=de,b=me),(W!==E||Z!==w||ue!==O||Ve!==P)&&(i.blendFuncSeparate(wt[W],wt[Z],wt[ue],wt[Ve]),E=W,w=Z,O=ue,P=Ve),(St.equals(L)===!1||Ut!==I)&&(i.blendColor(St.r,St.g,St.b,Ut),L.copy(St),I=Ut),f=U,S=!1}function sn(U,de){U.side===Yt?De(i.CULL_FACE):le(i.CULL_FACE);let W=U.side===jt;de&&(W=!W),Ke(W),U.blending===os&&U.transparent===!1?k($n):k(U.blending,U.blendEquation,U.blendSrc,U.blendDst,U.blendEquationAlpha,U.blendSrcAlpha,U.blendDstAlpha,U.blendColor,U.blendAlpha,U.premultipliedAlpha),r.setFunc(U.depthFunc),r.setTest(U.depthTest),r.setMask(U.depthWrite),a.setMask(U.colorWrite);const Z=U.stencilWrite;o.setTest(Z),Z&&(o.setMask(U.stencilWriteMask),o.setFunc(U.stencilFunc,U.stencilRef,U.stencilFuncMask),o.setOp(U.stencilFail,U.stencilZFail,U.stencilZPass)),gt(U.polygonOffset,U.polygonOffsetFactor,U.polygonOffsetUnits),U.alphaToCoverage===!0?le(i.SAMPLE_ALPHA_TO_COVERAGE):De(i.SAMPLE_ALPHA_TO_COVERAGE)}function Ke(U){y!==U&&(U?i.frontFace(i.CW):i.frontFace(i.CCW),y=U)}function Ze(U){U!==Du?(le(i.CULL_FACE),U!==D&&(U===uc?i.cullFace(i.BACK):U===Iu?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):De(i.CULL_FACE),D=U}function Ie(U){U!==V&&(q&&i.lineWidth(U),V=U)}function gt(U,de,W){U?(le(i.POLYGON_OFFSET_FILL),(z!==de||X!==W)&&(i.polygonOffset(de,W),z=de,X=W)):De(i.POLYGON_OFFSET_FILL)}function Le(U){U?le(i.SCISSOR_TEST):De(i.SCISSOR_TEST)}function A(U){U===void 0&&(U=i.TEXTURE0+J-1),ce!==U&&(i.activeTexture(U),ce=U)}function _(U,de,W){W===void 0&&(ce===null?W=i.TEXTURE0+J-1:W=ce);let Z=ee[W];Z===void 0&&(Z={type:void 0,texture:void 0},ee[W]=Z),(Z.type!==U||Z.texture!==de)&&(ce!==W&&(i.activeTexture(W),ce=W),i.bindTexture(U,de||Me[U]),Z.type=U,Z.texture=de)}function B(){const U=ee[ce];U!==void 0&&U.type!==void 0&&(i.bindTexture(U.type,null),U.type=void 0,U.texture=void 0)}function K(){try{i.compressedTexImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Q(){try{i.compressedTexImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function j(){try{i.texSubImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Ae(){try{i.texSubImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function he(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function ge(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function tt(){try{i.texStorage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function se(){try{i.texStorage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function _e(){try{i.texImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Ue(){try{i.texImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Fe(U){Te.equals(U)===!1&&(i.scissor(U.x,U.y,U.z,U.w),Te.copy(U))}function xe(U){Y.equals(U)===!1&&(i.viewport(U.x,U.y,U.z,U.w),Y.copy(U))}function Je(U,de){let W=c.get(de);W===void 0&&(W=new WeakMap,c.set(de,W));let Z=W.get(U);Z===void 0&&(Z=i.getUniformBlockIndex(de,U.name),W.set(U,Z))}function Xe(U,de){const Z=c.get(de).get(U);l.get(de)!==Z&&(i.uniformBlockBinding(de,Z,U.__bindingPointIndex),l.set(de,Z))}function ut(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),r.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),h={},ce=null,ee={},d={},u=new WeakMap,m=[],g=null,v=!1,f=null,p=null,E=null,w=null,b=null,O=null,P=null,L=new pe(0,0,0),I=0,S=!1,y=null,D=null,V=null,z=null,X=null,Te.set(0,0,i.canvas.width,i.canvas.height),Y.set(0,0,i.canvas.width,i.canvas.height),a.reset(),r.reset(),o.reset()}return{buffers:{color:a,depth:r,stencil:o},enable:le,disable:De,bindFramebuffer:ze,drawBuffers:Ye,useProgram:yt,setBlending:k,setMaterial:sn,setFlipSided:Ke,setCullFace:Ze,setLineWidth:Ie,setPolygonOffset:gt,setScissorTest:Le,activeTexture:A,bindTexture:_,unbindTexture:B,compressedTexImage2D:K,compressedTexImage3D:Q,texImage2D:_e,texImage3D:Ue,updateUBOMapping:Je,uniformBlockBinding:Xe,texStorage2D:tt,texStorage3D:se,texSubImage2D:j,texSubImage3D:Ae,compressedTexSubImage2D:he,compressedTexSubImage3D:ge,scissor:Fe,viewport:xe,reset:ut}}function ld(i,e,t,n){const s=Rv(n);switch(t){case ch:return i*e;case hh:return i*e;case uh:return i*e*2;case fh:return i*e/s.components*s.byteLength;case Pl:return i*e/s.components*s.byteLength;case ph:return i*e*2/s.components*s.byteLength;case Ll:return i*e*2/s.components*s.byteLength;case dh:return i*e*3/s.components*s.byteLength;case vn:return i*e*4/s.components*s.byteLength;case Dl:return i*e*4/s.components*s.byteLength;case ja:case Ka:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Za:case Ja:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Uo:case Fo:return Math.max(i,16)*Math.max(e,8)/4;case Io:case No:return Math.max(i,8)*Math.max(e,8)/2;case ko:case Oo:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Bo:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case zo:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Ho:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case Go:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case Vo:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case $o:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case Wo:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case Xo:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case qo:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case Yo:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case jo:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Ko:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case Zo:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Jo:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Qo:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case Qa:case el:case tl:return Math.ceil(i/4)*Math.ceil(e/4)*16;case mh:case nl:return Math.ceil(i/4)*Math.ceil(e/4)*8;case il:case sl:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Rv(i){switch(i){case jn:case rh:return{byteLength:1,components:1};case Js:case oh:case Wn:return{byteLength:2,components:1};case Cl:case Rl:return{byteLength:2,components:4};case Fi:case Al:case Gn:return{byteLength:4,components:1};case lh:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}function Pv(i,e,t,n,s,a,r){const o=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Pe,h=new WeakMap;let d;const u=new WeakMap;let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(A,_){return m?new OffscreenCanvas(A,_):ta("canvas")}function v(A,_,B){let K=1;const Q=Le(A);if((Q.width>B||Q.height>B)&&(K=B/Math.max(Q.width,Q.height)),K<1)if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap||typeof VideoFrame<"u"&&A instanceof VideoFrame){const j=Math.floor(K*Q.width),Ae=Math.floor(K*Q.height);d===void 0&&(d=g(j,Ae));const he=_?g(j,Ae):d;return he.width=j,he.height=Ae,he.getContext("2d").drawImage(A,0,0,j,Ae),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+Q.width+"x"+Q.height+") to ("+j+"x"+Ae+")."),he}else return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+Q.width+"x"+Q.height+")."),A;return A}function f(A){return A.generateMipmaps}function p(A){i.generateMipmap(A)}function E(A){return A.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:A.isWebGL3DRenderTarget?i.TEXTURE_3D:A.isWebGLArrayRenderTarget||A.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function w(A,_,B,K,Q=!1){if(A!==null){if(i[A]!==void 0)return i[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let j=_;if(_===i.RED&&(B===i.FLOAT&&(j=i.R32F),B===i.HALF_FLOAT&&(j=i.R16F),B===i.UNSIGNED_BYTE&&(j=i.R8)),_===i.RED_INTEGER&&(B===i.UNSIGNED_BYTE&&(j=i.R8UI),B===i.UNSIGNED_SHORT&&(j=i.R16UI),B===i.UNSIGNED_INT&&(j=i.R32UI),B===i.BYTE&&(j=i.R8I),B===i.SHORT&&(j=i.R16I),B===i.INT&&(j=i.R32I)),_===i.RG&&(B===i.FLOAT&&(j=i.RG32F),B===i.HALF_FLOAT&&(j=i.RG16F),B===i.UNSIGNED_BYTE&&(j=i.RG8)),_===i.RG_INTEGER&&(B===i.UNSIGNED_BYTE&&(j=i.RG8UI),B===i.UNSIGNED_SHORT&&(j=i.RG16UI),B===i.UNSIGNED_INT&&(j=i.RG32UI),B===i.BYTE&&(j=i.RG8I),B===i.SHORT&&(j=i.RG16I),B===i.INT&&(j=i.RG32I)),_===i.RGB_INTEGER&&(B===i.UNSIGNED_BYTE&&(j=i.RGB8UI),B===i.UNSIGNED_SHORT&&(j=i.RGB16UI),B===i.UNSIGNED_INT&&(j=i.RGB32UI),B===i.BYTE&&(j=i.RGB8I),B===i.SHORT&&(j=i.RGB16I),B===i.INT&&(j=i.RGB32I)),_===i.RGBA_INTEGER&&(B===i.UNSIGNED_BYTE&&(j=i.RGBA8UI),B===i.UNSIGNED_SHORT&&(j=i.RGBA16UI),B===i.UNSIGNED_INT&&(j=i.RGBA32UI),B===i.BYTE&&(j=i.RGBA8I),B===i.SHORT&&(j=i.RGBA16I),B===i.INT&&(j=i.RGBA32I)),_===i.RGB&&B===i.UNSIGNED_INT_5_9_9_9_REV&&(j=i.RGB9_E5),_===i.RGBA){const Ae=Q?_r:Qe.getTransfer(K);B===i.FLOAT&&(j=i.RGBA32F),B===i.HALF_FLOAT&&(j=i.RGBA16F),B===i.UNSIGNED_BYTE&&(j=Ae===ot?i.SRGB8_ALPHA8:i.RGBA8),B===i.UNSIGNED_SHORT_4_4_4_4&&(j=i.RGBA4),B===i.UNSIGNED_SHORT_5_5_5_1&&(j=i.RGB5_A1)}return(j===i.R16F||j===i.R32F||j===i.RG16F||j===i.RG32F||j===i.RGBA16F||j===i.RGBA32F)&&e.get("EXT_color_buffer_float"),j}function b(A,_){let B;return A?_===null||_===Fi||_===_s?B=i.DEPTH24_STENCIL8:_===Gn?B=i.DEPTH32F_STENCIL8:_===Js&&(B=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):_===null||_===Fi||_===_s?B=i.DEPTH_COMPONENT24:_===Gn?B=i.DEPTH_COMPONENT32F:_===Js&&(B=i.DEPTH_COMPONENT16),B}function O(A,_){return f(A)===!0||A.isFramebufferTexture&&A.minFilter!==_n&&A.minFilter!==Tn?Math.log2(Math.max(_.width,_.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?_.mipmaps.length:1}function P(A){const _=A.target;_.removeEventListener("dispose",P),I(_),_.isVideoTexture&&h.delete(_)}function L(A){const _=A.target;_.removeEventListener("dispose",L),y(_)}function I(A){const _=n.get(A);if(_.__webglInit===void 0)return;const B=A.source,K=u.get(B);if(K){const Q=K[_.__cacheKey];Q.usedTimes--,Q.usedTimes===0&&S(A),Object.keys(K).length===0&&u.delete(B)}n.remove(A)}function S(A){const _=n.get(A);i.deleteTexture(_.__webglTexture);const B=A.source,K=u.get(B);delete K[_.__cacheKey],r.memory.textures--}function y(A){const _=n.get(A);if(A.depthTexture&&(A.depthTexture.dispose(),n.remove(A.depthTexture)),A.isWebGLCubeRenderTarget)for(let K=0;K<6;K++){if(Array.isArray(_.__webglFramebuffer[K]))for(let Q=0;Q<_.__webglFramebuffer[K].length;Q++)i.deleteFramebuffer(_.__webglFramebuffer[K][Q]);else i.deleteFramebuffer(_.__webglFramebuffer[K]);_.__webglDepthbuffer&&i.deleteRenderbuffer(_.__webglDepthbuffer[K])}else{if(Array.isArray(_.__webglFramebuffer))for(let K=0;K<_.__webglFramebuffer.length;K++)i.deleteFramebuffer(_.__webglFramebuffer[K]);else i.deleteFramebuffer(_.__webglFramebuffer);if(_.__webglDepthbuffer&&i.deleteRenderbuffer(_.__webglDepthbuffer),_.__webglMultisampledFramebuffer&&i.deleteFramebuffer(_.__webglMultisampledFramebuffer),_.__webglColorRenderbuffer)for(let K=0;K<_.__webglColorRenderbuffer.length;K++)_.__webglColorRenderbuffer[K]&&i.deleteRenderbuffer(_.__webglColorRenderbuffer[K]);_.__webglDepthRenderbuffer&&i.deleteRenderbuffer(_.__webglDepthRenderbuffer)}const B=A.textures;for(let K=0,Q=B.length;K<Q;K++){const j=n.get(B[K]);j.__webglTexture&&(i.deleteTexture(j.__webglTexture),r.memory.textures--),n.remove(B[K])}n.remove(A)}let D=0;function V(){D=0}function z(){const A=D;return A>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+s.maxTextures),D+=1,A}function X(A){const _=[];return _.push(A.wrapS),_.push(A.wrapT),_.push(A.wrapR||0),_.push(A.magFilter),_.push(A.minFilter),_.push(A.anisotropy),_.push(A.internalFormat),_.push(A.format),_.push(A.type),_.push(A.generateMipmaps),_.push(A.premultiplyAlpha),_.push(A.flipY),_.push(A.unpackAlignment),_.push(A.colorSpace),_.join()}function J(A,_){const B=n.get(A);if(A.isVideoTexture&&Ie(A),A.isRenderTargetTexture===!1&&A.version>0&&B.__version!==A.version){const K=A.image;if(K===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(K.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Y(B,A,_);return}}t.bindTexture(i.TEXTURE_2D,B.__webglTexture,i.TEXTURE0+_)}function q(A,_){const B=n.get(A);if(A.version>0&&B.__version!==A.version){Y(B,A,_);return}t.bindTexture(i.TEXTURE_2D_ARRAY,B.__webglTexture,i.TEXTURE0+_)}function ne(A,_){const B=n.get(A);if(A.version>0&&B.__version!==A.version){Y(B,A,_);return}t.bindTexture(i.TEXTURE_3D,B.__webglTexture,i.TEXTURE0+_)}function $(A,_){const B=n.get(A);if(A.version>0&&B.__version!==A.version){te(B,A,_);return}t.bindTexture(i.TEXTURE_CUBE_MAP,B.__webglTexture,i.TEXTURE0+_)}const ce={[Lo]:i.REPEAT,[Li]:i.CLAMP_TO_EDGE,[Do]:i.MIRRORED_REPEAT},ee={[_n]:i.NEAREST,[nf]:i.NEAREST_MIPMAP_NEAREST,[ga]:i.NEAREST_MIPMAP_LINEAR,[Tn]:i.LINEAR,[Lr]:i.LINEAR_MIPMAP_NEAREST,[Di]:i.LINEAR_MIPMAP_LINEAR},ie={[of]:i.NEVER,[ff]:i.ALWAYS,[lf]:i.LESS,[vh]:i.LEQUAL,[cf]:i.EQUAL,[uf]:i.GEQUAL,[df]:i.GREATER,[hf]:i.NOTEQUAL};function ve(A,_){if(_.type===Gn&&e.has("OES_texture_float_linear")===!1&&(_.magFilter===Tn||_.magFilter===Lr||_.magFilter===ga||_.magFilter===Di||_.minFilter===Tn||_.minFilter===Lr||_.minFilter===ga||_.minFilter===Di)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(A,i.TEXTURE_WRAP_S,ce[_.wrapS]),i.texParameteri(A,i.TEXTURE_WRAP_T,ce[_.wrapT]),(A===i.TEXTURE_3D||A===i.TEXTURE_2D_ARRAY)&&i.texParameteri(A,i.TEXTURE_WRAP_R,ce[_.wrapR]),i.texParameteri(A,i.TEXTURE_MAG_FILTER,ee[_.magFilter]),i.texParameteri(A,i.TEXTURE_MIN_FILTER,ee[_.minFilter]),_.compareFunction&&(i.texParameteri(A,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(A,i.TEXTURE_COMPARE_FUNC,ie[_.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(_.magFilter===_n||_.minFilter!==ga&&_.minFilter!==Di||_.type===Gn&&e.has("OES_texture_float_linear")===!1)return;if(_.anisotropy>1||n.get(_).__currentAnisotropy){const B=e.get("EXT_texture_filter_anisotropic");i.texParameterf(A,B.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,s.getMaxAnisotropy())),n.get(_).__currentAnisotropy=_.anisotropy}}}function Te(A,_){let B=!1;A.__webglInit===void 0&&(A.__webglInit=!0,_.addEventListener("dispose",P));const K=_.source;let Q=u.get(K);Q===void 0&&(Q={},u.set(K,Q));const j=X(_);if(j!==A.__cacheKey){Q[j]===void 0&&(Q[j]={texture:i.createTexture(),usedTimes:0},r.memory.textures++,B=!0),Q[j].usedTimes++;const Ae=Q[A.__cacheKey];Ae!==void 0&&(Q[A.__cacheKey].usedTimes--,Ae.usedTimes===0&&S(_)),A.__cacheKey=j,A.__webglTexture=Q[j].texture}return B}function Y(A,_,B){let K=i.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(K=i.TEXTURE_2D_ARRAY),_.isData3DTexture&&(K=i.TEXTURE_3D);const Q=Te(A,_),j=_.source;t.bindTexture(K,A.__webglTexture,i.TEXTURE0+B);const Ae=n.get(j);if(j.version!==Ae.__version||Q===!0){t.activeTexture(i.TEXTURE0+B);const he=Qe.getPrimaries(Qe.workingColorSpace),ge=_.colorSpace===si?null:Qe.getPrimaries(_.colorSpace),tt=_.colorSpace===si||he===ge?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,_.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,_.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,tt);let se=v(_.image,!1,s.maxTextureSize);se=gt(_,se);const _e=a.convert(_.format,_.colorSpace),Ue=a.convert(_.type);let Fe=w(_.internalFormat,_e,Ue,_.colorSpace,_.isVideoTexture);ve(K,_);let xe;const Je=_.mipmaps,Xe=_.isVideoTexture!==!0,ut=Ae.__version===void 0||Q===!0,U=j.dataReady,de=O(_,se);if(_.isDepthTexture)Fe=b(_.format===xs,_.type),ut&&(Xe?t.texStorage2D(i.TEXTURE_2D,1,Fe,se.width,se.height):t.texImage2D(i.TEXTURE_2D,0,Fe,se.width,se.height,0,_e,Ue,null));else if(_.isDataTexture)if(Je.length>0){Xe&&ut&&t.texStorage2D(i.TEXTURE_2D,de,Fe,Je[0].width,Je[0].height);for(let W=0,Z=Je.length;W<Z;W++)xe=Je[W],Xe?U&&t.texSubImage2D(i.TEXTURE_2D,W,0,0,xe.width,xe.height,_e,Ue,xe.data):t.texImage2D(i.TEXTURE_2D,W,Fe,xe.width,xe.height,0,_e,Ue,xe.data);_.generateMipmaps=!1}else Xe?(ut&&t.texStorage2D(i.TEXTURE_2D,de,Fe,se.width,se.height),U&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,se.width,se.height,_e,Ue,se.data)):t.texImage2D(i.TEXTURE_2D,0,Fe,se.width,se.height,0,_e,Ue,se.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){Xe&&ut&&t.texStorage3D(i.TEXTURE_2D_ARRAY,de,Fe,Je[0].width,Je[0].height,se.depth);for(let W=0,Z=Je.length;W<Z;W++)if(xe=Je[W],_.format!==vn)if(_e!==null)if(Xe){if(U)if(_.layerUpdates.size>0){const me=ld(xe.width,xe.height,_.format,_.type);for(const ue of _.layerUpdates){const Ve=xe.data.subarray(ue*me/xe.data.BYTES_PER_ELEMENT,(ue+1)*me/xe.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,W,0,0,ue,xe.width,xe.height,1,_e,Ve)}_.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,W,0,0,0,xe.width,xe.height,se.depth,_e,xe.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,W,Fe,xe.width,xe.height,se.depth,0,xe.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Xe?U&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,W,0,0,0,xe.width,xe.height,se.depth,_e,Ue,xe.data):t.texImage3D(i.TEXTURE_2D_ARRAY,W,Fe,xe.width,xe.height,se.depth,0,_e,Ue,xe.data)}else{Xe&&ut&&t.texStorage2D(i.TEXTURE_2D,de,Fe,Je[0].width,Je[0].height);for(let W=0,Z=Je.length;W<Z;W++)xe=Je[W],_.format!==vn?_e!==null?Xe?U&&t.compressedTexSubImage2D(i.TEXTURE_2D,W,0,0,xe.width,xe.height,_e,xe.data):t.compressedTexImage2D(i.TEXTURE_2D,W,Fe,xe.width,xe.height,0,xe.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Xe?U&&t.texSubImage2D(i.TEXTURE_2D,W,0,0,xe.width,xe.height,_e,Ue,xe.data):t.texImage2D(i.TEXTURE_2D,W,Fe,xe.width,xe.height,0,_e,Ue,xe.data)}else if(_.isDataArrayTexture)if(Xe){if(ut&&t.texStorage3D(i.TEXTURE_2D_ARRAY,de,Fe,se.width,se.height,se.depth),U)if(_.layerUpdates.size>0){const W=ld(se.width,se.height,_.format,_.type);for(const Z of _.layerUpdates){const me=se.data.subarray(Z*W/se.data.BYTES_PER_ELEMENT,(Z+1)*W/se.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Z,se.width,se.height,1,_e,Ue,me)}_.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,se.width,se.height,se.depth,_e,Ue,se.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Fe,se.width,se.height,se.depth,0,_e,Ue,se.data);else if(_.isData3DTexture)Xe?(ut&&t.texStorage3D(i.TEXTURE_3D,de,Fe,se.width,se.height,se.depth),U&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,se.width,se.height,se.depth,_e,Ue,se.data)):t.texImage3D(i.TEXTURE_3D,0,Fe,se.width,se.height,se.depth,0,_e,Ue,se.data);else if(_.isFramebufferTexture){if(ut)if(Xe)t.texStorage2D(i.TEXTURE_2D,de,Fe,se.width,se.height);else{let W=se.width,Z=se.height;for(let me=0;me<de;me++)t.texImage2D(i.TEXTURE_2D,me,Fe,W,Z,0,_e,Ue,null),W>>=1,Z>>=1}}else if(Je.length>0){if(Xe&&ut){const W=Le(Je[0]);t.texStorage2D(i.TEXTURE_2D,de,Fe,W.width,W.height)}for(let W=0,Z=Je.length;W<Z;W++)xe=Je[W],Xe?U&&t.texSubImage2D(i.TEXTURE_2D,W,0,0,_e,Ue,xe):t.texImage2D(i.TEXTURE_2D,W,Fe,_e,Ue,xe);_.generateMipmaps=!1}else if(Xe){if(ut){const W=Le(se);t.texStorage2D(i.TEXTURE_2D,de,Fe,W.width,W.height)}U&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,_e,Ue,se)}else t.texImage2D(i.TEXTURE_2D,0,Fe,_e,Ue,se);f(_)&&p(K),Ae.__version=j.version,_.onUpdate&&_.onUpdate(_)}A.__version=_.version}function te(A,_,B){if(_.image.length!==6)return;const K=Te(A,_),Q=_.source;t.bindTexture(i.TEXTURE_CUBE_MAP,A.__webglTexture,i.TEXTURE0+B);const j=n.get(Q);if(Q.version!==j.__version||K===!0){t.activeTexture(i.TEXTURE0+B);const Ae=Qe.getPrimaries(Qe.workingColorSpace),he=_.colorSpace===si?null:Qe.getPrimaries(_.colorSpace),ge=_.colorSpace===si||Ae===he?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,_.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,_.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,ge);const tt=_.isCompressedTexture||_.image[0].isCompressedTexture,se=_.image[0]&&_.image[0].isDataTexture,_e=[];for(let Z=0;Z<6;Z++)!tt&&!se?_e[Z]=v(_.image[Z],!0,s.maxCubemapSize):_e[Z]=se?_.image[Z].image:_.image[Z],_e[Z]=gt(_,_e[Z]);const Ue=_e[0],Fe=a.convert(_.format,_.colorSpace),xe=a.convert(_.type),Je=w(_.internalFormat,Fe,xe,_.colorSpace),Xe=_.isVideoTexture!==!0,ut=j.__version===void 0||K===!0,U=Q.dataReady;let de=O(_,Ue);ve(i.TEXTURE_CUBE_MAP,_);let W;if(tt){Xe&&ut&&t.texStorage2D(i.TEXTURE_CUBE_MAP,de,Je,Ue.width,Ue.height);for(let Z=0;Z<6;Z++){W=_e[Z].mipmaps;for(let me=0;me<W.length;me++){const ue=W[me];_.format!==vn?Fe!==null?Xe?U&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,me,0,0,ue.width,ue.height,Fe,ue.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,me,Je,ue.width,ue.height,0,ue.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Xe?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,me,0,0,ue.width,ue.height,Fe,xe,ue.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,me,Je,ue.width,ue.height,0,Fe,xe,ue.data)}}}else{if(W=_.mipmaps,Xe&&ut){W.length>0&&de++;const Z=Le(_e[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,de,Je,Z.width,Z.height)}for(let Z=0;Z<6;Z++)if(se){Xe?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,_e[Z].width,_e[Z].height,Fe,xe,_e[Z].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,Je,_e[Z].width,_e[Z].height,0,Fe,xe,_e[Z].data);for(let me=0;me<W.length;me++){const Ve=W[me].image[Z].image;Xe?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,me+1,0,0,Ve.width,Ve.height,Fe,xe,Ve.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,me+1,Je,Ve.width,Ve.height,0,Fe,xe,Ve.data)}}else{Xe?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,Fe,xe,_e[Z]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,Je,Fe,xe,_e[Z]);for(let me=0;me<W.length;me++){const ue=W[me];Xe?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,me+1,0,0,Fe,xe,ue.image[Z]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,me+1,Je,Fe,xe,ue.image[Z])}}}f(_)&&p(i.TEXTURE_CUBE_MAP),j.__version=Q.version,_.onUpdate&&_.onUpdate(_)}A.__version=_.version}function Me(A,_,B,K,Q,j){const Ae=a.convert(B.format,B.colorSpace),he=a.convert(B.type),ge=w(B.internalFormat,Ae,he,B.colorSpace),tt=n.get(_),se=n.get(B);if(se.__renderTarget=_,!tt.__hasExternalTextures){const _e=Math.max(1,_.width>>j),Ue=Math.max(1,_.height>>j);Q===i.TEXTURE_3D||Q===i.TEXTURE_2D_ARRAY?t.texImage3D(Q,j,ge,_e,Ue,_.depth,0,Ae,he,null):t.texImage2D(Q,j,ge,_e,Ue,0,Ae,he,null)}t.bindFramebuffer(i.FRAMEBUFFER,A),Ze(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,K,Q,se.__webglTexture,0,Ke(_)):(Q===i.TEXTURE_2D||Q>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&Q<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,K,Q,se.__webglTexture,j),t.bindFramebuffer(i.FRAMEBUFFER,null)}function le(A,_,B){if(i.bindRenderbuffer(i.RENDERBUFFER,A),_.depthBuffer){const K=_.depthTexture,Q=K&&K.isDepthTexture?K.type:null,j=b(_.stencilBuffer,Q),Ae=_.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,he=Ke(_);Ze(_)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,he,j,_.width,_.height):B?i.renderbufferStorageMultisample(i.RENDERBUFFER,he,j,_.width,_.height):i.renderbufferStorage(i.RENDERBUFFER,j,_.width,_.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,Ae,i.RENDERBUFFER,A)}else{const K=_.textures;for(let Q=0;Q<K.length;Q++){const j=K[Q],Ae=a.convert(j.format,j.colorSpace),he=a.convert(j.type),ge=w(j.internalFormat,Ae,he,j.colorSpace),tt=Ke(_);B&&Ze(_)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,tt,ge,_.width,_.height):Ze(_)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,tt,ge,_.width,_.height):i.renderbufferStorage(i.RENDERBUFFER,ge,_.width,_.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function De(A,_){if(_&&_.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,A),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const K=n.get(_.depthTexture);K.__renderTarget=_,(!K.__webglTexture||_.depthTexture.image.width!==_.width||_.depthTexture.image.height!==_.height)&&(_.depthTexture.image.width=_.width,_.depthTexture.image.height=_.height,_.depthTexture.needsUpdate=!0),J(_.depthTexture,0);const Q=K.__webglTexture,j=Ke(_);if(_.depthTexture.format===ls)Ze(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,Q,0,j):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,Q,0);else if(_.depthTexture.format===xs)Ze(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,Q,0,j):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,Q,0);else throw new Error("Unknown depthTexture format")}function ze(A){const _=n.get(A),B=A.isWebGLCubeRenderTarget===!0;if(_.__boundDepthTexture!==A.depthTexture){const K=A.depthTexture;if(_.__depthDisposeCallback&&_.__depthDisposeCallback(),K){const Q=()=>{delete _.__boundDepthTexture,delete _.__depthDisposeCallback,K.removeEventListener("dispose",Q)};K.addEventListener("dispose",Q),_.__depthDisposeCallback=Q}_.__boundDepthTexture=K}if(A.depthTexture&&!_.__autoAllocateDepthBuffer){if(B)throw new Error("target.depthTexture not supported in Cube render targets");De(_.__webglFramebuffer,A)}else if(B){_.__webglDepthbuffer=[];for(let K=0;K<6;K++)if(t.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer[K]),_.__webglDepthbuffer[K]===void 0)_.__webglDepthbuffer[K]=i.createRenderbuffer(),le(_.__webglDepthbuffer[K],A,!1);else{const Q=A.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,j=_.__webglDepthbuffer[K];i.bindRenderbuffer(i.RENDERBUFFER,j),i.framebufferRenderbuffer(i.FRAMEBUFFER,Q,i.RENDERBUFFER,j)}}else if(t.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer===void 0)_.__webglDepthbuffer=i.createRenderbuffer(),le(_.__webglDepthbuffer,A,!1);else{const K=A.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Q=_.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,Q),i.framebufferRenderbuffer(i.FRAMEBUFFER,K,i.RENDERBUFFER,Q)}t.bindFramebuffer(i.FRAMEBUFFER,null)}function Ye(A,_,B){const K=n.get(A);_!==void 0&&Me(K.__webglFramebuffer,A,A.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),B!==void 0&&ze(A)}function yt(A){const _=A.texture,B=n.get(A),K=n.get(_);A.addEventListener("dispose",L);const Q=A.textures,j=A.isWebGLCubeRenderTarget===!0,Ae=Q.length>1;if(Ae||(K.__webglTexture===void 0&&(K.__webglTexture=i.createTexture()),K.__version=_.version,r.memory.textures++),j){B.__webglFramebuffer=[];for(let he=0;he<6;he++)if(_.mipmaps&&_.mipmaps.length>0){B.__webglFramebuffer[he]=[];for(let ge=0;ge<_.mipmaps.length;ge++)B.__webglFramebuffer[he][ge]=i.createFramebuffer()}else B.__webglFramebuffer[he]=i.createFramebuffer()}else{if(_.mipmaps&&_.mipmaps.length>0){B.__webglFramebuffer=[];for(let he=0;he<_.mipmaps.length;he++)B.__webglFramebuffer[he]=i.createFramebuffer()}else B.__webglFramebuffer=i.createFramebuffer();if(Ae)for(let he=0,ge=Q.length;he<ge;he++){const tt=n.get(Q[he]);tt.__webglTexture===void 0&&(tt.__webglTexture=i.createTexture(),r.memory.textures++)}if(A.samples>0&&Ze(A)===!1){B.__webglMultisampledFramebuffer=i.createFramebuffer(),B.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,B.__webglMultisampledFramebuffer);for(let he=0;he<Q.length;he++){const ge=Q[he];B.__webglColorRenderbuffer[he]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,B.__webglColorRenderbuffer[he]);const tt=a.convert(ge.format,ge.colorSpace),se=a.convert(ge.type),_e=w(ge.internalFormat,tt,se,ge.colorSpace,A.isXRRenderTarget===!0),Ue=Ke(A);i.renderbufferStorageMultisample(i.RENDERBUFFER,Ue,_e,A.width,A.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+he,i.RENDERBUFFER,B.__webglColorRenderbuffer[he])}i.bindRenderbuffer(i.RENDERBUFFER,null),A.depthBuffer&&(B.__webglDepthRenderbuffer=i.createRenderbuffer(),le(B.__webglDepthRenderbuffer,A,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(j){t.bindTexture(i.TEXTURE_CUBE_MAP,K.__webglTexture),ve(i.TEXTURE_CUBE_MAP,_);for(let he=0;he<6;he++)if(_.mipmaps&&_.mipmaps.length>0)for(let ge=0;ge<_.mipmaps.length;ge++)Me(B.__webglFramebuffer[he][ge],A,_,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+he,ge);else Me(B.__webglFramebuffer[he],A,_,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+he,0);f(_)&&p(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(Ae){for(let he=0,ge=Q.length;he<ge;he++){const tt=Q[he],se=n.get(tt);t.bindTexture(i.TEXTURE_2D,se.__webglTexture),ve(i.TEXTURE_2D,tt),Me(B.__webglFramebuffer,A,tt,i.COLOR_ATTACHMENT0+he,i.TEXTURE_2D,0),f(tt)&&p(i.TEXTURE_2D)}t.unbindTexture()}else{let he=i.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(he=A.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(he,K.__webglTexture),ve(he,_),_.mipmaps&&_.mipmaps.length>0)for(let ge=0;ge<_.mipmaps.length;ge++)Me(B.__webglFramebuffer[ge],A,_,i.COLOR_ATTACHMENT0,he,ge);else Me(B.__webglFramebuffer,A,_,i.COLOR_ATTACHMENT0,he,0);f(_)&&p(he),t.unbindTexture()}A.depthBuffer&&ze(A)}function et(A){const _=A.textures;for(let B=0,K=_.length;B<K;B++){const Q=_[B];if(f(Q)){const j=E(A),Ae=n.get(Q).__webglTexture;t.bindTexture(j,Ae),p(j),t.unbindTexture()}}}const wt=[],k=[];function sn(A){if(A.samples>0){if(Ze(A)===!1){const _=A.textures,B=A.width,K=A.height;let Q=i.COLOR_BUFFER_BIT;const j=A.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Ae=n.get(A),he=_.length>1;if(he)for(let ge=0;ge<_.length;ge++)t.bindFramebuffer(i.FRAMEBUFFER,Ae.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ge,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,Ae.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+ge,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,Ae.__webglMultisampledFramebuffer),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ae.__webglFramebuffer);for(let ge=0;ge<_.length;ge++){if(A.resolveDepthBuffer&&(A.depthBuffer&&(Q|=i.DEPTH_BUFFER_BIT),A.stencilBuffer&&A.resolveStencilBuffer&&(Q|=i.STENCIL_BUFFER_BIT)),he){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,Ae.__webglColorRenderbuffer[ge]);const tt=n.get(_[ge]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,tt,0)}i.blitFramebuffer(0,0,B,K,0,0,B,K,Q,i.NEAREST),l===!0&&(wt.length=0,k.length=0,wt.push(i.COLOR_ATTACHMENT0+ge),A.depthBuffer&&A.resolveDepthBuffer===!1&&(wt.push(j),k.push(j),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,k)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,wt))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),he)for(let ge=0;ge<_.length;ge++){t.bindFramebuffer(i.FRAMEBUFFER,Ae.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ge,i.RENDERBUFFER,Ae.__webglColorRenderbuffer[ge]);const tt=n.get(_[ge]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,Ae.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+ge,i.TEXTURE_2D,tt,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ae.__webglMultisampledFramebuffer)}else if(A.depthBuffer&&A.resolveDepthBuffer===!1&&l){const _=A.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[_])}}}function Ke(A){return Math.min(s.maxSamples,A.samples)}function Ze(A){const _=n.get(A);return A.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function Ie(A){const _=r.render.frame;h.get(A)!==_&&(h.set(A,_),A.update())}function gt(A,_){const B=A.colorSpace,K=A.format,Q=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||B!==ws&&B!==si&&(Qe.getTransfer(B)===ot?(K!==vn||Q!==jn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",B)),_}function Le(A){return typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement?(c.width=A.naturalWidth||A.width,c.height=A.naturalHeight||A.height):typeof VideoFrame<"u"&&A instanceof VideoFrame?(c.width=A.displayWidth,c.height=A.displayHeight):(c.width=A.width,c.height=A.height),c}this.allocateTextureUnit=z,this.resetTextureUnits=V,this.setTexture2D=J,this.setTexture2DArray=q,this.setTexture3D=ne,this.setTextureCube=$,this.rebindTextures=Ye,this.setupRenderTarget=yt,this.updateRenderTargetMipmap=et,this.updateMultisampleRenderTarget=sn,this.setupDepthRenderbuffer=ze,this.setupFrameBufferTexture=Me,this.useMultisampledRTT=Ze}function Lv(i,e){function t(n,s=si){let a;const r=Qe.getTransfer(s);if(n===jn)return i.UNSIGNED_BYTE;if(n===Cl)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Rl)return i.UNSIGNED_SHORT_5_5_5_1;if(n===lh)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===rh)return i.BYTE;if(n===oh)return i.SHORT;if(n===Js)return i.UNSIGNED_SHORT;if(n===Al)return i.INT;if(n===Fi)return i.UNSIGNED_INT;if(n===Gn)return i.FLOAT;if(n===Wn)return i.HALF_FLOAT;if(n===ch)return i.ALPHA;if(n===dh)return i.RGB;if(n===vn)return i.RGBA;if(n===hh)return i.LUMINANCE;if(n===uh)return i.LUMINANCE_ALPHA;if(n===ls)return i.DEPTH_COMPONENT;if(n===xs)return i.DEPTH_STENCIL;if(n===fh)return i.RED;if(n===Pl)return i.RED_INTEGER;if(n===ph)return i.RG;if(n===Ll)return i.RG_INTEGER;if(n===Dl)return i.RGBA_INTEGER;if(n===ja||n===Ka||n===Za||n===Ja)if(r===ot)if(a=e.get("WEBGL_compressed_texture_s3tc_srgb"),a!==null){if(n===ja)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Ka)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Za)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Ja)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(a=e.get("WEBGL_compressed_texture_s3tc"),a!==null){if(n===ja)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Ka)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Za)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Ja)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Io||n===Uo||n===No||n===Fo)if(a=e.get("WEBGL_compressed_texture_pvrtc"),a!==null){if(n===Io)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Uo)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===No)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Fo)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===ko||n===Oo||n===Bo)if(a=e.get("WEBGL_compressed_texture_etc"),a!==null){if(n===ko||n===Oo)return r===ot?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(n===Bo)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===zo||n===Ho||n===Go||n===Vo||n===$o||n===Wo||n===Xo||n===qo||n===Yo||n===jo||n===Ko||n===Zo||n===Jo||n===Qo)if(a=e.get("WEBGL_compressed_texture_astc"),a!==null){if(n===zo)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Ho)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Go)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Vo)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===$o)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Wo)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Xo)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===qo)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Yo)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===jo)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Ko)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Zo)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Jo)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Qo)return r===ot?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Qa||n===el||n===tl)if(a=e.get("EXT_texture_compression_bptc"),a!==null){if(n===Qa)return r===ot?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===el)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===tl)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===mh||n===nl||n===il||n===sl)if(a=e.get("EXT_texture_compression_rgtc"),a!==null){if(n===Qa)return a.COMPRESSED_RED_RGTC1_EXT;if(n===nl)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===il)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===sl)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===_s?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}class Dv extends qt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}}class tn extends Ct{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Iv={type:"move"};class ao{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new tn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new tn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new R,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new R),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new tn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new R,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new R),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,a=null,r=null;const o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){r=!0;for(const v of e.hand.values()){const f=t.getJointPose(v,n),p=this._getHandJoint(c,v);f!==null&&(p.matrix.fromArray(f.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=f.radius),p.visible=f!==null}const h=c.joints["index-finger-tip"],d=c.joints["thumb-tip"],u=h.position.distanceTo(d.position),m=.02,g=.005;c.inputState.pinching&&u>m+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&u<=m-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(a=t.getPose(e.gripSpace,n),a!==null&&(l.matrix.fromArray(a.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,a.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(a.linearVelocity)):l.hasLinearVelocity=!1,a.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(a.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&a!==null&&(s=a),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Iv)))}return o!==null&&(o.visible=s!==null),l!==null&&(l.visible=a!==null),c!==null&&(c.visible=r!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new tn;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}const Uv=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Nv=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Fv{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t,n){if(this.texture===null){const s=new Bt,a=e.properties.get(s);a.__webglTexture=t.texture,(t.depthNear!=n.depthNear||t.depthFar!=n.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=s}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new Ot({vertexShader:Uv,fragmentShader:Nv,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new Ge(new Ts(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class kv extends Es{constructor(e,t){super();const n=this;let s=null,a=1,r=null,o="local-floor",l=1,c=null,h=null,d=null,u=null,m=null,g=null;const v=new Fv,f=t.getContextAttributes();let p=null,E=null;const w=[],b=[],O=new Pe;let P=null;const L=new qt;L.viewport=new dt;const I=new qt;I.viewport=new dt;const S=[L,I],y=new Dv;let D=null,V=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Y){let te=w[Y];return te===void 0&&(te=new ao,w[Y]=te),te.getTargetRaySpace()},this.getControllerGrip=function(Y){let te=w[Y];return te===void 0&&(te=new ao,w[Y]=te),te.getGripSpace()},this.getHand=function(Y){let te=w[Y];return te===void 0&&(te=new ao,w[Y]=te),te.getHandSpace()};function z(Y){const te=b.indexOf(Y.inputSource);if(te===-1)return;const Me=w[te];Me!==void 0&&(Me.update(Y.inputSource,Y.frame,c||r),Me.dispatchEvent({type:Y.type,data:Y.inputSource}))}function X(){s.removeEventListener("select",z),s.removeEventListener("selectstart",z),s.removeEventListener("selectend",z),s.removeEventListener("squeeze",z),s.removeEventListener("squeezestart",z),s.removeEventListener("squeezeend",z),s.removeEventListener("end",X),s.removeEventListener("inputsourceschange",J);for(let Y=0;Y<w.length;Y++){const te=b[Y];te!==null&&(b[Y]=null,w[Y].disconnect(te))}D=null,V=null,v.reset(),e.setRenderTarget(p),m=null,u=null,d=null,s=null,E=null,Te.stop(),n.isPresenting=!1,e.setPixelRatio(P),e.setSize(O.width,O.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Y){a=Y,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Y){o=Y,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||r},this.setReferenceSpace=function(Y){c=Y},this.getBaseLayer=function(){return u!==null?u:m},this.getBinding=function(){return d},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(Y){if(s=Y,s!==null){if(p=e.getRenderTarget(),s.addEventListener("select",z),s.addEventListener("selectstart",z),s.addEventListener("selectend",z),s.addEventListener("squeeze",z),s.addEventListener("squeezestart",z),s.addEventListener("squeezeend",z),s.addEventListener("end",X),s.addEventListener("inputsourceschange",J),f.xrCompatible!==!0&&await t.makeXRCompatible(),P=e.getPixelRatio(),e.getSize(O),s.renderState.layers===void 0){const te={antialias:f.antialias,alpha:!0,depth:f.depth,stencil:f.stencil,framebufferScaleFactor:a};m=new XRWebGLLayer(s,t,te),s.updateRenderState({baseLayer:m}),e.setPixelRatio(1),e.setSize(m.framebufferWidth,m.framebufferHeight,!1),E=new xn(m.framebufferWidth,m.framebufferHeight,{format:vn,type:jn,colorSpace:e.outputColorSpace,stencilBuffer:f.stencil})}else{let te=null,Me=null,le=null;f.depth&&(le=f.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,te=f.stencil?xs:ls,Me=f.stencil?_s:Fi);const De={colorFormat:t.RGBA8,depthFormat:le,scaleFactor:a};d=new XRWebGLBinding(s,t),u=d.createProjectionLayer(De),s.updateRenderState({layers:[u]}),e.setPixelRatio(1),e.setSize(u.textureWidth,u.textureHeight,!1),E=new xn(u.textureWidth,u.textureHeight,{format:vn,type:jn,depthTexture:new Rh(u.textureWidth,u.textureHeight,Me,void 0,void 0,void 0,void 0,void 0,void 0,te),stencilBuffer:f.stencil,colorSpace:e.outputColorSpace,samples:f.antialias?4:0,resolveDepthBuffer:u.ignoreDepthValues===!1})}E.isXRRenderTarget=!0,this.setFoveation(l),c=null,r=await s.requestReferenceSpace(o),Te.setContext(s),Te.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return v.getDepthTexture()};function J(Y){for(let te=0;te<Y.removed.length;te++){const Me=Y.removed[te],le=b.indexOf(Me);le>=0&&(b[le]=null,w[le].disconnect(Me))}for(let te=0;te<Y.added.length;te++){const Me=Y.added[te];let le=b.indexOf(Me);if(le===-1){for(let ze=0;ze<w.length;ze++)if(ze>=b.length){b.push(Me),le=ze;break}else if(b[ze]===null){b[ze]=Me,le=ze;break}if(le===-1)break}const De=w[le];De&&De.connect(Me)}}const q=new R,ne=new R;function $(Y,te,Me){q.setFromMatrixPosition(te.matrixWorld),ne.setFromMatrixPosition(Me.matrixWorld);const le=q.distanceTo(ne),De=te.projectionMatrix.elements,ze=Me.projectionMatrix.elements,Ye=De[14]/(De[10]-1),yt=De[14]/(De[10]+1),et=(De[9]+1)/De[5],wt=(De[9]-1)/De[5],k=(De[8]-1)/De[0],sn=(ze[8]+1)/ze[0],Ke=Ye*k,Ze=Ye*sn,Ie=le/(-k+sn),gt=Ie*-k;if(te.matrixWorld.decompose(Y.position,Y.quaternion,Y.scale),Y.translateX(gt),Y.translateZ(Ie),Y.matrixWorld.compose(Y.position,Y.quaternion,Y.scale),Y.matrixWorldInverse.copy(Y.matrixWorld).invert(),De[10]===-1)Y.projectionMatrix.copy(te.projectionMatrix),Y.projectionMatrixInverse.copy(te.projectionMatrixInverse);else{const Le=Ye+Ie,A=yt+Ie,_=Ke-gt,B=Ze+(le-gt),K=et*yt/A*Le,Q=wt*yt/A*Le;Y.projectionMatrix.makePerspective(_,B,K,Q,Le,A),Y.projectionMatrixInverse.copy(Y.projectionMatrix).invert()}}function ce(Y,te){te===null?Y.matrixWorld.copy(Y.matrix):Y.matrixWorld.multiplyMatrices(te.matrixWorld,Y.matrix),Y.matrixWorldInverse.copy(Y.matrixWorld).invert()}this.updateCamera=function(Y){if(s===null)return;let te=Y.near,Me=Y.far;v.texture!==null&&(v.depthNear>0&&(te=v.depthNear),v.depthFar>0&&(Me=v.depthFar)),y.near=I.near=L.near=te,y.far=I.far=L.far=Me,(D!==y.near||V!==y.far)&&(s.updateRenderState({depthNear:y.near,depthFar:y.far}),D=y.near,V=y.far),L.layers.mask=Y.layers.mask|2,I.layers.mask=Y.layers.mask|4,y.layers.mask=L.layers.mask|I.layers.mask;const le=Y.parent,De=y.cameras;ce(y,le);for(let ze=0;ze<De.length;ze++)ce(De[ze],le);De.length===2?$(y,L,I):y.projectionMatrix.copy(L.projectionMatrix),ee(Y,y,le)};function ee(Y,te,Me){Me===null?Y.matrix.copy(te.matrixWorld):(Y.matrix.copy(Me.matrixWorld),Y.matrix.invert(),Y.matrix.multiply(te.matrixWorld)),Y.matrix.decompose(Y.position,Y.quaternion,Y.scale),Y.updateMatrixWorld(!0),Y.projectionMatrix.copy(te.projectionMatrix),Y.projectionMatrixInverse.copy(te.projectionMatrixInverse),Y.isPerspectiveCamera&&(Y.fov=Qs*2*Math.atan(1/Y.projectionMatrix.elements[5]),Y.zoom=1)}this.getCamera=function(){return y},this.getFoveation=function(){if(!(u===null&&m===null))return l},this.setFoveation=function(Y){l=Y,u!==null&&(u.fixedFoveation=Y),m!==null&&m.fixedFoveation!==void 0&&(m.fixedFoveation=Y)},this.hasDepthSensing=function(){return v.texture!==null},this.getDepthSensingMesh=function(){return v.getMesh(y)};let ie=null;function ve(Y,te){if(h=te.getViewerPose(c||r),g=te,h!==null){const Me=h.views;m!==null&&(e.setRenderTargetFramebuffer(E,m.framebuffer),e.setRenderTarget(E));let le=!1;Me.length!==y.cameras.length&&(y.cameras.length=0,le=!0);for(let ze=0;ze<Me.length;ze++){const Ye=Me[ze];let yt=null;if(m!==null)yt=m.getViewport(Ye);else{const wt=d.getViewSubImage(u,Ye);yt=wt.viewport,ze===0&&(e.setRenderTargetTextures(E,wt.colorTexture,u.ignoreDepthValues?void 0:wt.depthStencilTexture),e.setRenderTarget(E))}let et=S[ze];et===void 0&&(et=new qt,et.layers.enable(ze),et.viewport=new dt,S[ze]=et),et.matrix.fromArray(Ye.transform.matrix),et.matrix.decompose(et.position,et.quaternion,et.scale),et.projectionMatrix.fromArray(Ye.projectionMatrix),et.projectionMatrixInverse.copy(et.projectionMatrix).invert(),et.viewport.set(yt.x,yt.y,yt.width,yt.height),ze===0&&(y.matrix.copy(et.matrix),y.matrix.decompose(y.position,y.quaternion,y.scale)),le===!0&&y.cameras.push(et)}const De=s.enabledFeatures;if(De&&De.includes("depth-sensing")){const ze=d.getDepthInformation(Me[0]);ze&&ze.isValid&&ze.texture&&v.init(e,ze,s.renderState)}}for(let Me=0;Me<w.length;Me++){const le=b[Me],De=w[Me];le!==null&&De!==void 0&&De.update(le,te,c||r)}ie&&ie(Y,te),te.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:te}),g=null}const Te=new Ch;Te.setAnimationLoop(ve),this.setAnimationLoop=function(Y){ie=Y},this.dispose=function(){}}}const Mi=new Cn,Ov=new pt;function Bv(i,e){function t(f,p){f.matrixAutoUpdate===!0&&f.updateMatrix(),p.value.copy(f.matrix)}function n(f,p){p.color.getRGB(f.fogColor.value,Eh(i)),p.isFog?(f.fogNear.value=p.near,f.fogFar.value=p.far):p.isFogExp2&&(f.fogDensity.value=p.density)}function s(f,p,E,w,b){p.isMeshBasicMaterial||p.isMeshLambertMaterial?a(f,p):p.isMeshToonMaterial?(a(f,p),d(f,p)):p.isMeshPhongMaterial?(a(f,p),h(f,p)):p.isMeshStandardMaterial?(a(f,p),u(f,p),p.isMeshPhysicalMaterial&&m(f,p,b)):p.isMeshMatcapMaterial?(a(f,p),g(f,p)):p.isMeshDepthMaterial?a(f,p):p.isMeshDistanceMaterial?(a(f,p),v(f,p)):p.isMeshNormalMaterial?a(f,p):p.isLineBasicMaterial?(r(f,p),p.isLineDashedMaterial&&o(f,p)):p.isPointsMaterial?l(f,p,E,w):p.isSpriteMaterial?c(f,p):p.isShadowMaterial?(f.color.value.copy(p.color),f.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function a(f,p){f.opacity.value=p.opacity,p.color&&f.diffuse.value.copy(p.color),p.emissive&&f.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(f.map.value=p.map,t(p.map,f.mapTransform)),p.alphaMap&&(f.alphaMap.value=p.alphaMap,t(p.alphaMap,f.alphaMapTransform)),p.bumpMap&&(f.bumpMap.value=p.bumpMap,t(p.bumpMap,f.bumpMapTransform),f.bumpScale.value=p.bumpScale,p.side===jt&&(f.bumpScale.value*=-1)),p.normalMap&&(f.normalMap.value=p.normalMap,t(p.normalMap,f.normalMapTransform),f.normalScale.value.copy(p.normalScale),p.side===jt&&f.normalScale.value.negate()),p.displacementMap&&(f.displacementMap.value=p.displacementMap,t(p.displacementMap,f.displacementMapTransform),f.displacementScale.value=p.displacementScale,f.displacementBias.value=p.displacementBias),p.emissiveMap&&(f.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,f.emissiveMapTransform)),p.specularMap&&(f.specularMap.value=p.specularMap,t(p.specularMap,f.specularMapTransform)),p.alphaTest>0&&(f.alphaTest.value=p.alphaTest);const E=e.get(p),w=E.envMap,b=E.envMapRotation;w&&(f.envMap.value=w,Mi.copy(b),Mi.x*=-1,Mi.y*=-1,Mi.z*=-1,w.isCubeTexture&&w.isRenderTargetTexture===!1&&(Mi.y*=-1,Mi.z*=-1),f.envMapRotation.value.setFromMatrix4(Ov.makeRotationFromEuler(Mi)),f.flipEnvMap.value=w.isCubeTexture&&w.isRenderTargetTexture===!1?-1:1,f.reflectivity.value=p.reflectivity,f.ior.value=p.ior,f.refractionRatio.value=p.refractionRatio),p.lightMap&&(f.lightMap.value=p.lightMap,f.lightMapIntensity.value=p.lightMapIntensity,t(p.lightMap,f.lightMapTransform)),p.aoMap&&(f.aoMap.value=p.aoMap,f.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,f.aoMapTransform))}function r(f,p){f.diffuse.value.copy(p.color),f.opacity.value=p.opacity,p.map&&(f.map.value=p.map,t(p.map,f.mapTransform))}function o(f,p){f.dashSize.value=p.dashSize,f.totalSize.value=p.dashSize+p.gapSize,f.scale.value=p.scale}function l(f,p,E,w){f.diffuse.value.copy(p.color),f.opacity.value=p.opacity,f.size.value=p.size*E,f.scale.value=w*.5,p.map&&(f.map.value=p.map,t(p.map,f.uvTransform)),p.alphaMap&&(f.alphaMap.value=p.alphaMap,t(p.alphaMap,f.alphaMapTransform)),p.alphaTest>0&&(f.alphaTest.value=p.alphaTest)}function c(f,p){f.diffuse.value.copy(p.color),f.opacity.value=p.opacity,f.rotation.value=p.rotation,p.map&&(f.map.value=p.map,t(p.map,f.mapTransform)),p.alphaMap&&(f.alphaMap.value=p.alphaMap,t(p.alphaMap,f.alphaMapTransform)),p.alphaTest>0&&(f.alphaTest.value=p.alphaTest)}function h(f,p){f.specular.value.copy(p.specular),f.shininess.value=Math.max(p.shininess,1e-4)}function d(f,p){p.gradientMap&&(f.gradientMap.value=p.gradientMap)}function u(f,p){f.metalness.value=p.metalness,p.metalnessMap&&(f.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,f.metalnessMapTransform)),f.roughness.value=p.roughness,p.roughnessMap&&(f.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,f.roughnessMapTransform)),p.envMap&&(f.envMapIntensity.value=p.envMapIntensity)}function m(f,p,E){f.ior.value=p.ior,p.sheen>0&&(f.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),f.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(f.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,f.sheenColorMapTransform)),p.sheenRoughnessMap&&(f.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,f.sheenRoughnessMapTransform))),p.clearcoat>0&&(f.clearcoat.value=p.clearcoat,f.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(f.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,f.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(f.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,f.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(f.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,f.clearcoatNormalMapTransform),f.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===jt&&f.clearcoatNormalScale.value.negate())),p.dispersion>0&&(f.dispersion.value=p.dispersion),p.iridescence>0&&(f.iridescence.value=p.iridescence,f.iridescenceIOR.value=p.iridescenceIOR,f.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],f.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(f.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,f.iridescenceMapTransform)),p.iridescenceThicknessMap&&(f.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,f.iridescenceThicknessMapTransform))),p.transmission>0&&(f.transmission.value=p.transmission,f.transmissionSamplerMap.value=E.texture,f.transmissionSamplerSize.value.set(E.width,E.height),p.transmissionMap&&(f.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,f.transmissionMapTransform)),f.thickness.value=p.thickness,p.thicknessMap&&(f.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,f.thicknessMapTransform)),f.attenuationDistance.value=p.attenuationDistance,f.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(f.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(f.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,f.anisotropyMapTransform))),f.specularIntensity.value=p.specularIntensity,f.specularColor.value.copy(p.specularColor),p.specularColorMap&&(f.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,f.specularColorMapTransform)),p.specularIntensityMap&&(f.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,f.specularIntensityMapTransform))}function g(f,p){p.matcap&&(f.matcap.value=p.matcap)}function v(f,p){const E=e.get(p).light;f.referencePosition.value.setFromMatrixPosition(E.matrixWorld),f.nearDistance.value=E.shadow.camera.near,f.farDistance.value=E.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function zv(i,e,t,n){let s={},a={},r=[];const o=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(E,w){const b=w.program;n.uniformBlockBinding(E,b)}function c(E,w){let b=s[E.id];b===void 0&&(g(E),b=h(E),s[E.id]=b,E.addEventListener("dispose",f));const O=w.program;n.updateUBOMapping(E,O);const P=e.render.frame;a[E.id]!==P&&(u(E),a[E.id]=P)}function h(E){const w=d();E.__bindingPointIndex=w;const b=i.createBuffer(),O=E.__size,P=E.usage;return i.bindBuffer(i.UNIFORM_BUFFER,b),i.bufferData(i.UNIFORM_BUFFER,O,P),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,w,b),b}function d(){for(let E=0;E<o;E++)if(r.indexOf(E)===-1)return r.push(E),E;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function u(E){const w=s[E.id],b=E.uniforms,O=E.__cache;i.bindBuffer(i.UNIFORM_BUFFER,w);for(let P=0,L=b.length;P<L;P++){const I=Array.isArray(b[P])?b[P]:[b[P]];for(let S=0,y=I.length;S<y;S++){const D=I[S];if(m(D,P,S,O)===!0){const V=D.__offset,z=Array.isArray(D.value)?D.value:[D.value];let X=0;for(let J=0;J<z.length;J++){const q=z[J],ne=v(q);typeof q=="number"||typeof q=="boolean"?(D.__data[0]=q,i.bufferSubData(i.UNIFORM_BUFFER,V+X,D.__data)):q.isMatrix3?(D.__data[0]=q.elements[0],D.__data[1]=q.elements[1],D.__data[2]=q.elements[2],D.__data[3]=0,D.__data[4]=q.elements[3],D.__data[5]=q.elements[4],D.__data[6]=q.elements[5],D.__data[7]=0,D.__data[8]=q.elements[6],D.__data[9]=q.elements[7],D.__data[10]=q.elements[8],D.__data[11]=0):(q.toArray(D.__data,X),X+=ne.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,V,D.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function m(E,w,b,O){const P=E.value,L=w+"_"+b;if(O[L]===void 0)return typeof P=="number"||typeof P=="boolean"?O[L]=P:O[L]=P.clone(),!0;{const I=O[L];if(typeof P=="number"||typeof P=="boolean"){if(I!==P)return O[L]=P,!0}else if(I.equals(P)===!1)return I.copy(P),!0}return!1}function g(E){const w=E.uniforms;let b=0;const O=16;for(let L=0,I=w.length;L<I;L++){const S=Array.isArray(w[L])?w[L]:[w[L]];for(let y=0,D=S.length;y<D;y++){const V=S[y],z=Array.isArray(V.value)?V.value:[V.value];for(let X=0,J=z.length;X<J;X++){const q=z[X],ne=v(q),$=b%O,ce=$%ne.boundary,ee=$+ce;b+=ce,ee!==0&&O-ee<ne.storage&&(b+=O-ee),V.__data=new Float32Array(ne.storage/Float32Array.BYTES_PER_ELEMENT),V.__offset=b,b+=ne.storage}}}const P=b%O;return P>0&&(b+=O-P),E.__size=b,E.__cache={},this}function v(E){const w={boundary:0,storage:0};return typeof E=="number"||typeof E=="boolean"?(w.boundary=4,w.storage=4):E.isVector2?(w.boundary=8,w.storage=8):E.isVector3||E.isColor?(w.boundary=16,w.storage=12):E.isVector4?(w.boundary=16,w.storage=16):E.isMatrix3?(w.boundary=48,w.storage=48):E.isMatrix4?(w.boundary=64,w.storage=64):E.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",E),w}function f(E){const w=E.target;w.removeEventListener("dispose",f);const b=r.indexOf(w.__bindingPointIndex);r.splice(b,1),i.deleteBuffer(s[w.id]),delete s[w.id],delete a[w.id]}function p(){for(const E in s)i.deleteBuffer(s[E]);r=[],s={},a={}}return{bind:l,update:c,dispose:p}}class Hv{constructor(e={}){const{canvas:t=Pf(),context:n=null,depth:s=!0,stencil:a=!1,alpha:r=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:d=!1,reverseDepthBuffer:u=!1}=e;this.isWebGLRenderer=!0;let m;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");m=n.getContextAttributes().alpha}else m=r;const g=new Uint32Array(4),v=new Int32Array(4);let f=null,p=null;const E=[],w=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Gt,this.toneMapping=oi,this.toneMappingExposure=1;const b=this;let O=!1,P=0,L=0,I=null,S=-1,y=null;const D=new dt,V=new dt;let z=null;const X=new pe(0);let J=0,q=t.width,ne=t.height,$=1,ce=null,ee=null;const ie=new dt(0,0,q,ne),ve=new dt(0,0,q,ne);let Te=!1;const Y=new Nl;let te=!1,Me=!1;const le=new pt,De=new pt,ze=new R,Ye=new dt,yt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let et=!1;function wt(){return I===null?$:1}let k=n;function sn(M,N){return t.getContext(M,N)}try{const M={alpha:!0,depth:s,stencil:a,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:d};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${El}`),t.addEventListener("webglcontextlost",Z,!1),t.addEventListener("webglcontextrestored",me,!1),t.addEventListener("webglcontextcreationerror",ue,!1),k===null){const N="webgl2";if(k=sn(N,M),k===null)throw sn(N)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(M){throw console.error("THREE.WebGLRenderer: "+M.message),M}let Ke,Ze,Ie,gt,Le,A,_,B,K,Q,j,Ae,he,ge,tt,se,_e,Ue,Fe,xe,Je,Xe,ut,U;function de(){Ke=new Xg(k),Ke.init(),Xe=new Lv(k,Ke),Ze=new zg(k,Ke,e,Xe),Ie=new Cv(k,Ke),Ze.reverseDepthBuffer&&u&&Ie.buffers.depth.setReversed(!0),gt=new jg(k),Le=new fv,A=new Pv(k,Ke,Ie,Le,Ze,Xe,gt),_=new Gg(b),B=new Wg(b),K=new np(k),ut=new Og(k,K),Q=new qg(k,K,gt,ut),j=new Zg(k,Q,K,gt),Fe=new Kg(k,Ze,A),se=new Hg(Le),Ae=new uv(b,_,B,Ke,Ze,ut,se),he=new Bv(b,Le),ge=new mv,tt=new Mv(Ke),Ue=new kg(b,_,B,Ie,j,m,l),_e=new Tv(b,j,Ze),U=new zv(k,gt,Ze,Ie),xe=new Bg(k,Ke,gt),Je=new Yg(k,Ke,gt),gt.programs=Ae.programs,b.capabilities=Ze,b.extensions=Ke,b.properties=Le,b.renderLists=ge,b.shadowMap=_e,b.state=Ie,b.info=gt}de();const W=new kv(b,k);this.xr=W,this.getContext=function(){return k},this.getContextAttributes=function(){return k.getContextAttributes()},this.forceContextLoss=function(){const M=Ke.get("WEBGL_lose_context");M&&M.loseContext()},this.forceContextRestore=function(){const M=Ke.get("WEBGL_lose_context");M&&M.restoreContext()},this.getPixelRatio=function(){return $},this.setPixelRatio=function(M){M!==void 0&&($=M,this.setSize(q,ne,!1))},this.getSize=function(M){return M.set(q,ne)},this.setSize=function(M,N,H=!0){if(W.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}q=M,ne=N,t.width=Math.floor(M*$),t.height=Math.floor(N*$),H===!0&&(t.style.width=M+"px",t.style.height=N+"px"),this.setViewport(0,0,M,N)},this.getDrawingBufferSize=function(M){return M.set(q*$,ne*$).floor()},this.setDrawingBufferSize=function(M,N,H){q=M,ne=N,$=H,t.width=Math.floor(M*H),t.height=Math.floor(N*H),this.setViewport(0,0,M,N)},this.getCurrentViewport=function(M){return M.copy(D)},this.getViewport=function(M){return M.copy(ie)},this.setViewport=function(M,N,H,G){M.isVector4?ie.set(M.x,M.y,M.z,M.w):ie.set(M,N,H,G),Ie.viewport(D.copy(ie).multiplyScalar($).round())},this.getScissor=function(M){return M.copy(ve)},this.setScissor=function(M,N,H,G){M.isVector4?ve.set(M.x,M.y,M.z,M.w):ve.set(M,N,H,G),Ie.scissor(V.copy(ve).multiplyScalar($).round())},this.getScissorTest=function(){return Te},this.setScissorTest=function(M){Ie.setScissorTest(Te=M)},this.setOpaqueSort=function(M){ce=M},this.setTransparentSort=function(M){ee=M},this.getClearColor=function(M){return M.copy(Ue.getClearColor())},this.setClearColor=function(){Ue.setClearColor.apply(Ue,arguments)},this.getClearAlpha=function(){return Ue.getClearAlpha()},this.setClearAlpha=function(){Ue.setClearAlpha.apply(Ue,arguments)},this.clear=function(M=!0,N=!0,H=!0){let G=0;if(M){let F=!1;if(I!==null){const ae=I.texture.format;F=ae===Dl||ae===Ll||ae===Pl}if(F){const ae=I.texture.type,fe=ae===jn||ae===Fi||ae===Js||ae===_s||ae===Cl||ae===Rl,be=Ue.getClearColor(),Se=Ue.getClearAlpha(),Be=be.r,$e=be.g,we=be.b;fe?(g[0]=Be,g[1]=$e,g[2]=we,g[3]=Se,k.clearBufferuiv(k.COLOR,0,g)):(v[0]=Be,v[1]=$e,v[2]=we,v[3]=Se,k.clearBufferiv(k.COLOR,0,v))}else G|=k.COLOR_BUFFER_BIT}N&&(G|=k.DEPTH_BUFFER_BIT),H&&(G|=k.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),k.clear(G)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",Z,!1),t.removeEventListener("webglcontextrestored",me,!1),t.removeEventListener("webglcontextcreationerror",ue,!1),ge.dispose(),tt.dispose(),Le.dispose(),_.dispose(),B.dispose(),j.dispose(),ut.dispose(),U.dispose(),Ae.dispose(),W.dispose(),W.removeEventListener("sessionstart",Ql),W.removeEventListener("sessionend",ec),pi.stop()};function Z(M){M.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),O=!0}function me(){console.log("THREE.WebGLRenderer: Context Restored."),O=!1;const M=gt.autoReset,N=_e.enabled,H=_e.autoUpdate,G=_e.needsUpdate,F=_e.type;de(),gt.autoReset=M,_e.enabled=N,_e.autoUpdate=H,_e.needsUpdate=G,_e.type=F}function ue(M){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",M.statusMessage)}function Ve(M){const N=M.target;N.removeEventListener("dispose",Ve),St(N)}function St(M){Ut(M),Le.remove(M)}function Ut(M){const N=Le.get(M).programs;N!==void 0&&(N.forEach(function(H){Ae.releaseProgram(H)}),M.isShaderMaterial&&Ae.releaseShaderCache(M))}this.renderBufferDirect=function(M,N,H,G,F,ae){N===null&&(N=yt);const fe=F.isMesh&&F.matrixWorld.determinant()<0,be=ou(M,N,H,G,F);Ie.setMaterial(G,fe);let Se=H.index,Be=1;if(G.wireframe===!0){if(Se=Q.getWireframeAttribute(H),Se===void 0)return;Be=2}const $e=H.drawRange,we=H.attributes.position;let it=$e.start*Be,ft=($e.start+$e.count)*Be;ae!==null&&(it=Math.max(it,ae.start*Be),ft=Math.min(ft,(ae.start+ae.count)*Be)),Se!==null?(it=Math.max(it,0),ft=Math.min(ft,Se.count)):we!=null&&(it=Math.max(it,0),ft=Math.min(ft,we.count));const vt=ft-it;if(vt<0||vt===1/0)return;ut.setup(F,G,be,H,Se);let Wt,st=xe;if(Se!==null&&(Wt=K.get(Se),st=Je,st.setIndex(Wt)),F.isMesh)G.wireframe===!0?(Ie.setLineWidth(G.wireframeLinewidth*wt()),st.setMode(k.LINES)):st.setMode(k.TRIANGLES);else if(F.isLine){let Ce=G.linewidth;Ce===void 0&&(Ce=1),Ie.setLineWidth(Ce*wt()),F.isLineSegments?st.setMode(k.LINES):F.isLineLoop?st.setMode(k.LINE_LOOP):st.setMode(k.LINE_STRIP)}else F.isPoints?st.setMode(k.POINTS):F.isSprite&&st.setMode(k.TRIANGLES);if(F.isBatchedMesh)if(F._multiDrawInstances!==null)st.renderMultiDrawInstances(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount,F._multiDrawInstances);else if(Ke.get("WEBGL_multi_draw"))st.renderMultiDraw(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount);else{const Ce=F._multiDrawStarts,Ln=F._multiDrawCounts,at=F._multiDrawCount,dn=Se?K.get(Se).bytesPerElement:1,ki=Le.get(G).currentProgram.getUniforms();for(let Kt=0;Kt<at;Kt++)ki.setValue(k,"_gl_DrawID",Kt),st.render(Ce[Kt]/dn,Ln[Kt])}else if(F.isInstancedMesh)st.renderInstances(it,vt,F.count);else if(H.isInstancedBufferGeometry){const Ce=H._maxInstanceCount!==void 0?H._maxInstanceCount:1/0,Ln=Math.min(H.instanceCount,Ce);st.renderInstances(it,vt,Ln)}else st.render(it,vt)};function rt(M,N,H){M.transparent===!0&&M.side===Yt&&M.forceSinglePass===!1?(M.side=jt,M.needsUpdate=!0,ha(M,N,H),M.side=Yn,M.needsUpdate=!0,ha(M,N,H),M.side=Yt):ha(M,N,H)}this.compile=function(M,N,H=null){H===null&&(H=M),p=tt.get(H),p.init(N),w.push(p),H.traverseVisible(function(F){F.isLight&&F.layers.test(N.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),M!==H&&M.traverseVisible(function(F){F.isLight&&F.layers.test(N.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),p.setupLights();const G=new Set;return M.traverse(function(F){if(!(F.isMesh||F.isPoints||F.isLine||F.isSprite))return;const ae=F.material;if(ae)if(Array.isArray(ae))for(let fe=0;fe<ae.length;fe++){const be=ae[fe];rt(be,H,F),G.add(be)}else rt(ae,H,F),G.add(ae)}),w.pop(),p=null,G},this.compileAsync=function(M,N,H=null){const G=this.compile(M,N,H);return new Promise(F=>{function ae(){if(G.forEach(function(fe){Le.get(fe).currentProgram.isReady()&&G.delete(fe)}),G.size===0){F(M);return}setTimeout(ae,10)}Ke.get("KHR_parallel_shader_compile")!==null?ae():setTimeout(ae,10)})};let cn=null;function Pn(M){cn&&cn(M)}function Ql(){pi.stop()}function ec(){pi.start()}const pi=new Ch;pi.setAnimationLoop(Pn),typeof self<"u"&&pi.setContext(self),this.setAnimationLoop=function(M){cn=M,W.setAnimationLoop(M),M===null?pi.stop():pi.start()},W.addEventListener("sessionstart",Ql),W.addEventListener("sessionend",ec),this.render=function(M,N){if(N!==void 0&&N.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(O===!0)return;if(M.matrixWorldAutoUpdate===!0&&M.updateMatrixWorld(),N.parent===null&&N.matrixWorldAutoUpdate===!0&&N.updateMatrixWorld(),W.enabled===!0&&W.isPresenting===!0&&(W.cameraAutoUpdate===!0&&W.updateCamera(N),N=W.getCamera()),M.isScene===!0&&M.onBeforeRender(b,M,N,I),p=tt.get(M,w.length),p.init(N),w.push(p),De.multiplyMatrices(N.projectionMatrix,N.matrixWorldInverse),Y.setFromProjectionMatrix(De),Me=this.localClippingEnabled,te=se.init(this.clippingPlanes,Me),f=ge.get(M,E.length),f.init(),E.push(f),W.enabled===!0&&W.isPresenting===!0){const ae=b.xr.getDepthSensingMesh();ae!==null&&wr(ae,N,-1/0,b.sortObjects)}wr(M,N,0,b.sortObjects),f.finish(),b.sortObjects===!0&&f.sort(ce,ee),et=W.enabled===!1||W.isPresenting===!1||W.hasDepthSensing()===!1,et&&Ue.addToRenderList(f,M),this.info.render.frame++,te===!0&&se.beginShadows();const H=p.state.shadowsArray;_e.render(H,M,N),te===!0&&se.endShadows(),this.info.autoReset===!0&&this.info.reset();const G=f.opaque,F=f.transmissive;if(p.setupLights(),N.isArrayCamera){const ae=N.cameras;if(F.length>0)for(let fe=0,be=ae.length;fe<be;fe++){const Se=ae[fe];nc(G,F,M,Se)}et&&Ue.render(M);for(let fe=0,be=ae.length;fe<be;fe++){const Se=ae[fe];tc(f,M,Se,Se.viewport)}}else F.length>0&&nc(G,F,M,N),et&&Ue.render(M),tc(f,M,N);I!==null&&(A.updateMultisampleRenderTarget(I),A.updateRenderTargetMipmap(I)),M.isScene===!0&&M.onAfterRender(b,M,N),ut.resetDefaultState(),S=-1,y=null,w.pop(),w.length>0?(p=w[w.length-1],te===!0&&se.setGlobalState(b.clippingPlanes,p.state.camera)):p=null,E.pop(),E.length>0?f=E[E.length-1]:f=null};function wr(M,N,H,G){if(M.visible===!1)return;if(M.layers.test(N.layers)){if(M.isGroup)H=M.renderOrder;else if(M.isLOD)M.autoUpdate===!0&&M.update(N);else if(M.isLight)p.pushLight(M),M.castShadow&&p.pushShadow(M);else if(M.isSprite){if(!M.frustumCulled||Y.intersectsSprite(M)){G&&Ye.setFromMatrixPosition(M.matrixWorld).applyMatrix4(De);const fe=j.update(M),be=M.material;be.visible&&f.push(M,fe,be,H,Ye.z,null)}}else if((M.isMesh||M.isLine||M.isPoints)&&(!M.frustumCulled||Y.intersectsObject(M))){const fe=j.update(M),be=M.material;if(G&&(M.boundingSphere!==void 0?(M.boundingSphere===null&&M.computeBoundingSphere(),Ye.copy(M.boundingSphere.center)):(fe.boundingSphere===null&&fe.computeBoundingSphere(),Ye.copy(fe.boundingSphere.center)),Ye.applyMatrix4(M.matrixWorld).applyMatrix4(De)),Array.isArray(be)){const Se=fe.groups;for(let Be=0,$e=Se.length;Be<$e;Be++){const we=Se[Be],it=be[we.materialIndex];it&&it.visible&&f.push(M,fe,it,H,Ye.z,we)}}else be.visible&&f.push(M,fe,be,H,Ye.z,null)}}const ae=M.children;for(let fe=0,be=ae.length;fe<be;fe++)wr(ae[fe],N,H,G)}function tc(M,N,H,G){const F=M.opaque,ae=M.transmissive,fe=M.transparent;p.setupLightsView(H),te===!0&&se.setGlobalState(b.clippingPlanes,H),G&&Ie.viewport(D.copy(G)),F.length>0&&da(F,N,H),ae.length>0&&da(ae,N,H),fe.length>0&&da(fe,N,H),Ie.buffers.depth.setTest(!0),Ie.buffers.depth.setMask(!0),Ie.buffers.color.setMask(!0),Ie.setPolygonOffset(!1)}function nc(M,N,H,G){if((H.isScene===!0?H.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[G.id]===void 0&&(p.state.transmissionRenderTarget[G.id]=new xn(1,1,{generateMipmaps:!0,type:Ke.has("EXT_color_buffer_half_float")||Ke.has("EXT_color_buffer_float")?Wn:jn,minFilter:Di,samples:4,stencilBuffer:a,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Qe.workingColorSpace}));const ae=p.state.transmissionRenderTarget[G.id],fe=G.viewport||D;ae.setSize(fe.z,fe.w);const be=b.getRenderTarget();b.setRenderTarget(ae),b.getClearColor(X),J=b.getClearAlpha(),J<1&&b.setClearColor(16777215,.5),b.clear(),et&&Ue.render(H);const Se=b.toneMapping;b.toneMapping=oi;const Be=G.viewport;if(G.viewport!==void 0&&(G.viewport=void 0),p.setupLightsView(G),te===!0&&se.setGlobalState(b.clippingPlanes,G),da(M,H,G),A.updateMultisampleRenderTarget(ae),A.updateRenderTargetMipmap(ae),Ke.has("WEBGL_multisampled_render_to_texture")===!1){let $e=!1;for(let we=0,it=N.length;we<it;we++){const ft=N[we],vt=ft.object,Wt=ft.geometry,st=ft.material,Ce=ft.group;if(st.side===Yt&&vt.layers.test(G.layers)){const Ln=st.side;st.side=jt,st.needsUpdate=!0,ic(vt,H,G,Wt,st,Ce),st.side=Ln,st.needsUpdate=!0,$e=!0}}$e===!0&&(A.updateMultisampleRenderTarget(ae),A.updateRenderTargetMipmap(ae))}b.setRenderTarget(be),b.setClearColor(X,J),Be!==void 0&&(G.viewport=Be),b.toneMapping=Se}function da(M,N,H){const G=N.isScene===!0?N.overrideMaterial:null;for(let F=0,ae=M.length;F<ae;F++){const fe=M[F],be=fe.object,Se=fe.geometry,Be=G===null?fe.material:G,$e=fe.group;be.layers.test(H.layers)&&ic(be,N,H,Se,Be,$e)}}function ic(M,N,H,G,F,ae){M.onBeforeRender(b,N,H,G,F,ae),M.modelViewMatrix.multiplyMatrices(H.matrixWorldInverse,M.matrixWorld),M.normalMatrix.getNormalMatrix(M.modelViewMatrix),F.onBeforeRender(b,N,H,G,M,ae),F.transparent===!0&&F.side===Yt&&F.forceSinglePass===!1?(F.side=jt,F.needsUpdate=!0,b.renderBufferDirect(H,N,G,F,M,ae),F.side=Yn,F.needsUpdate=!0,b.renderBufferDirect(H,N,G,F,M,ae),F.side=Yt):b.renderBufferDirect(H,N,G,F,M,ae),M.onAfterRender(b,N,H,G,F,ae)}function ha(M,N,H){N.isScene!==!0&&(N=yt);const G=Le.get(M),F=p.state.lights,ae=p.state.shadowsArray,fe=F.state.version,be=Ae.getParameters(M,F.state,ae,N,H),Se=Ae.getProgramCacheKey(be);let Be=G.programs;G.environment=M.isMeshStandardMaterial?N.environment:null,G.fog=N.fog,G.envMap=(M.isMeshStandardMaterial?B:_).get(M.envMap||G.environment),G.envMapRotation=G.environment!==null&&M.envMap===null?N.environmentRotation:M.envMapRotation,Be===void 0&&(M.addEventListener("dispose",Ve),Be=new Map,G.programs=Be);let $e=Be.get(Se);if($e!==void 0){if(G.currentProgram===$e&&G.lightsStateVersion===fe)return ac(M,be),$e}else be.uniforms=Ae.getUniforms(M),M.onBeforeCompile(be,b),$e=Ae.acquireProgram(be,Se),Be.set(Se,$e),G.uniforms=be.uniforms;const we=G.uniforms;return(!M.isShaderMaterial&&!M.isRawShaderMaterial||M.clipping===!0)&&(we.clippingPlanes=se.uniform),ac(M,be),G.needsLights=cu(M),G.lightsStateVersion=fe,G.needsLights&&(we.ambientLightColor.value=F.state.ambient,we.lightProbe.value=F.state.probe,we.directionalLights.value=F.state.directional,we.directionalLightShadows.value=F.state.directionalShadow,we.spotLights.value=F.state.spot,we.spotLightShadows.value=F.state.spotShadow,we.rectAreaLights.value=F.state.rectArea,we.ltc_1.value=F.state.rectAreaLTC1,we.ltc_2.value=F.state.rectAreaLTC2,we.pointLights.value=F.state.point,we.pointLightShadows.value=F.state.pointShadow,we.hemisphereLights.value=F.state.hemi,we.directionalShadowMap.value=F.state.directionalShadowMap,we.directionalShadowMatrix.value=F.state.directionalShadowMatrix,we.spotShadowMap.value=F.state.spotShadowMap,we.spotLightMatrix.value=F.state.spotLightMatrix,we.spotLightMap.value=F.state.spotLightMap,we.pointShadowMap.value=F.state.pointShadowMap,we.pointShadowMatrix.value=F.state.pointShadowMatrix),G.currentProgram=$e,G.uniformsList=null,$e}function sc(M){if(M.uniformsList===null){const N=M.currentProgram.getUniforms();M.uniformsList=er.seqWithValue(N.seq,M.uniforms)}return M.uniformsList}function ac(M,N){const H=Le.get(M);H.outputColorSpace=N.outputColorSpace,H.batching=N.batching,H.batchingColor=N.batchingColor,H.instancing=N.instancing,H.instancingColor=N.instancingColor,H.instancingMorph=N.instancingMorph,H.skinning=N.skinning,H.morphTargets=N.morphTargets,H.morphNormals=N.morphNormals,H.morphColors=N.morphColors,H.morphTargetsCount=N.morphTargetsCount,H.numClippingPlanes=N.numClippingPlanes,H.numIntersection=N.numClipIntersection,H.vertexAlphas=N.vertexAlphas,H.vertexTangents=N.vertexTangents,H.toneMapping=N.toneMapping}function ou(M,N,H,G,F){N.isScene!==!0&&(N=yt),A.resetTextureUnits();const ae=N.fog,fe=G.isMeshStandardMaterial?N.environment:null,be=I===null?b.outputColorSpace:I.isXRRenderTarget===!0?I.texture.colorSpace:ws,Se=(G.isMeshStandardMaterial?B:_).get(G.envMap||fe),Be=G.vertexColors===!0&&!!H.attributes.color&&H.attributes.color.itemSize===4,$e=!!H.attributes.tangent&&(!!G.normalMap||G.anisotropy>0),we=!!H.morphAttributes.position,it=!!H.morphAttributes.normal,ft=!!H.morphAttributes.color;let vt=oi;G.toneMapped&&(I===null||I.isXRRenderTarget===!0)&&(vt=b.toneMapping);const Wt=H.morphAttributes.position||H.morphAttributes.normal||H.morphAttributes.color,st=Wt!==void 0?Wt.length:0,Ce=Le.get(G),Ln=p.state.lights;if(te===!0&&(Me===!0||M!==y)){const an=M===y&&G.id===S;se.setState(G,M,an)}let at=!1;G.version===Ce.__version?(Ce.needsLights&&Ce.lightsStateVersion!==Ln.state.version||Ce.outputColorSpace!==be||F.isBatchedMesh&&Ce.batching===!1||!F.isBatchedMesh&&Ce.batching===!0||F.isBatchedMesh&&Ce.batchingColor===!0&&F.colorTexture===null||F.isBatchedMesh&&Ce.batchingColor===!1&&F.colorTexture!==null||F.isInstancedMesh&&Ce.instancing===!1||!F.isInstancedMesh&&Ce.instancing===!0||F.isSkinnedMesh&&Ce.skinning===!1||!F.isSkinnedMesh&&Ce.skinning===!0||F.isInstancedMesh&&Ce.instancingColor===!0&&F.instanceColor===null||F.isInstancedMesh&&Ce.instancingColor===!1&&F.instanceColor!==null||F.isInstancedMesh&&Ce.instancingMorph===!0&&F.morphTexture===null||F.isInstancedMesh&&Ce.instancingMorph===!1&&F.morphTexture!==null||Ce.envMap!==Se||G.fog===!0&&Ce.fog!==ae||Ce.numClippingPlanes!==void 0&&(Ce.numClippingPlanes!==se.numPlanes||Ce.numIntersection!==se.numIntersection)||Ce.vertexAlphas!==Be||Ce.vertexTangents!==$e||Ce.morphTargets!==we||Ce.morphNormals!==it||Ce.morphColors!==ft||Ce.toneMapping!==vt||Ce.morphTargetsCount!==st)&&(at=!0):(at=!0,Ce.__version=G.version);let dn=Ce.currentProgram;at===!0&&(dn=ha(G,N,F));let ki=!1,Kt=!1,Ps=!1;const _t=dn.getUniforms(),Mn=Ce.uniforms;if(Ie.useProgram(dn.program)&&(ki=!0,Kt=!0,Ps=!0),G.id!==S&&(S=G.id,Kt=!0),ki||y!==M){Ie.buffers.depth.getReversed()?(le.copy(M.projectionMatrix),Df(le),If(le),_t.setValue(k,"projectionMatrix",le)):_t.setValue(k,"projectionMatrix",M.projectionMatrix),_t.setValue(k,"viewMatrix",M.matrixWorldInverse);const Kn=_t.map.cameraPosition;Kn!==void 0&&Kn.setValue(k,ze.setFromMatrixPosition(M.matrixWorld)),Ze.logarithmicDepthBuffer&&_t.setValue(k,"logDepthBufFC",2/(Math.log(M.far+1)/Math.LN2)),(G.isMeshPhongMaterial||G.isMeshToonMaterial||G.isMeshLambertMaterial||G.isMeshBasicMaterial||G.isMeshStandardMaterial||G.isShaderMaterial)&&_t.setValue(k,"isOrthographic",M.isOrthographicCamera===!0),y!==M&&(y=M,Kt=!0,Ps=!0)}if(F.isSkinnedMesh){_t.setOptional(k,F,"bindMatrix"),_t.setOptional(k,F,"bindMatrixInverse");const an=F.skeleton;an&&(an.boneTexture===null&&an.computeBoneTexture(),_t.setValue(k,"boneTexture",an.boneTexture,A))}F.isBatchedMesh&&(_t.setOptional(k,F,"batchingTexture"),_t.setValue(k,"batchingTexture",F._matricesTexture,A),_t.setOptional(k,F,"batchingIdTexture"),_t.setValue(k,"batchingIdTexture",F._indirectTexture,A),_t.setOptional(k,F,"batchingColorTexture"),F._colorsTexture!==null&&_t.setValue(k,"batchingColorTexture",F._colorsTexture,A));const Ls=H.morphAttributes;if((Ls.position!==void 0||Ls.normal!==void 0||Ls.color!==void 0)&&Fe.update(F,H,dn),(Kt||Ce.receiveShadow!==F.receiveShadow)&&(Ce.receiveShadow=F.receiveShadow,_t.setValue(k,"receiveShadow",F.receiveShadow)),G.isMeshGouraudMaterial&&G.envMap!==null&&(Mn.envMap.value=Se,Mn.flipEnvMap.value=Se.isCubeTexture&&Se.isRenderTargetTexture===!1?-1:1),G.isMeshStandardMaterial&&G.envMap===null&&N.environment!==null&&(Mn.envMapIntensity.value=N.environmentIntensity),Kt&&(_t.setValue(k,"toneMappingExposure",b.toneMappingExposure),Ce.needsLights&&lu(Mn,Ps),ae&&G.fog===!0&&he.refreshFogUniforms(Mn,ae),he.refreshMaterialUniforms(Mn,G,$,ne,p.state.transmissionRenderTarget[M.id]),er.upload(k,sc(Ce),Mn,A)),G.isShaderMaterial&&G.uniformsNeedUpdate===!0&&(er.upload(k,sc(Ce),Mn,A),G.uniformsNeedUpdate=!1),G.isSpriteMaterial&&_t.setValue(k,"center",F.center),_t.setValue(k,"modelViewMatrix",F.modelViewMatrix),_t.setValue(k,"normalMatrix",F.normalMatrix),_t.setValue(k,"modelMatrix",F.matrixWorld),G.isShaderMaterial||G.isRawShaderMaterial){const an=G.uniformsGroups;for(let Kn=0,Zn=an.length;Kn<Zn;Kn++){const rc=an[Kn];U.update(rc,dn),U.bind(rc,dn)}}return dn}function lu(M,N){M.ambientLightColor.needsUpdate=N,M.lightProbe.needsUpdate=N,M.directionalLights.needsUpdate=N,M.directionalLightShadows.needsUpdate=N,M.pointLights.needsUpdate=N,M.pointLightShadows.needsUpdate=N,M.spotLights.needsUpdate=N,M.spotLightShadows.needsUpdate=N,M.rectAreaLights.needsUpdate=N,M.hemisphereLights.needsUpdate=N}function cu(M){return M.isMeshLambertMaterial||M.isMeshToonMaterial||M.isMeshPhongMaterial||M.isMeshStandardMaterial||M.isShadowMaterial||M.isShaderMaterial&&M.lights===!0}this.getActiveCubeFace=function(){return P},this.getActiveMipmapLevel=function(){return L},this.getRenderTarget=function(){return I},this.setRenderTargetTextures=function(M,N,H){Le.get(M.texture).__webglTexture=N,Le.get(M.depthTexture).__webglTexture=H;const G=Le.get(M);G.__hasExternalTextures=!0,G.__autoAllocateDepthBuffer=H===void 0,G.__autoAllocateDepthBuffer||Ke.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),G.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(M,N){const H=Le.get(M);H.__webglFramebuffer=N,H.__useDefaultFramebuffer=N===void 0},this.setRenderTarget=function(M,N=0,H=0){I=M,P=N,L=H;let G=!0,F=null,ae=!1,fe=!1;if(M){const Se=Le.get(M);if(Se.__useDefaultFramebuffer!==void 0)Ie.bindFramebuffer(k.FRAMEBUFFER,null),G=!1;else if(Se.__webglFramebuffer===void 0)A.setupRenderTarget(M);else if(Se.__hasExternalTextures)A.rebindTextures(M,Le.get(M.texture).__webglTexture,Le.get(M.depthTexture).__webglTexture);else if(M.depthBuffer){const we=M.depthTexture;if(Se.__boundDepthTexture!==we){if(we!==null&&Le.has(we)&&(M.width!==we.image.width||M.height!==we.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");A.setupDepthRenderbuffer(M)}}const Be=M.texture;(Be.isData3DTexture||Be.isDataArrayTexture||Be.isCompressedArrayTexture)&&(fe=!0);const $e=Le.get(M).__webglFramebuffer;M.isWebGLCubeRenderTarget?(Array.isArray($e[N])?F=$e[N][H]:F=$e[N],ae=!0):M.samples>0&&A.useMultisampledRTT(M)===!1?F=Le.get(M).__webglMultisampledFramebuffer:Array.isArray($e)?F=$e[H]:F=$e,D.copy(M.viewport),V.copy(M.scissor),z=M.scissorTest}else D.copy(ie).multiplyScalar($).floor(),V.copy(ve).multiplyScalar($).floor(),z=Te;if(Ie.bindFramebuffer(k.FRAMEBUFFER,F)&&G&&Ie.drawBuffers(M,F),Ie.viewport(D),Ie.scissor(V),Ie.setScissorTest(z),ae){const Se=Le.get(M.texture);k.framebufferTexture2D(k.FRAMEBUFFER,k.COLOR_ATTACHMENT0,k.TEXTURE_CUBE_MAP_POSITIVE_X+N,Se.__webglTexture,H)}else if(fe){const Se=Le.get(M.texture),Be=N||0;k.framebufferTextureLayer(k.FRAMEBUFFER,k.COLOR_ATTACHMENT0,Se.__webglTexture,H||0,Be)}S=-1},this.readRenderTargetPixels=function(M,N,H,G,F,ae,fe){if(!(M&&M.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let be=Le.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&fe!==void 0&&(be=be[fe]),be){Ie.bindFramebuffer(k.FRAMEBUFFER,be);try{const Se=M.texture,Be=Se.format,$e=Se.type;if(!Ze.textureFormatReadable(Be)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Ze.textureTypeReadable($e)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}N>=0&&N<=M.width-G&&H>=0&&H<=M.height-F&&k.readPixels(N,H,G,F,Xe.convert(Be),Xe.convert($e),ae)}finally{const Se=I!==null?Le.get(I).__webglFramebuffer:null;Ie.bindFramebuffer(k.FRAMEBUFFER,Se)}}},this.readRenderTargetPixelsAsync=async function(M,N,H,G,F,ae,fe){if(!(M&&M.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let be=Le.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&fe!==void 0&&(be=be[fe]),be){const Se=M.texture,Be=Se.format,$e=Se.type;if(!Ze.textureFormatReadable(Be))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Ze.textureTypeReadable($e))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(N>=0&&N<=M.width-G&&H>=0&&H<=M.height-F){Ie.bindFramebuffer(k.FRAMEBUFFER,be);const we=k.createBuffer();k.bindBuffer(k.PIXEL_PACK_BUFFER,we),k.bufferData(k.PIXEL_PACK_BUFFER,ae.byteLength,k.STREAM_READ),k.readPixels(N,H,G,F,Xe.convert(Be),Xe.convert($e),0);const it=I!==null?Le.get(I).__webglFramebuffer:null;Ie.bindFramebuffer(k.FRAMEBUFFER,it);const ft=k.fenceSync(k.SYNC_GPU_COMMANDS_COMPLETE,0);return k.flush(),await Lf(k,ft,4),k.bindBuffer(k.PIXEL_PACK_BUFFER,we),k.getBufferSubData(k.PIXEL_PACK_BUFFER,0,ae),k.deleteBuffer(we),k.deleteSync(ft),ae}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(M,N=null,H=0){M.isTexture!==!0&&($s("WebGLRenderer: copyFramebufferToTexture function signature has changed."),N=arguments[0]||null,M=arguments[1]);const G=Math.pow(2,-H),F=Math.floor(M.image.width*G),ae=Math.floor(M.image.height*G),fe=N!==null?N.x:0,be=N!==null?N.y:0;A.setTexture2D(M,0),k.copyTexSubImage2D(k.TEXTURE_2D,H,0,0,fe,be,F,ae),Ie.unbindTexture()},this.copyTextureToTexture=function(M,N,H=null,G=null,F=0){M.isTexture!==!0&&($s("WebGLRenderer: copyTextureToTexture function signature has changed."),G=arguments[0]||null,M=arguments[1],N=arguments[2],F=arguments[3]||0,H=null);let ae,fe,be,Se,Be,$e,we,it,ft;const vt=M.isCompressedTexture?M.mipmaps[F]:M.image;H!==null?(ae=H.max.x-H.min.x,fe=H.max.y-H.min.y,be=H.isBox3?H.max.z-H.min.z:1,Se=H.min.x,Be=H.min.y,$e=H.isBox3?H.min.z:0):(ae=vt.width,fe=vt.height,be=vt.depth||1,Se=0,Be=0,$e=0),G!==null?(we=G.x,it=G.y,ft=G.z):(we=0,it=0,ft=0);const Wt=Xe.convert(N.format),st=Xe.convert(N.type);let Ce;N.isData3DTexture?(A.setTexture3D(N,0),Ce=k.TEXTURE_3D):N.isDataArrayTexture||N.isCompressedArrayTexture?(A.setTexture2DArray(N,0),Ce=k.TEXTURE_2D_ARRAY):(A.setTexture2D(N,0),Ce=k.TEXTURE_2D),k.pixelStorei(k.UNPACK_FLIP_Y_WEBGL,N.flipY),k.pixelStorei(k.UNPACK_PREMULTIPLY_ALPHA_WEBGL,N.premultiplyAlpha),k.pixelStorei(k.UNPACK_ALIGNMENT,N.unpackAlignment);const Ln=k.getParameter(k.UNPACK_ROW_LENGTH),at=k.getParameter(k.UNPACK_IMAGE_HEIGHT),dn=k.getParameter(k.UNPACK_SKIP_PIXELS),ki=k.getParameter(k.UNPACK_SKIP_ROWS),Kt=k.getParameter(k.UNPACK_SKIP_IMAGES);k.pixelStorei(k.UNPACK_ROW_LENGTH,vt.width),k.pixelStorei(k.UNPACK_IMAGE_HEIGHT,vt.height),k.pixelStorei(k.UNPACK_SKIP_PIXELS,Se),k.pixelStorei(k.UNPACK_SKIP_ROWS,Be),k.pixelStorei(k.UNPACK_SKIP_IMAGES,$e);const Ps=M.isDataArrayTexture||M.isData3DTexture,_t=N.isDataArrayTexture||N.isData3DTexture;if(M.isRenderTargetTexture||M.isDepthTexture){const Mn=Le.get(M),Ls=Le.get(N),an=Le.get(Mn.__renderTarget),Kn=Le.get(Ls.__renderTarget);Ie.bindFramebuffer(k.READ_FRAMEBUFFER,an.__webglFramebuffer),Ie.bindFramebuffer(k.DRAW_FRAMEBUFFER,Kn.__webglFramebuffer);for(let Zn=0;Zn<be;Zn++)Ps&&k.framebufferTextureLayer(k.READ_FRAMEBUFFER,k.COLOR_ATTACHMENT0,Le.get(M).__webglTexture,F,$e+Zn),M.isDepthTexture?(_t&&k.framebufferTextureLayer(k.DRAW_FRAMEBUFFER,k.COLOR_ATTACHMENT0,Le.get(N).__webglTexture,F,ft+Zn),k.blitFramebuffer(Se,Be,ae,fe,we,it,ae,fe,k.DEPTH_BUFFER_BIT,k.NEAREST)):_t?k.copyTexSubImage3D(Ce,F,we,it,ft+Zn,Se,Be,ae,fe):k.copyTexSubImage2D(Ce,F,we,it,ft+Zn,Se,Be,ae,fe);Ie.bindFramebuffer(k.READ_FRAMEBUFFER,null),Ie.bindFramebuffer(k.DRAW_FRAMEBUFFER,null)}else _t?M.isDataTexture||M.isData3DTexture?k.texSubImage3D(Ce,F,we,it,ft,ae,fe,be,Wt,st,vt.data):N.isCompressedArrayTexture?k.compressedTexSubImage3D(Ce,F,we,it,ft,ae,fe,be,Wt,vt.data):k.texSubImage3D(Ce,F,we,it,ft,ae,fe,be,Wt,st,vt):M.isDataTexture?k.texSubImage2D(k.TEXTURE_2D,F,we,it,ae,fe,Wt,st,vt.data):M.isCompressedTexture?k.compressedTexSubImage2D(k.TEXTURE_2D,F,we,it,vt.width,vt.height,Wt,vt.data):k.texSubImage2D(k.TEXTURE_2D,F,we,it,ae,fe,Wt,st,vt);k.pixelStorei(k.UNPACK_ROW_LENGTH,Ln),k.pixelStorei(k.UNPACK_IMAGE_HEIGHT,at),k.pixelStorei(k.UNPACK_SKIP_PIXELS,dn),k.pixelStorei(k.UNPACK_SKIP_ROWS,ki),k.pixelStorei(k.UNPACK_SKIP_IMAGES,Kt),F===0&&N.generateMipmaps&&k.generateMipmap(Ce),Ie.unbindTexture()},this.copyTextureToTexture3D=function(M,N,H=null,G=null,F=0){return M.isTexture!==!0&&($s("WebGLRenderer: copyTextureToTexture3D function signature has changed."),H=arguments[0]||null,G=arguments[1]||null,M=arguments[2],N=arguments[3],F=arguments[4]||0),$s('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(M,N,H,G,F)},this.initRenderTarget=function(M){Le.get(M).__webglFramebuffer===void 0&&A.setupRenderTarget(M)},this.initTexture=function(M){M.isCubeTexture?A.setTextureCube(M,0):M.isData3DTexture?A.setTexture3D(M,0):M.isDataArrayTexture||M.isCompressedArrayTexture?A.setTexture2DArray(M,0):A.setTexture2D(M,0),Ie.unbindTexture()},this.resetState=function(){P=0,L=0,I=null,Ie.reset(),ut.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Vn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorspace=Qe._getDrawingBufferColorSpace(e),t.unpackColorSpace=Qe._getUnpackColorSpace()}}class Ol{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new pe(e),this.density=t}clone(){return new Ol(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class Uh extends Ct{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Cn,this.environmentIntensity=1,this.environmentRotation=new Cn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class Gv{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=al,this.updateRanges=[],this.version=0,this.uuid=Xn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let s=0,a=this.stride;s<a;s++)this.array[e+s]=t.array[n+s];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Xn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Xn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const zt=new R;class lr{constructor(e,t,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)zt.fromBufferAttribute(this,t),zt.applyMatrix4(e),this.setXYZ(t,zt.x,zt.y,zt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)zt.fromBufferAttribute(this,t),zt.applyNormalMatrix(e),this.setXYZ(t,zt.x,zt.y,zt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)zt.fromBufferAttribute(this,t),zt.transformDirection(e),this.setXYZ(t,zt.x,zt.y,zt.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=mn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=lt(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=lt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=mn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=mn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=mn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=mn(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this}setXYZW(e,t,n,s,a){return e=e*this.data.stride+this.offset,this.normalized&&(t=lt(t,this.array),n=lt(n,this.array),s=lt(s,this.array),a=lt(a,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this.data.array[e+3]=a,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let a=0;a<this.itemSize;a++)t.push(this.data.array[s+a])}return new Dt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new lr(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let a=0;a<this.itemSize;a++)t.push(this.data.array[s+a])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class cr extends fi{static get type(){return"SpriteMaterial"}constructor(e){super(),this.isSpriteMaterial=!0,this.color=new pe(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let Ji;const Os=new R,Qi=new R,es=new R,ts=new Pe,Bs=new Pe,Nh=new pt,ka=new R,zs=new R,Oa=new R,cd=new Pe,ro=new Pe,dd=new Pe;class ol extends Ct{constructor(e=new cr){if(super(),this.isSprite=!0,this.type="Sprite",Ji===void 0){Ji=new bt;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new Gv(t,5);Ji.setIndex([0,1,2,0,2,3]),Ji.setAttribute("position",new lr(n,3,0,!1)),Ji.setAttribute("uv",new lr(n,2,3,!1))}this.geometry=Ji,this.material=e,this.center=new Pe(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Qi.setFromMatrixScale(this.matrixWorld),Nh.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),es.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Qi.multiplyScalar(-es.z);const n=this.material.rotation;let s,a;n!==0&&(a=Math.cos(n),s=Math.sin(n));const r=this.center;Ba(ka.set(-.5,-.5,0),es,r,Qi,s,a),Ba(zs.set(.5,-.5,0),es,r,Qi,s,a),Ba(Oa.set(.5,.5,0),es,r,Qi,s,a),cd.set(0,0),ro.set(1,0),dd.set(1,1);let o=e.ray.intersectTriangle(ka,zs,Oa,!1,Os);if(o===null&&(Ba(zs.set(-.5,.5,0),es,r,Qi,s,a),ro.set(0,1),o=e.ray.intersectTriangle(ka,Oa,zs,!1,Os),o===null))return;const l=e.ray.origin.distanceTo(Os);l<e.near||l>e.far||t.push({distance:l,point:Os.clone(),uv:ln.getInterpolation(Os,ka,zs,Oa,cd,ro,dd,new Pe),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}}function Ba(i,e,t,n,s,a){ts.subVectors(i,t).addScalar(.5).multiply(n),s!==void 0?(Bs.x=a*ts.x-s*ts.y,Bs.y=s*ts.x+a*ts.y):Bs.copy(ts),i.copy(e),i.x+=Bs.x,i.y+=Bs.y,i.applyMatrix4(Nh)}class yr extends fi{static get type(){return"LineBasicMaterial"}constructor(e){super(),this.isLineBasicMaterial=!0,this.color=new pe(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const dr=new R,hr=new R,hd=new pt,Hs=new Ul,za=new oa,oo=new R,ud=new R;class Bl extends Ct{constructor(e=new bt,t=new yr){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let s=1,a=t.count;s<a;s++)dr.fromBufferAttribute(t,s-1),hr.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=dr.distanceTo(hr);e.setAttribute("lineDistance",new mt(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const n=this.geometry,s=this.matrixWorld,a=e.params.Line.threshold,r=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),za.copy(n.boundingSphere),za.applyMatrix4(s),za.radius+=a,e.ray.intersectsSphere(za)===!1)return;hd.copy(s).invert(),Hs.copy(e.ray).applyMatrix4(hd);const o=a/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,h=n.index,u=n.attributes.position;if(h!==null){const m=Math.max(0,r.start),g=Math.min(h.count,r.start+r.count);for(let v=m,f=g-1;v<f;v+=c){const p=h.getX(v),E=h.getX(v+1),w=Ha(this,e,Hs,l,p,E);w&&t.push(w)}if(this.isLineLoop){const v=h.getX(g-1),f=h.getX(m),p=Ha(this,e,Hs,l,v,f);p&&t.push(p)}}else{const m=Math.max(0,r.start),g=Math.min(u.count,r.start+r.count);for(let v=m,f=g-1;v<f;v+=c){const p=Ha(this,e,Hs,l,v,v+1);p&&t.push(p)}if(this.isLineLoop){const v=Ha(this,e,Hs,l,g-1,m);v&&t.push(v)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let a=0,r=s.length;a<r;a++){const o=s[a].name||String(a);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=a}}}}}function Ha(i,e,t,n,s,a){const r=i.geometry.attributes.position;if(dr.fromBufferAttribute(r,s),hr.fromBufferAttribute(r,a),t.distanceSqToSegment(dr,hr,oo,ud)>n)return;oo.applyMatrix4(i.matrixWorld);const l=e.ray.origin.distanceTo(oo);if(!(l<e.near||l>e.far))return{distance:l,point:ud.clone().applyMatrix4(i.matrixWorld),index:s,face:null,faceIndex:null,barycoord:null,object:i}}const fd=new R,pd=new R;class Vv extends Bl{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let s=0,a=t.count;s<a;s+=2)fd.fromBufferAttribute(t,s),pd.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+fd.distanceTo(pd);e.setAttribute("lineDistance",new mt(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class zl extends fi{static get type(){return"PointsMaterial"}constructor(e){super(),this.isPointsMaterial=!0,this.color=new pe(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const md=new pt,ll=new Ul,Ga=new oa,Va=new R;class Hl extends Ct{constructor(e=new bt,t=new zl){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const n=this.geometry,s=this.matrixWorld,a=e.params.Points.threshold,r=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ga.copy(n.boundingSphere),Ga.applyMatrix4(s),Ga.radius+=a,e.ray.intersectsSphere(Ga)===!1)return;md.copy(s).invert(),ll.copy(e.ray).applyMatrix4(md);const o=a/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,d=n.attributes.position;if(c!==null){const u=Math.max(0,r.start),m=Math.min(c.count,r.start+r.count);for(let g=u,v=m;g<v;g++){const f=c.getX(g);Va.fromBufferAttribute(d,f),gd(Va,f,l,s,e,t,this)}}else{const u=Math.max(0,r.start),m=Math.min(d.count,r.start+r.count);for(let g=u,v=m;g<v;g++)Va.fromBufferAttribute(d,g),gd(Va,g,l,s,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let a=0,r=s.length;a<r;a++){const o=s[a].name||String(a);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=a}}}}}function gd(i,e,t,n,s,a,r){const o=ll.distanceSqToPoint(i);if(o<t){const l=new R;ll.closestPointToPoint(i,l),l.applyMatrix4(n);const c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;a.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:r})}}class Fh extends Bt{constructor(e,t,n,s,a,r,o,l,c){super(e,t,n,s,a,r,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class Mr extends bt{constructor(e=1,t=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:s},t=Math.max(3,t);const a=[],r=[],o=[],l=[],c=new R,h=new Pe;r.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let d=0,u=3;d<=t;d++,u+=3){const m=n+d/t*s;c.x=e*Math.cos(m),c.y=e*Math.sin(m),r.push(c.x,c.y,c.z),o.push(0,0,1),h.x=(r[u]/e+1)/2,h.y=(r[u+1]/e+1)/2,l.push(h.x,h.y)}for(let d=1;d<=t;d++)a.push(d,d+1,0);this.setIndex(a),this.setAttribute("position",new mt(r,3)),this.setAttribute("normal",new mt(o,3)),this.setAttribute("uv",new mt(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Mr(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class ui extends bt{constructor(e=1,t=1,n=1,s=32,a=1,r=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:a,openEnded:r,thetaStart:o,thetaLength:l};const c=this;s=Math.floor(s),a=Math.floor(a);const h=[],d=[],u=[],m=[];let g=0;const v=[],f=n/2;let p=0;E(),r===!1&&(e>0&&w(!0),t>0&&w(!1)),this.setIndex(h),this.setAttribute("position",new mt(d,3)),this.setAttribute("normal",new mt(u,3)),this.setAttribute("uv",new mt(m,2));function E(){const b=new R,O=new R;let P=0;const L=(t-e)/n;for(let I=0;I<=a;I++){const S=[],y=I/a,D=y*(t-e)+e;for(let V=0;V<=s;V++){const z=V/s,X=z*l+o,J=Math.sin(X),q=Math.cos(X);O.x=D*J,O.y=-y*n+f,O.z=D*q,d.push(O.x,O.y,O.z),b.set(J,L,q).normalize(),u.push(b.x,b.y,b.z),m.push(z,1-y),S.push(g++)}v.push(S)}for(let I=0;I<s;I++)for(let S=0;S<a;S++){const y=v[S][I],D=v[S+1][I],V=v[S+1][I+1],z=v[S][I+1];(e>0||S!==0)&&(h.push(y,D,z),P+=3),(t>0||S!==a-1)&&(h.push(D,V,z),P+=3)}c.addGroup(p,P,0),p+=P}function w(b){const O=g,P=new Pe,L=new R;let I=0;const S=b===!0?e:t,y=b===!0?1:-1;for(let V=1;V<=s;V++)d.push(0,f*y,0),u.push(0,y,0),m.push(.5,.5),g++;const D=g;for(let V=0;V<=s;V++){const X=V/s*l+o,J=Math.cos(X),q=Math.sin(X);L.x=S*q,L.y=f*y,L.z=S*J,d.push(L.x,L.y,L.z),u.push(0,y,0),P.x=J*.5+.5,P.y=q*.5*y+.5,m.push(P.x,P.y),g++}for(let V=0;V<s;V++){const z=O+V,X=D+V;b===!0?h.push(X,X+1,z):h.push(X+1,X,z),I+=3}c.addGroup(p,I,b===!0?1:2),p+=I}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ui(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Ms extends ui{constructor(e=1,t=1,n=32,s=1,a=!1,r=0,o=Math.PI*2){super(0,e,t,n,s,a,r,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:s,openEnded:a,thetaStart:r,thetaLength:o}}static fromJSON(e){return new Ms(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class la extends bt{constructor(e=[],t=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:s};const a=[],r=[];o(s),c(n),h(),this.setAttribute("position",new mt(a,3)),this.setAttribute("normal",new mt(a.slice(),3)),this.setAttribute("uv",new mt(r,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(E){const w=new R,b=new R,O=new R;for(let P=0;P<t.length;P+=3)m(t[P+0],w),m(t[P+1],b),m(t[P+2],O),l(w,b,O,E)}function l(E,w,b,O){const P=O+1,L=[];for(let I=0;I<=P;I++){L[I]=[];const S=E.clone().lerp(b,I/P),y=w.clone().lerp(b,I/P),D=P-I;for(let V=0;V<=D;V++)V===0&&I===P?L[I][V]=S:L[I][V]=S.clone().lerp(y,V/D)}for(let I=0;I<P;I++)for(let S=0;S<2*(P-I)-1;S++){const y=Math.floor(S/2);S%2===0?(u(L[I][y+1]),u(L[I+1][y]),u(L[I][y])):(u(L[I][y+1]),u(L[I+1][y+1]),u(L[I+1][y]))}}function c(E){const w=new R;for(let b=0;b<a.length;b+=3)w.x=a[b+0],w.y=a[b+1],w.z=a[b+2],w.normalize().multiplyScalar(E),a[b+0]=w.x,a[b+1]=w.y,a[b+2]=w.z}function h(){const E=new R;for(let w=0;w<a.length;w+=3){E.x=a[w+0],E.y=a[w+1],E.z=a[w+2];const b=f(E)/2/Math.PI+.5,O=p(E)/Math.PI+.5;r.push(b,1-O)}g(),d()}function d(){for(let E=0;E<r.length;E+=6){const w=r[E+0],b=r[E+2],O=r[E+4],P=Math.max(w,b,O),L=Math.min(w,b,O);P>.9&&L<.1&&(w<.2&&(r[E+0]+=1),b<.2&&(r[E+2]+=1),O<.2&&(r[E+4]+=1))}}function u(E){a.push(E.x,E.y,E.z)}function m(E,w){const b=E*3;w.x=e[b+0],w.y=e[b+1],w.z=e[b+2]}function g(){const E=new R,w=new R,b=new R,O=new R,P=new Pe,L=new Pe,I=new Pe;for(let S=0,y=0;S<a.length;S+=9,y+=6){E.set(a[S+0],a[S+1],a[S+2]),w.set(a[S+3],a[S+4],a[S+5]),b.set(a[S+6],a[S+7],a[S+8]),P.set(r[y+0],r[y+1]),L.set(r[y+2],r[y+3]),I.set(r[y+4],r[y+5]),O.copy(E).add(w).add(b).divideScalar(3);const D=f(O);v(P,y+0,E,D),v(L,y+2,w,D),v(I,y+4,b,D)}}function v(E,w,b,O){O<0&&E.x===1&&(r[w]=E.x-1),b.x===0&&b.z===0&&(r[w]=O/2/Math.PI+.5)}function f(E){return Math.atan2(E.z,-E.x)}function p(E){return Math.atan2(-E.y,Math.sqrt(E.x*E.x+E.z*E.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new la(e.vertices,e.indices,e.radius,e.details)}}class ur extends la{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,s=1/n,a=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],r=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(a,r,e,t),this.type="DodecahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new ur(e.radius,e.detail)}}class br extends la{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],a=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,a,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new br(e.radius,e.detail)}}class ia extends la{constructor(e=1,t=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,s,e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new ia(e.radius,e.detail)}}class Gl extends bt{constructor(e=.5,t=1,n=32,s=1,a=0,r=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:s,thetaStart:a,thetaLength:r},n=Math.max(3,n),s=Math.max(1,s);const o=[],l=[],c=[],h=[];let d=e;const u=(t-e)/s,m=new R,g=new Pe;for(let v=0;v<=s;v++){for(let f=0;f<=n;f++){const p=a+f/n*r;m.x=d*Math.cos(p),m.y=d*Math.sin(p),l.push(m.x,m.y,m.z),c.push(0,0,1),g.x=(m.x/t+1)/2,g.y=(m.y/t+1)/2,h.push(g.x,g.y)}d+=u}for(let v=0;v<s;v++){const f=v*(n+1);for(let p=0;p<n;p++){const E=p+f,w=E,b=E+n+1,O=E+n+2,P=E+1;o.push(w,b,P),o.push(b,O,P)}}this.setIndex(o),this.setAttribute("position",new mt(l,3)),this.setAttribute("normal",new mt(c,3)),this.setAttribute("uv",new mt(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Gl(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}}class Vl extends bt{constructor(e=1,t=.4,n=12,s=48,a=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:s,arc:a},n=Math.floor(n),s=Math.floor(s);const r=[],o=[],l=[],c=[],h=new R,d=new R,u=new R;for(let m=0;m<=n;m++)for(let g=0;g<=s;g++){const v=g/s*a,f=m/n*Math.PI*2;d.x=(e+t*Math.cos(f))*Math.cos(v),d.y=(e+t*Math.cos(f))*Math.sin(v),d.z=t*Math.sin(f),o.push(d.x,d.y,d.z),h.x=e*Math.cos(v),h.y=e*Math.sin(v),u.subVectors(d,h).normalize(),l.push(u.x,u.y,u.z),c.push(g/s),c.push(m/n)}for(let m=1;m<=n;m++)for(let g=1;g<=s;g++){const v=(s+1)*m+g-1,f=(s+1)*(m-1)+g-1,p=(s+1)*(m-1)+g,E=(s+1)*m+g;r.push(v,f,E),r.push(f,p,E)}this.setIndex(r),this.setAttribute("position",new mt(o,3)),this.setAttribute("normal",new mt(l,3)),this.setAttribute("uv",new mt(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Vl(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}}class $v extends Ot{static get type(){return"RawShaderMaterial"}constructor(e){super(e),this.isRawShaderMaterial=!0}}class $l extends fi{static get type(){return"MeshStandardMaterial"}constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.color=new pe(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new pe(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=gh,this.normalScale=new Pe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Cn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}const vd={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}};class Wv{constructor(e,t,n){const s=this;let a=!1,r=0,o=0,l;const c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.itemStart=function(h){o++,a===!1&&s.onStart!==void 0&&s.onStart(h,r,o),a=!0},this.itemEnd=function(h){r++,s.onProgress!==void 0&&s.onProgress(h,r,o),r===o&&(a=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,d){return c.push(h,d),this},this.removeHandler=function(h){const d=c.indexOf(h);return d!==-1&&c.splice(d,2),this},this.getHandler=function(h){for(let d=0,u=c.length;d<u;d+=2){const m=c[d],g=c[d+1];if(m.global&&(m.lastIndex=0),m.test(h))return g}return null}}}const Xv=new Wv;class Wl{constructor(e){this.manager=e!==void 0?e:Xv,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const n=this;return new Promise(function(s,a){n.load(e,s,t,a)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}}Wl.DEFAULT_MATERIAL_NAME="__DEFAULT";class qv extends Wl{constructor(e){super(e)}load(e,t,n,s){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const a=this,r=vd.get(e);if(r!==void 0)return a.manager.itemStart(e),setTimeout(function(){t&&t(r),a.manager.itemEnd(e)},0),r;const o=ta("img");function l(){h(),vd.add(e,this),t&&t(this),a.manager.itemEnd(e)}function c(d){h(),s&&s(d),a.manager.itemError(e),a.manager.itemEnd(e)}function h(){o.removeEventListener("load",l,!1),o.removeEventListener("error",c,!1)}return o.addEventListener("load",l,!1),o.addEventListener("error",c,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(o.crossOrigin=this.crossOrigin),a.manager.itemStart(e),o.src=e,o}}class Yv extends Wl{constructor(e){super(e)}load(e,t,n,s){const a=new Bt,r=new qv(this.manager);return r.setCrossOrigin(this.crossOrigin),r.setPath(this.path),r.load(e,function(o){a.image=o,a.needsUpdate=!0,t!==void 0&&t(a)},n,s),a}}class Xl extends Ct{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new pe(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}}class jv extends Xl{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Ct.DEFAULT_UP),this.updateMatrix(),this.groundColor=new pe(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const lo=new pt,_d=new R,xd=new R;class kh{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Pe(512,512),this.map=null,this.mapPass=null,this.matrix=new pt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Nl,this._frameExtents=new Pe(1,1),this._viewportCount=1,this._viewports=[new dt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,n=this.matrix;_d.setFromMatrixPosition(e.matrixWorld),t.position.copy(_d),xd.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(xd),t.updateMatrixWorld(),lo.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(lo),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(lo)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const yd=new pt,Gs=new R,co=new R;class Kv extends kh{constructor(){super(new qt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Pe(4,2),this._viewportCount=6,this._viewports=[new dt(2,1,1,1),new dt(0,1,1,1),new dt(3,1,1,1),new dt(1,1,1,1),new dt(3,0,1,1),new dt(1,0,1,1)],this._cubeDirections=[new R(1,0,0),new R(-1,0,0),new R(0,0,1),new R(0,0,-1),new R(0,1,0),new R(0,-1,0)],this._cubeUps=[new R(0,1,0),new R(0,1,0),new R(0,1,0),new R(0,1,0),new R(0,0,1),new R(0,0,-1)]}updateMatrices(e,t=0){const n=this.camera,s=this.matrix,a=e.distance||n.far;a!==n.far&&(n.far=a,n.updateProjectionMatrix()),Gs.setFromMatrixPosition(e.matrixWorld),n.position.copy(Gs),co.copy(n.position),co.add(this._cubeDirections[t]),n.up.copy(this._cubeUps[t]),n.lookAt(co),n.updateMatrixWorld(),s.makeTranslation(-Gs.x,-Gs.y,-Gs.z),yd.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(yd)}}class Zv extends Xl{constructor(e,t,n=0,s=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new Kv}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class Jv extends kh{constructor(){super(new Fl(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Md extends Xl{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Ct.DEFAULT_UP),this.updateMatrix(),this.target=new Ct,this.shadow=new Jv}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class Qv{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=bd(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const t=bd();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}}function bd(){return performance.now()}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:El}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=El);const Ne=(i,e,t,n,s)=>({key:i,name:{es:e,en:t},desc:n,...s}),Oh={hidra:[Ne("q","Mordisco múltiple","Multi-bite",{es:"Tres mordiscos rápidos en arco.",en:"Three quick bites in an arc."},{type:"melee",stat:"p",power:3.2,hits:3,range:3.4,arc:120,cd:.9,cost:0}),Ne("e","Aliento abisal","Abyssal Breath",{es:"Aliento en cono que ralentiza.",en:"Cone breath that slows."},{type:"cone",stat:"m",power:2.2,ticks:6,dur:1.2,range:9,arc:50,cd:6,cost:25,status:{t:"slow",dur:2,val:.45}}),Ne("r","Regenerar cabeza","Regrow Head",{es:"Recupera el 25 % de vida y gana +20 % de poder.",en:"Restores 25% HP and gains +20% power."},{type:"heal",pct:.25,dur:3,cd:14,cost:35,buff:{atk:.2,dur:6}}),Ne("f","Devorar estrellas","Devour the Stars",{es:"Cinco alientos en abanico que atraviesan.",en:"Five piercing breaths in a fan."},{type:"projectile",stat:"m",power:9,count:5,spread:70,speed:22,range:18,radius:1.3,pierce:!0,cd:0})],fenix:[Ne("q","Pluma ígnea","Fire Feather",{es:"Tres plumas que queman.",en:"Three feathers that burn."},{type:"projectile",stat:"m",power:2.4,count:3,spread:22,speed:24,range:16,radius:.7,cd:.8,cost:0,status:{t:"burn",dur:3,val:.5}}),Ne("e","Muro de llamas","Wall of Flames",{es:"Zona de fuego frente al enemigo.",en:"A zone of fire on the enemy."},{type:"zone",stat:"m",power:1.6,range:12,radius:3.2,dur:4,tick:.5,cd:8,cost:25,status:{t:"burn",dur:2,val:.5}}),Ne("r","Calor vital","Vital Warmth",{es:"Cura al equipo un 20 % en 5 s.",en:"Heals your team 20% over 5 s."},{type:"heal",pct:.2,dur:5,team:!0,cd:15,cost:35}),Ne("f","Renacer","Rebirth",{es:"Revive al equipo con el 50 % de vida y estalla en llamas.",en:"Revives the team at 50% HP and bursts into flame."},{type:"revive",pct:.5,stat:"m",power:8,radius:7,cd:0})],kraken:[Ne("q","Latigazo","Lash",{es:"Golpe amplio de tentáculo.",en:"A wide tentacle strike."},{type:"melee",stat:"p",power:6,hits:1,range:4.6,arc:150,cd:1,cost:0}),Ne("e","Agarre","Grab",{es:"Atrae al objetivo y lo aturde.",en:"Pulls the target in and stuns it."},{type:"projectile",stat:"p",power:6,count:1,speed:26,range:12,radius:1,cd:7,cost:25,pullBack:!0,status:{t:"stun",dur:1}}),Ne("r","Tinta cegadora","Blinding Ink",{es:"Ciega a los enemigos cercanos y te escuda.",en:"Blinds nearby enemies and shields you."},{type:"aoe",stat:"m",power:2,range:0,radius:6,delay:0,cd:12,cost:35,status:{t:"blind",dur:4},also:{type:"shield",pct:.2,dur:5}}),Ne("f","Remolino","Maelstrom",{es:"Arrastra a todos al centro y los golpea.",en:"Drags everyone to the center and crushes them."},{type:"aoe",stat:"m",power:2.4,range:0,radius:10,ticks:6,dur:2,pull:9,final:10,cd:0})],grifo:[Ne("q","Picado","Dive",{es:"Se lanza sobre el objetivo.",en:"Dives onto the target."},{type:"dash",stat:"p",power:5.5,range:9,speed:34,width:1.8,cd:1.1,cost:0}),Ne("e","Garra eléctrica","Shock Claw",{es:"Tres zarpazos que marcan al enemigo.",en:"Three slashes that mark the enemy."},{type:"melee",stat:"p",power:3.4,hits:3,range:3.4,arc:110,cd:5,cost:25,status:{t:"mark",dur:8}}),Ne("r","Vendaval","Gale",{es:"Ráfaga en cono que empuja y ralentiza.",en:"A cone gust that knocks back and slows."},{type:"cone",stat:"p",power:5,ticks:1,dur:0,range:8,arc:70,knock:6,cd:9,cost:30,status:{t:"slow",dur:2.5,val:.5}}),Ne("f","Tormenta","Storm",{es:"Seis rayos sobre los enemigos marcados.",en:"Six bolts on marked enemies."},{type:"strike",stat:"p",power:7,count:6,radius:2.2,delay:.25,interval:.18,cd:0})],cerbero:[Ne("q","Triple mordida","Triple Bite",{es:"Tres mordiscos feroces.",en:"Three ferocious bites."},{type:"melee",stat:"p",power:3,hits:3,range:3.2,arc:110,cd:.8,cost:0}),Ne("e","Carga","Charge",{es:"Embiste en línea y aturde.",en:"Charges in a line and stuns."},{type:"dash",stat:"p",power:8,range:11,speed:30,width:2.2,cd:6,cost:25,status:{t:"stun",dur:.7}}),Ne("r","Aullido","Howl",{es:"+35 % de poder y frena a los enemigos.",en:"+35% power and slows enemies."},{type:"aoe",stat:"p",power:0,range:0,radius:9,delay:0,cd:13,cost:30,status:{t:"slow",dur:3,val:.5},also:{type:"buff",atk:.35,dur:6}}),Ne("f","Furia de tres cabezas","Three-Headed Fury",{es:"8 s de ataques en cadena con robo de vida.",en:"8 s of chained attacks with lifesteal."},{type:"buff",atk:.3,spd:.35,cdr:.7,lifesteal:.2,dur:8,cd:0})],basilisco:[Ne("q","Colmillo tóxico","Toxic Fang",{es:"Proyectil que envenena.",en:"A projectile that poisons."},{type:"projectile",stat:"m",power:4.6,count:1,speed:22,range:15,radius:.8,cd:.85,cost:0,status:{t:"poison",dur:4,val:.45}}),Ne("e","Capucha espejo","Mirror Hood",{es:"Escudo que refleja la mitad del daño.",en:"A shield that reflects half the damage."},{type:"shield",pct:.25,dur:4,reflect:.5,cd:9,cost:25}),Ne("r","Constricción","Constrict",{es:"Inmoviliza y aprieta en una zona.",en:"Roots and squeezes in an area."},{type:"aoe",stat:"m",power:2,range:11,radius:3.4,delay:.5,ticks:4,dur:2,cd:10,cost:30,status:{t:"root",dur:2}}),Ne("f","Mirada de piedra","Stone Gaze",{es:"Petrifica 3 s en un cono.",en:"Petrifies for 3 s in a cone."},{type:"cone",stat:"m",power:9,ticks:1,dur:0,range:13,arc:65,cd:0,status:{t:"petrify",dur:3}})],wyvern:[Ne("q","Esquirlas","Shards",{es:"Tres esquirlas que ralentizan.",en:"Three slowing shards."},{type:"projectile",stat:"m",power:2.3,count:3,spread:16,speed:28,range:16,radius:.6,cd:.75,cost:0,status:{t:"slow",dur:1.5,val:.3}}),Ne("e","Aliento helado","Frost Breath",{es:"Aliento que acaba congelando.",en:"A breath that ends up freezing."},{type:"cone",stat:"m",power:2,ticks:6,dur:1.4,range:9,arc:50,cd:7,cost:25,status:{t:"slow",dur:2,val:.5},endStatus:{t:"freeze",dur:1.2}}),Ne("r","Vuelo rasante","Low Flight",{es:"Pasa en vuelo dañando todo a su paso.",en:"Swoops through, damaging everything."},{type:"dash",stat:"m",power:6.5,range:12,speed:32,width:2.6,cd:8,cost:30}),Ne("f","Ventisca","Blizzard",{es:"Zona que congela a quien se quede.",en:"A zone that freezes whoever stays."},{type:"zone",stat:"m",power:2.2,range:12,radius:6,dur:6,tick:.5,cd:0,status:{t:"slow",dur:1,val:.6},freezeAfter:2})],golem:[Ne("q","Puñetazo sísmico","Seismic Punch",{es:"Golpe pesado con onda.",en:"A heavy punch with a shockwave."},{type:"melee",stat:"p",power:7.2,hits:1,range:3.6,arc:130,cd:1.15,cost:0}),Ne("e","Escudo de rocas","Rock Shield",{es:"Escudo del 30 % de tu vida.",en:"A shield worth 30% of your HP."},{type:"shield",pct:.3,dur:6,cd:10,cost:25}),Ne("r","Atraer","Pull",{es:"Atrae a los enemigos cercanos.",en:"Pulls nearby enemies in."},{type:"aoe",stat:"p",power:3,range:0,radius:10,delay:0,pull:14,cd:11,cost:30,status:{t:"slow",dur:2,val:.4}}),Ne("f","Núcleo desatado","Core Unleashed",{es:"Onda que aturde y escuda al equipo.",en:"A wave that stuns and shields the team."},{type:"aoe",stat:"p",power:10,range:0,radius:9,delay:0,cd:0,status:{t:"stun",dur:2},also:{type:"shield",pct:.3,dur:6}})],leviatan:[Ne("q","Cometa","Comet",{es:"Cometa que estalla al impactar.",en:"A comet that explodes on impact."},{type:"projectile",stat:"m",power:5,count:1,speed:20,range:16,radius:.9,explode:2.4,cd:1,cost:0}),Ne("e","Canto estelar","Star Song",{es:"Pulso que daña y te cura.",en:"A pulse that damages and heals you."},{type:"aoe",stat:"m",power:2.2,range:0,radius:6.5,delay:0,ticks:3,dur:1.5,cd:8,cost:25,selfHeal:.04}),Ne("r","Corriente astral","Astral Current",{es:"Se desliza y gana velocidad.",en:"Glides and gains speed."},{type:"dash",stat:"m",power:3,range:10,speed:30,width:2,cd:7,cost:20,also:{type:"buff",spd:.4,dur:3}}),Ne("f","Lluvia de meteoritos","Meteor Shower",{es:"Meteoritos sobre toda la zona.",en:"Meteors rain over the whole area."},{type:"strike",stat:"m",power:6.5,count:12,radius:3,delay:.7,interval:.15,area:!0,cd:0})],aracna:[Ne("q","Red rúnica","Rune Web",{es:"Red que ralentiza.",en:"A web that slows."},{type:"projectile",stat:"m",power:4,count:1,speed:20,range:14,radius:1.1,cd:.8,cost:0,status:{t:"slow",dur:2,val:.4}}),Ne("e","Veneno de sombra","Shadow Venom",{es:"Charco que envenena.",en:"A pool that poisons."},{type:"zone",stat:"m",power:1.4,range:12,radius:3.4,dur:4,tick:.5,cd:7,cost:25,status:{t:"poison",dur:3,val:.5}}),Ne("r","Crías trampa","Trap Spawn",{es:"Tres crías que estallan al contacto.",en:"Three spawn that burst on contact."},{type:"mines",stat:"m",power:6,count:3,radius:2.4,cd:10,cost:30}),Ne("f","Gran sello","Great Seal",{es:"Atrapa a todos dentro del círculo.",en:"Traps everyone inside the circle."},{type:"aoe",stat:"m",power:8,range:0,radius:11,delay:.3,cd:0,status:{t:"root",dur:3}})],ciervo:[Ne("q","Destello","Flash",{es:"Rayo de luz veloz.",en:"A swift ray of light."},{type:"projectile",stat:"m",power:4.2,count:1,speed:34,range:16,radius:.7,cd:.7,cost:0}),Ne("e","Flores curativas","Healing Flowers",{es:"Jardín que cura mientras estés dentro.",en:"A garden that heals while you stand in it."},{type:"zone",heal:.035,range:0,radius:4,dur:5,tick:.5,cd:10,cost:25}),Ne("r","Carga de astas","Antler Charge",{es:"Embestida que empuja.",en:"A charge that knocks back."},{type:"dash",stat:"p",power:7,range:10,speed:30,width:2.2,knock:5,cd:8,cost:30}),Ne("f","Amanecer","Dawn",{es:"Cura total y quita efectos negativos.",en:"Full heal and removes negative effects."},{type:"heal",pct:1,dur:0,team:!0,cleanse:!0,burst:{stat:"m",power:6,radius:8},cd:0})],tortuga:[Ne("q","Embestida","Ram",{es:"Embestida corta.",en:"A short ram."},{type:"dash",stat:"p",power:5.2,range:5,speed:22,width:2.2,cd:1.1,cost:0}),Ne("e","Muro de cristal","Crystal Wall",{es:"Escudo que refleja proyectiles.",en:"A shield that reflects projectiles."},{type:"shield",pct:.32,dur:5,reflect:.3,cd:9,cost:25}),Ne("r","Refugio","Refuge",{es:"Escudo y regeneración para el equipo.",en:"Shield and regeneration for the team."},{type:"heal",pct:.18,dur:5,team:!0,cd:14,cost:35,also:{type:"shield",pct:.15,dur:5}}),Ne("f","Montaña viva","Living Mountain",{es:"Torres de cristal que cierran el paso.",en:"Crystal towers that block the way."},{type:"strike",stat:"m",power:8,count:6,radius:2.6,delay:.5,interval:.12,status:{t:"root",dur:2},cd:0})]},Ni=50,e_=60,fr=i=>Math.round(30+i*12+i*i*1.2),ho=i=>Math.round(80*i+6*i*i),cl=i=>Math.round(40+i*i*3.5);function pr(){let i=1,e=C.rankXp;for(;i<e_&&e>=ho(i);)e-=ho(i),i++;return{rank:i,xp:e,need:ho(i)}}const Sd=[{min:1,es:"Aprendiz",en:"Apprentice"},{min:10,es:"Iniciado",en:"Initiate"},{min:25,es:"Sellador",en:"Sealer"},{min:40,es:"Maestro de Sellos",en:"Seal Master"},{min:55,es:"Archisellador",en:"Archsealer"}];function t_(i){let e=Sd[0];for(const t of Sd)i>=t.min&&(e=t);return e}function sa(){return pr().rank>=10?3:2}function Bh(i,e,t,n=!1){const s=ct[i],[a,r,o,l]=s.stats,c=1+(e-1)*.085,h=Hn[t].mult*(n?1.25:1);return{hp:Math.round((150+r*2.1)*c*h*(n?6:1)),atk:a*c*h,mag:l*c*h,def:r*c*h,spd:5.6+o*.022,cdr:1-o*.0015}}function zh(i){C.bestiary[i].seen||(C.bestiary[i].seen=!0,ht())}function ql(){let i=0;for(const e of En)i+=C.bestiary[e.id].forms.filter(Boolean).length;return i}function n_(i,e,t){const n=ct[i],s={isNew:!1,essence:0,fragments:0,bondUp:!1};if(zh(i),!C.creatures[i])C.creatures[i]={form:0,level:Math.max(1,e),xp:0,bond:t?2:1,bondXp:0,tint:""},C.bestiary[i].forms[0]=!0,s.isNew=!0,C.team.length<sa()&&C.team.push(i);else{const r=C.creatures[i];r.bondXp+=t?40:20,s.bondUp=Hh(r)}const a=t?4:3;return C.fragments[n.el]=(C.fragments[n.el]||0)+a,s.fragments=a,ht(),s}function Hh(i){let e=!1;for(;i.bond<5&&i.bondXp>=60*i.bond;)i.bondXp-=60*i.bond,i.bond++,e=!0;return e}function i_(i,e){const t=C.creatures[i];if(!t)return 0;let n=0;if(t.level>=Ni)return 0;for(t.xp+=Math.round(e);t.level<Ni&&t.xp>=fr(t.level);)t.xp-=fr(t.level),t.level++,n++;return t.level>=Ni&&(t.xp=0),n}function s_(i){const e=C.creatures[i];if(!e||e.level>=Ni)return!1;const t=cl(e.level);return C.essence<t?!1:(C.essence-=t,e.level++,e.xp=0,ht(),!0)}function dl(i){const e=C.creatures[i],t=ct[i];if(!e||e.form>=2)return null;if(e.form===0){const s=C.fragments[t.el]||0;return{to:1,level:20,frags:30,haveFrags:s,boss:!1,ok:e.level>=20&&s>=30}}const n=C.islands.cleared.includes(t.island);return{to:2,level:40,frags:0,boss:!0,bossDone:n,ok:e.level>=40&&n}}function a_(i){const e=dl(i);if(!e||!e.ok)return!1;const t=C.creatures[i],n=ct[i];return e.frags&&(C.fragments[n.el]-=e.frags),t.form=e.to,C.bestiary[i].forms[e.to]=!0,Gh(),ht(),!0}function Gh(){for(const i of En){const e="title_"+i.id;C.bestiary[i.id].forms.every(Boolean)&&!C.titles.includes(e)&&C.titles.push(e)}}function Yl(){const i=ql(),e=[];for(const t of[3,6,12,18,24,30,36]){const n="b"+t;if(i>=t&&!C.milestones.includes(n)){C.milestones.push(n);const s=t===36?200:t>=18?40:20;C.crystals+=s,e.push({forms:t,crystals:s})}}return e.length&&ht(),e}function r_(i,e=Math.random()){const[t,n]=It[i].levels;return Math.round(t+(n-t)*e)}function jl(i,e=1){if(i){if(i.essence&&(C.essence+=Math.round(i.essence*e)),i.crystals&&(C.crystals+=i.crystals),i.ink&&Gd(i.ink),i.fragments){const t=C.team[0]&&ct[C.team[0]],n=t?t.el:"luz";C.fragments[n]=(C.fragments[n]||0)+i.fragments}i.tint&&!C.cosmetics.tints.includes(i.tint)&&C.cosmetics.tints.push(i.tint),i.seal&&!C.cosmetics.seals.includes(i.seal)&&C.cosmetics.seals.push(i.seal),i.effect&&!C.cosmetics.effects.includes(i.effect)&&C.cosmetics.effects.push(i.effect),ht()}}function Vh(){return{can:C.daily.last!==di(),day:C.daily.day%7,reward:Lu[C.daily.day%7]}}function o_(){const i=Vh();return i.can?(jl(i.reward),C.daily.day=(C.daily.day+1)%7,C.daily.last=di(),ht(),i.reward):null}const $h=[{type:"seal",goal:2,es:"Sella {n} criaturas",en:"Seal {n} creatures",essence:400},{type:"perfect",goal:1,es:"Logra {n} trazo perfecto",en:"Land {n} perfect trace",essence:450},{type:"kills",goal:12,es:"Derrota a {n} criaturas",en:"Defeat {n} creatures",essence:350},{type:"ult",goal:3,es:"Usa la Definitiva {n} veces",en:"Use your Ultimate {n} times",essence:350},{type:"runs",goal:2,es:"Completa {n} expediciones",en:"Complete {n} expeditions",essence:500},{type:"advantage",goal:8,es:"Golpea {n} veces con ventaja de dominio",en:"Land {n} hits with domain advantage",essence:300}];function Wh(){if(C.contracts.date===di()&&C.contracts.list.length)return C.contracts.list;const i=[...$h].sort(()=>Math.random()-.5).slice(0,3);return C.contracts={date:di(),list:i.map(e=>({type:e.type,goal:e.goal,progress:0,essence:e.essence,passXp:60,claimed:!1}))},ht(),C.contracts.list}function Kl(i,e){const t=$h.find(n=>n.type===i.type);return(t?t[e]:i.type).replace("{n}",i.goal)}function ss(i,e=1){Wh();const t=[];for(const n of C.contracts.list){if(n.type!==i||n.claimed)continue;const s=n.progress;n.progress=Math.min(n.goal,n.progress+e),s<n.goal&&n.progress>=n.goal&&t.push(n)}return ht(),t}function l_(i){const e=C.contracts.list[i];return!e||e.claimed||e.progress<e.goal?!1:(e.claimed=!0,C.essence+=e.essence,Xh(e.passXp),ht(),!0)}function mr(){return Math.min(Ui.length,Math.floor(C.pass.xp/wl))}function Xh(i){C.pass.xp=Math.min(Ui.length*wl,C.pass.xp+i),ht()}function c_(i,e){const t=Ui[i-1];if(!t||mr()<i)return!1;const n=e==="prem"?C.pass.prem:C.pass.free;return n.includes(i)||e==="prem"&&!C.pass.premium?!1:(n.push(i),jl(e==="prem"?t.prem:t.free),!0)}function js(i,e){if(!i)return e;const t=Xs[i];return t?t.color:e}const d_="./",bs=i=>d_+i,ci={geo:{},tex:{},bbox:{}},h_=new Yv;function u_(i,e){return new Promise(t=>{h_.load(bs(`assets/tex/${i}.webp`),n=>{n.colorSpace=Gt,n.anisotropy=4,ci.tex[i]=n,e(),t(n)},void 0,()=>{e(),t(null)})})}async function qh(i){const e=["halo"];for(const o of["hexagrama","heptagrama","pentagrama"])for(const l of["exterior","medio","interior","completo"])e.push(`circulo_${o}_${l}`);let t=0;const n=e.length+2,s=()=>{t++,i?.(t/n)},[a,r]=await Promise.all([fetch(bs("assets/creatures.json")).then(o=>o.json()).finally(s),fetch(bs("assets/creatures.bin")).then(o=>o.arrayBuffer()).finally(s)]);for(const[o,l]of Object.entries(a)){const c=[];for(const h of l.parts){const d=new Int16Array(r,h.po,h.v*3),u=new Float32Array(h.v*3);for(let v=0;v<h.v;v++)for(let f=0;f<3;f++)u[v*3+f]=(d[v*3+f]+32768)*l.scale[f]+l.min[f];const m=new Uint16Array(r,h.io,h.i),g=new bt;g.setAttribute("position",new Dt(u,3)),g.setIndex(new Dt(m,1)),g.computeBoundingSphere(),g.userData.shared=!0,c.push({mat:h.mat,geometry:g})}ci.geo[o]=c,ci.bbox[o]={min:l.min,max:l.max}}await Promise.all(e.map(o=>u_(o,s)))}const f_=Object.freeze(Object.defineProperty({__proto__:null,assets:ci,loadAssets:qh,url:bs},Symbol.toStringTag,{value:"Module"})),uo={};let $a=null;function p_(i){let e=i>>>0;return()=>(e=e*1664525+1013904223>>>0)/4294967296}function m_(i,e,t,n,s){i.beginPath();const a=2+Math.floor(s()*3);let r=e+(s()-.5)*n,o=t+(s()-.5)*n;i.moveTo(r,o);for(let l=0;l<a;l++)r=e+(s()-.5)*n,o=t+(s()-.5)*n,i.lineTo(r,o);i.stroke()}function bn(i,e,t,n){i.lineWidth=t,i.setLineDash(n||[]),i.beginPath(),i.arc(512,512,e,0,Math.PI*2),i.stroke(),i.setLineDash([])}function fo(i,e,t,n,s=-Math.PI/2){i.beginPath();for(let a=0;a<=e;a++){const r=s+a*t%e/e*Math.PI*2,o=512+Math.cos(r)*n,l=512+Math.sin(r)*n;a===0?i.moveTo(o,l):i.lineTo(o,l)}i.stroke()}function g_(i,e){const t=document.createElement("canvas");t.width=t.height=1024;const n=t.getContext("2d");n.strokeStyle="#fff",n.fillStyle="#fff",n.lineCap="round",n.lineJoin="round",n.shadowColor="#fff",n.shadowBlur=6;const s=p_(i.length*977+e.length*131);if(e==="exterior"){bn(n,500,5),bn(n,470,2.5),bn(n,404,2.5),n.lineWidth=2.5;for(let r=0;r<40;r++){const o=r/40*Math.PI*2;m_(n,512+Math.cos(o)*437,512+Math.sin(o)*437,26,s)}if(i==="corona")for(let r=0;r<24;r++){const o=r/24*Math.PI*2;n.beginPath(),n.moveTo(512+Math.cos(o-.03)*500,512+Math.sin(o-.03)*500),n.lineTo(512+Math.cos(o)*470,512+Math.sin(o)*470),n.lineTo(512+Math.cos(o+.03)*500,512+Math.sin(o+.03)*500),n.stroke()}}else if(e==="medio")if(i==="corona"){bn(n,380,3),bn(n,352,8,[2,26]);for(let r=0;r<12;r++){const o=r/12*Math.PI*2;n.lineWidth=3,n.beginPath(),n.moveTo(512+Math.cos(o)*300,512+Math.sin(o)*300),n.lineTo(512+Math.cos(o)*380,512+Math.sin(o)*380),n.stroke()}}else if(i==="constelacion"){bn(n,380,2,[10,14]);const r=[];for(let o=0;o<9;o++){const l=s()*Math.PI*2,c=230+s()*140;r.push([512+Math.cos(l)*c,512+Math.sin(l)*c])}n.lineWidth=2,n.beginPath(),r.forEach(([o,l],c)=>c?n.lineTo(o,l):n.moveTo(o,l)),n.stroke(),r.forEach(([o,l])=>{n.beginPath(),n.arc(o,l,9,0,Math.PI*2),n.fill()})}else{bn(n,380,3),n.lineWidth=6;for(let r=0;r<3;r++){const o=r/3*Math.PI*2;n.beginPath(),n.arc(512,512,330,o,o+1.4),n.stroke()}}else{if(i==="corona")n.lineWidth=3.5,fo(n,12,5,280),bn(n,110,3);else if(i==="constelacion"){n.lineWidth=3,fo(n,8,3,270);for(let r=0;r<8;r++){const o=r/8*Math.PI*2-Math.PI/2;n.beginPath(),n.arc(512+Math.cos(o)*270,512+Math.sin(o)*270,16,0,Math.PI*2),n.stroke()}}else bn(n,260,4),n.lineWidth=4,n.beginPath(),n.arc(560,490,200,0,Math.PI*2),n.stroke(),fo(n,7,3,240);bn(n,30,6)}const a=new Fh(t);return a.colorSpace=Gt,a.anisotropy=4,a}function v_(i,e){if(["hexagrama","heptagrama","pentagrama"].includes(i))return ci.tex[`circulo_${i}_${e}`];const t=i+e;return uo[t]||(uo[t]=g_(i,e)),uo[t]}function Cs(){if($a)return $a;const i=document.createElement("canvas");i.width=i.height=128;const e=i.getContext("2d"),t=e.createRadialGradient(64,64,0,64,64,64);return t.addColorStop(0,"rgba(255,255,255,1)"),t.addColorStop(.35,"rgba(255,255,255,0.35)"),t.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=t,e.fillRect(0,0,128,128),$a=new Fh(i),$a}const hl=new Ts(1,1);hl.userData.shared=!0;class Zl{constructor(e,t,n=2){this.group=new tn,this.layers=[],this.speed=1,this.intensity=1,this.color=new pe(t),this.design="";const s=new kt({map:Cs(),color:this.color,transparent:!0,opacity:.32,blending:Vt,depthWrite:!1});this.glow=new Ge(hl,s),this.glow.rotation.x=-Math.PI/2,this.glow.scale.setScalar(n*2.6),this.glow.renderOrder=1,this.group.add(this.glow);for(const a of["exterior","medio","interior"]){const r=new kt({transparent:!0,blending:Vt,depthWrite:!1,color:this.color}),o=new Ge(hl,r);o.rotation.x=-Math.PI/2,o.scale.setScalar(n*2),o.position.y=.02+this.layers.length*.004,o.renderOrder=2,this.group.add(o),this.layers.push(o)}this.setDesign(e),this.setColor(t)}setDesign(e){e!==this.design&&(this.design=e,["exterior","medio","interior"].forEach((t,n)=>{this.layers[n].material.map=v_(e,t),this.layers[n].material.needsUpdate=!0}))}setColor(e){this.color.set(e),this.applyIntensity()}setIntensity(e){this.intensity=e,this.applyIntensity()}applyIntensity(){const e=1.25*this.intensity;for(const t of this.layers)t.material.color.copy(this.color).multiplyScalar(e);this.glow.material.color.copy(this.color),this.glow.material.opacity=Math.min(.9,.3*this.intensity)}setOpacity(e){for(const t of this.layers)t.material.opacity=e;this.glow.material.opacity=Math.min(.9,.3*this.intensity)*e}update(e){const t=this.speed;this.layers[0].rotation.z+=e*.12*t,this.layers[1].rotation.z-=e*.22*t,this.layers[2].rotation.z+=e*.4*t}dispose(){for(const e of this.layers)e.material.dispose();this.glow.material.dispose()}}const __=Object.freeze(Object.defineProperty({__proto__:null,MagicCircle:Zl,getGlowTex:Cs},Symbol.toStringTag,{value:"Module"})),Yh={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};class Rs{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}}const x_=new Fl(-1,1,1,-1,0,1);class y_ extends bt{constructor(){super(),this.setAttribute("position",new mt([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new mt([0,2,0,0,2,0],2))}}const M_=new y_;class Jl{constructor(e){this._mesh=new Ge(M_,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,x_)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}}class b_ extends Rs{constructor(e,t){super(),this.textureID=t!==void 0?t:"tDiffuse",e instanceof Ot?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=na.clone(e.uniforms),this.material=new Ot({name:e.name!==void 0?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this.fsQuad=new Jl(this.material)}render(e,t,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this.fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this.fsQuad.render(e))}dispose(){this.material.dispose(),this.fsQuad.dispose()}}class wd extends Rs{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,n){const s=e.getContext(),a=e.state;a.buffers.color.setMask(!1),a.buffers.depth.setMask(!1),a.buffers.color.setLocked(!0),a.buffers.depth.setLocked(!0);let r,o;this.inverse?(r=0,o=1):(r=1,o=0),a.buffers.stencil.setTest(!0),a.buffers.stencil.setOp(s.REPLACE,s.REPLACE,s.REPLACE),a.buffers.stencil.setFunc(s.ALWAYS,r,4294967295),a.buffers.stencil.setClear(o),a.buffers.stencil.setLocked(!0),e.setRenderTarget(n),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),a.buffers.color.setLocked(!1),a.buffers.depth.setLocked(!1),a.buffers.color.setMask(!0),a.buffers.depth.setMask(!0),a.buffers.stencil.setLocked(!1),a.buffers.stencil.setFunc(s.EQUAL,1,4294967295),a.buffers.stencil.setOp(s.KEEP,s.KEEP,s.KEEP),a.buffers.stencil.setLocked(!0)}}class S_ extends Rs{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}}class w_{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){const n=e.getSize(new Pe);this._width=n.width,this._height=n.height,t=new xn(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:Wn}),t.texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new b_(Yh),this.copyPass.material.blending=$n,this.clock=new Qv}swapBuffers(){const e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){const t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){e===void 0&&(e=this.clock.getDelta());const t=this.renderer.getRenderTarget();let n=!1;for(let s=0,a=this.passes.length;s<a;s++){const r=this.passes[s];if(r.enabled!==!1){if(r.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(s),r.render(this.renderer,this.writeBuffer,this.readBuffer,e,n),r.needsSwap){if(n){const o=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(o.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),l.setFunc(o.EQUAL,1,4294967295)}this.swapBuffers()}wd!==void 0&&(r instanceof wd?n=!0:r instanceof S_&&(n=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){const t=this.renderer.getSize(new Pe);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;const n=this._width*this._pixelRatio,s=this._height*this._pixelRatio;this.renderTarget1.setSize(n,s),this.renderTarget2.setSize(n,s);for(let a=0;a<this.passes.length;a++)this.passes[a].setSize(n,s)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}}class E_ extends Rs{constructor(e,t,n=null,s=null,a=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=n,this.clearColor=s,this.clearAlpha=a,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new pe}render(e,t,n){const s=e.autoClear;e.autoClear=!1;let a,r;this.overrideMaterial!==null&&(r=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),this.clearAlpha!==null&&(a=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(a),this.overrideMaterial!==null&&(this.scene.overrideMaterial=r),e.autoClear=s}}const T_={uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new pe(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};class Ss extends Rs{constructor(e,t,n,s){super(),this.strength=t!==void 0?t:1,this.radius=n,this.threshold=s,this.resolution=e!==void 0?new Pe(e.x,e.y):new Pe(256,256),this.clearColor=new pe(0,0,0),this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let a=Math.round(this.resolution.x/2),r=Math.round(this.resolution.y/2);this.renderTargetBright=new xn(a,r,{type:Wn}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let d=0;d<this.nMips;d++){const u=new xn(a,r,{type:Wn});u.texture.name="UnrealBloomPass.h"+d,u.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(u);const m=new xn(a,r,{type:Wn});m.texture.name="UnrealBloomPass.v"+d,m.texture.generateMipmaps=!1,this.renderTargetsVertical.push(m),a=Math.round(a/2),r=Math.round(r/2)}const o=T_;this.highPassUniforms=na.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=s,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new Ot({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];const l=[3,5,7,9,11];a=Math.round(this.resolution.x/2),r=Math.round(this.resolution.y/2);for(let d=0;d<this.nMips;d++)this.separableBlurMaterials.push(this.getSeperableBlurMaterial(l[d])),this.separableBlurMaterials[d].uniforms.invSize.value=new Pe(1/a,1/r),a=Math.round(a/2),r=Math.round(r/2);this.compositeMaterial=this.getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;const c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new R(1,1,1),new R(1,1,1),new R(1,1,1),new R(1,1,1),new R(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors;const h=Yh;this.copyUniforms=na.clone(h.uniforms),this.blendMaterial=new Ot({uniforms:this.copyUniforms,vertexShader:h.vertexShader,fragmentShader:h.fragmentShader,blending:Vt,depthTest:!1,depthWrite:!1,transparent:!0}),this.enabled=!0,this.needsSwap=!1,this._oldClearColor=new pe,this.oldClearAlpha=1,this.basic=new kt,this.fsQuad=new Jl(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this.basic.dispose(),this.fsQuad.dispose()}setSize(e,t){let n=Math.round(e/2),s=Math.round(t/2);this.renderTargetBright.setSize(n,s);for(let a=0;a<this.nMips;a++)this.renderTargetsHorizontal[a].setSize(n,s),this.renderTargetsVertical[a].setSize(n,s),this.separableBlurMaterials[a].uniforms.invSize.value=new Pe(1/n,1/s),n=Math.round(n/2),s=Math.round(s/2)}render(e,t,n,s,a){e.getClearColor(this._oldClearColor),this.oldClearAlpha=e.getClearAlpha();const r=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),a&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this.fsQuad.material=this.basic,this.basic.map=n.texture,e.setRenderTarget(null),e.clear(),this.fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this.fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this.fsQuad.render(e);let o=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this.fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=o.texture,this.separableBlurMaterials[l].uniforms.direction.value=Ss.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[l]),e.clear(),this.fsQuad.render(e),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=Ss.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[l]),e.clear(),this.fsQuad.render(e),o=this.renderTargetsVertical[l];this.fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this.fsQuad.render(e),this.fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,a&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(n),this.fsQuad.render(e)),e.setClearColor(this._oldClearColor,this.oldClearAlpha),e.autoClear=r}getSeperableBlurMaterial(e){const t=[];for(let n=0;n<e;n++)t.push(.39894*Math.exp(-.5*n*n/(e*e))/e);return new Ot({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new Pe(.5,.5)},direction:{value:new Pe(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}getCompositeMaterial(e){return new Ot({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}}Ss.BlurDirectionX=new Pe(1,0);Ss.BlurDirectionY=new Pe(0,1);const A_={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`
	
		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#elif defined( NEUTRAL_TONE_MAPPING )

				gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};class C_ extends Rs{constructor(){super();const e=A_;this.uniforms=na.clone(e.uniforms),this.material=new $v({name:e.name,uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader}),this.fsQuad=new Jl(this.material),this._outputColorSpace=null,this._toneMapping=null}render(e,t,n){this.uniforms.tDiffuse.value=n.texture,this.uniforms.toneMappingExposure.value=e.toneMappingExposure,(this._outputColorSpace!==e.outputColorSpace||this._toneMapping!==e.toneMapping)&&(this._outputColorSpace=e.outputColorSpace,this._toneMapping=e.toneMapping,this.material.defines={},Qe.getTransfer(this._outputColorSpace)===ot&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===eh?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===th?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===nh?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===Tl?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===ih?this.material.defines.AGX_TONE_MAPPING="":this._toneMapping===sh&&(this.material.defines.NEUTRAL_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this.fsQuad.render(e))}dispose(){this.material.dispose(),this.fsQuad.dispose()}}const ul=new pe("#090817"),fl={bloom:!0},Wa=/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)||navigator.maxTouchPoints>1&&window.innerWidth<1100,kn={low:{dpr:1,bloom:!1,aa:!1,shadows:!1},medium:{dpr:1.5,bloom:!0,bloomScale:.5,aa:!1},high:{dpr:2,bloom:!0,bloomScale:.5,aa:!0}};class R_{constructor(e){this.canvas=e,this.qualityName="auto",this.q=Wa?kn.medium:kn.high,this.renderer=new Hv({canvas:e,antialias:!Wa,powerPreference:"high-performance",alpha:!1,preserveDrawingBuffer:!1}),this.renderer.setClearColor(ul,1),this.renderer.outputColorSpace=Gt,this.renderer.toneMapping=Tl,this.renderer.toneMappingExposure=1.05,this.scene=null,this.camera=null,this.composer=null,this.bloom=null,this.fpsSamples=[],this.autoChecked=!1,window.addEventListener("resize",()=>this.resize()),this.resize()}get isMobile(){return Wa}setQuality(e){this.qualityName=e,this.q=e==="auto"?Wa?kn.medium:kn.high:kn[e],this.autoChecked=e!=="auto",this.buildComposer(),this.resize()}setScene(e,t){this.scene=e,this.camera=t,this.buildComposer(),this.resize()}buildComposer(){if(!this.scene||(this.composer&&this.composer.dispose(),this.composer=null,fl.bloom=!!this.q.bloom,!this.q.bloom))return;const e=this.renderer.getSize(new Pe);this.composer=new w_(this.renderer),this.composer.addPass(new E_(this.scene,this.camera)),this.bloom=new Ss(new Pe(e.x*this.q.bloomScale,e.y*this.q.bloomScale),.9,.5,.62),this.composer.addPass(this.bloom),this.composer.addPass(new C_)}resize(){const e=window.innerWidth,t=window.innerHeight,n=Math.min(window.devicePixelRatio||1,this.q.dpr);this.renderer.setPixelRatio(n),this.renderer.setSize(e,t,!1),this.camera&&(this.camera.aspect=e/t,this.camera.fov=e<t?62:45,this.camera.updateProjectionMatrix()),this.composer&&(this.composer.setPixelRatio(n),this.composer.setSize(e,t))}render(e){!this.scene||!this.camera||(this.composer?this.composer.render(e):this.renderer.render(this.scene,this.camera),this.adapt(e))}adapt(e){if(this.autoChecked||this.qualityName!=="auto"||(this.fpsSamples.push(e),this.fpsSamples.length<180))return;const t=this.fpsSamples.reduce((n,s)=>n+s,0)/this.fpsSamples.length;this.fpsSamples=[],t>1/28?(this.q===kn.high?this.q=kn.medium:this.q===kn.medium&&(this.q=kn.low,this.autoChecked=!0),this.buildComposer(),this.resize()):this.autoChecked=!0}}const P_=new Set(["Brillo","Plumas","Estrellas","Cristal"]),L_=new Set(["fenix","grifo","wyvern","leviatan"]),po=new pe;function Ed(i,e){if(i==="prisma")return po.setHSL(e*.12%1,.95,.62);if(i==="aurora"){const t=["#9fefff","#3dff88","#b06bff","#ff4fd2"],n=e*.25%t.length,s=Math.floor(n);return po.set(t[s]).lerp(new pe(t[(s+1)%t.length]),n-s)}return po.set(i)}class pl{constructor(e,{glow:t,form:n=0,boss:s=!1,seal:a,circle:r=!0,scale:o}={}){const l=ct[e];this.id=e,this.def=l,this.glowId=t||l.color,this.group=new tn,this.pivot=new tn,this.group.add(this.pivot),this.flyer=L_.has(e),this.t=Math.random()*10,this.flash=0,this.flashColor=new pe(1,1,1),this.lunge=0,this.squash=0,this.tilt=0,this.moveAmt=0,this.statusTint=null,this.opacity=1,this.glowPulse=1;const c=ci.bbox[e],h=c.max[1]-c.min[1],d=Math.pow(3.6/h,.55),u=(o??Hn[n].scale*(s?1.75:1))*d;this.scale=u,this.height=h*u,this.radius=Math.max(-c.min[0],c.max[0],-c.min[2],c.max[2])*u*.62;const m=new pe(l.body),g=new pe(l.bone);this.bodyMats=[],this.glowMats=[],this.model=new tn,this.model.scale.setScalar(u);for(const f of ci.geo[e]){let p;if(P_.has(f.mat))p=new kt({color:16777215}),p.userData.k=f.mat==="Cristal"?1.6:2.4,this.glowMats.push(p);else if(f.mat==="Ojos")p=new kt({color:16777215}),p.userData.k=3.2,p.userData.eyes=!0,this.glowMats.push(p);else if(f.mat==="CristalTenue")p=new kt({color:16777215,transparent:!0,opacity:.42,depthWrite:!1}),p.userData.k=.9,this.glowMats.push(p);else{let w=m.clone();f.mat==="Hueso"?w=g.clone():f.mat==="Cuerpo2"||f.mat==="Plumaje"?w.multiplyScalar(1.22):f.mat==="Oscuro"?w.multiplyScalar(.6):f.mat==="Membrana"&&w.multiplyScalar(1.1),p=new $l({color:w,roughness:.72,metalness:.18,flatShading:!0,emissive:0,side:f.mat==="Membrana"?Yt:Yn}),p.userData.base=w.clone(),this.bodyMats.push(p)}const E=new Ge(f.geometry,p);this.model.add(E)}if(this.pivot.add(this.model),r&&(this.circle=new Zl(a||l.circle,l.color,Math.max(1.4,this.radius*1.9)),this.group.add(this.circle.group)),l.halo){const f=new cr({map:ci.tex.halo,color:16777215,transparent:!0,blending:Vt,depthWrite:!1});this.halo=new ol(f),this.halo.scale.setScalar(this.height*.55),this.halo.position.set(0,this.height*.82,-.35*u),this.pivot.add(this.halo)}const v=new cr({map:Cs(),transparent:!0,opacity:.09,blending:Vt,depthWrite:!1});this.aura=new ol(v),this.aura.scale.setScalar(this.height*1.4),this.aura.position.y=this.height*.5,this.pivot.add(this.aura),this.applyGlow()}setGlow(e){this.glowId=e||this.def.color,this.applyGlow()}setSeal(e){this.circle&&this.circle.setDesign(e||this.def.circle)}applyGlow(){const e=Ed(this.glowId,this.t),t=fl.bloom?1:1.35;this.aura.material.opacity=(fl.bloom?.09:.2)*this.opacity;for(const n of this.glowMats)n.userData.eyes?n.color.copy(e).lerp(new pe(1,1,1),.6).multiplyScalar(n.userData.k*this.glowPulse*t):n.color.copy(e).multiplyScalar(n.userData.k*this.glowPulse*t);this.circle&&this.circle.setColor(e),this.halo&&this.halo.material.color.copy(e).multiplyScalar(1.6),this.aura.material.color.copy(e)}get glowColor(){return Ed(this.glowId,this.t).clone()}hit(e){this.flash=1,e?this.flashColor.set(e):this.flashColor.setRGB(1,1,1),this.squash=.12}attack(){this.lunge=1}setOpacity(e){this.opacity=e;const t=e<1;for(const n of[...this.bodyMats,...this.glowMats])n.userData.k!==.9&&(n.transparent=t,n.opacity=e,n.depthWrite=!t);this.circle&&this.circle.setOpacity(e),this.aura.material.opacity=.09*e,this.halo&&(this.halo.material.opacity=e)}update(e,{moving:t=0,heading:n,stunned:s=!1}={}){this.t+=e;const a=this.t;this.moveAmt+=(t-this.moveAmt)*Math.min(1,e*8);const r=this.moveAmt,o=1+Math.sin(a*2.2)*.018*(1-r),l=Math.abs(Math.sin(a*9))*.12*r*this.scale*2,c=this.flyer?.35*this.scale*2+Math.sin(a*1.8)*.12*this.scale*2:0;this.pivot.position.y=l+c,this.squash=Math.max(0,this.squash-e*.8);const h=this.squash*Math.sin(a*60);this.model.scale.set(this.scale*(1+h),this.scale*o*(1-h),this.scale*(1+h)),this.lunge=Math.max(0,this.lunge-e*4);const d=Math.sin(this.lunge*Math.PI)*.6*this.scale*2;if(this.model.position.z=d,n!==void 0){let u=n-this.pivot.rotation.y;for(;u>Math.PI;)u-=Math.PI*2;for(;u<-Math.PI;)u+=Math.PI*2;this.pivot.rotation.y+=u*Math.min(1,e*10),this.tilt+=(Math.max(-.25,Math.min(.25,u*.6))*r-this.tilt)*Math.min(1,e*6)}this.pivot.rotation.z=-this.tilt,this.pivot.rotation.x=r*.06,s&&(this.pivot.rotation.z+=Math.sin(a*30)*.03),this.glowPulse=1+Math.sin(a*3.4)*.12,this.flash=Math.max(0,this.flash-e*5);for(const u of this.bodyMats)this.statusTint?u.emissive.copy(this.statusTint).multiplyScalar(.35):u.emissive.setRGB(0,0,0),this.flash>0&&u.emissive.lerp(this.flashColor,this.flash*.8);this.applyGlow(),this.circle&&this.circle.update(e),this.halo&&(this.halo.material.rotation+=e*.15)}dispose(){for(const e of[...this.bodyMats,...this.glowMats])e.dispose();this.circle?.dispose(),this.aura.material.dispose(),this.halo?.material.dispose()}}const Td=new Set(["stun","freeze","petrify"]),D_=new Set(["burn","poison","slow","stun","freeze","petrify","root","blind","mark"]),Ad={freeze:new pe("#9fefff"),petrify:new pe("#8a8a8a"),poison:new pe("#3dff88"),burn:new pe("#ff7a2e"),stun:new pe("#fff2a0"),root:new pe("#ff4fd2")};let I_=0;class Xa{constructor(e,{side:t,level:n=1,form:s=0,boss:a=!1,glow:r,seal:o,owned:l}={}){this.uid=++I_,this.id=e,this.def=ct[e],this.side=t,this.level=n,this.form=s,this.boss=a,this.owned=l||null,this.stats=Bh(e,n,s,a),this.maxHp=this.stats.hp,this.hp=this.maxHp,this.energy=100,this.seal=0,this.cds={q:0,e:0,r:0},this.statuses=[],this.shield=0,this.shieldT=0,this.reflect=0,this.buffs=[],this.pos=new R,this.vel=new R,this.facing=0,this.alive=!0,this.fainted=!1,this.iframes=0,this.dodgeCd=0,this.castLock=0,this.channel=null,this.dash=null,this.windup=null,this.sealable=!1,this.invuln=!1,this.moving=0,this.knock=new R,this.pullTo=null,this.aiT=Math.random(),this.aiGcd=1+Math.random(),this.strafe=Math.random()<.5?1:-1,this.target=null,this.usedRevive=!1,this.abilities=Oh[e],this.visual=new pl(e,{glow:r,form:s,boss:a,seal:o}),this.radius=this.visual.radius,this.color=new pe(this.def.color)}ability(e){return this.abilities.find(t=>t.key===e)}hasAbility(e){return e==="r"?this.form>=1||this.boss:!0}has(e){return this.statuses.some(t=>t.t===e)}get stunned(){return this.statuses.some(e=>Td.has(e.t))}get rooted(){return this.stunned||this.has("root")}get speedMul(){let e=1;for(const t of this.statuses)t.t==="slow"&&(e=Math.min(e,1-t.val));for(const t of this.buffs)t.spd&&(e*=1+t.spd);return e}get atkMul(){let e=1;for(const t of this.buffs)t.atk&&(e*=1+t.atk);return this.has("blind")&&(e*=.5),e}get cdrMul(){let e=this.stats.cdr;for(const t of this.buffs)t.cdr&&(e*=1-t.cdr);return e}get lifesteal(){let e=0;for(const t of this.buffs)t.lifesteal&&(e+=t.lifesteal);return e}addStatus(e,t,n=0){let s=e.dur;if(this.boss&&(Td.has(e.t)||e.t==="root")&&(s*=.35),this.anchor)return;const a=this.statuses.find(o=>o.t===e.t),r={t:e.t,dur:s,val:e.val||0,src:t,tickT:.5};(e.t==="burn"||e.t==="poison")&&(r.dps=n*(e.val||.5)*2/Math.max(1,e.dur)),a?Object.assign(a,r):this.statuses.push(r)}cleanse(){this.statuses=this.statuses.filter(e=>!D_.has(e.t))}addShield(e,t,n=0){this.shield=Math.max(this.shield,e),this.shieldT=Math.max(this.shieldT,t),this.reflect=Math.max(this.reflect,n)}addBuff(e){this.buffs.push({...e,t:e.dur})}heal(e){if(!this.alive)return 0;const t=this.hp;return this.hp=Math.min(this.maxHp,this.hp+e),this.hp-t}tick(e,t){for(const s of["q","e","r"])this.cds[s]=Math.max(0,this.cds[s]-e);this.energy=Math.min(100,this.energy+e*10),this.iframes=Math.max(0,this.iframes-e),this.dodgeCd=Math.max(0,this.dodgeCd-e),this.castLock=Math.max(0,this.castLock-e),this.shieldT>0&&(this.shieldT-=e,this.shieldT<=0&&(this.shield=0,this.reflect=0));for(let s=this.buffs.length-1;s>=0;s--)this.buffs[s].t-=e,this.buffs[s].t<=0&&this.buffs.splice(s,1);let n=null;for(let s=this.statuses.length-1;s>=0;s--){const a=this.statuses[s];a.dur-=e,a.dps&&(a.tickT-=e,a.tickT<=0&&(a.tickT+=.5,t?.(this,a.dps*.5,a))),Ad[a.t]&&!n&&(n=Ad[a.t]),a.dur<=0&&this.statuses.splice(s,1)}this.visual.statusTint=n}dispose(){this.visual.dispose()}}const gn=17;function ds(i,e,t=!0){const n=i.attributes.position;for(let s=0;s<n.count;s++)t&&n.getY(s)>.55||n.setXYZ(s,n.getX(s)+(Math.random()-.5)*e,n.getY(s)+(Math.random()-.5)*e,n.getZ(s)+(Math.random()-.5)*e);return i.computeVertexNormals(),i}function wn(i){return new $l({color:new pe(i),roughness:.92,metalness:.05,flatShading:!0})}function tr(i,e=2){return new kt({color:new pe(i).multiplyScalar(e)})}function jh(i=900,e=140){const t=new bt,n=new Float32Array(i*3);for(let a=0;a<i;a++){const r=Math.random()*2-1,o=Math.random()*Math.PI*2,l=e*(.7+Math.random()*.3),c=Math.sqrt(1-r*r);n[a*3]=Math.cos(o)*c*l,n[a*3+1]=Math.abs(r)*l*.9-10,n[a*3+2]=Math.sin(o)*c*l}t.setAttribute("position",new Dt(n,3));const s=new zl({color:13617407,size:1.6,sizeAttenuation:!1,transparent:!0,opacity:.8,depthWrite:!1});return new Hl(t,s)}function Kh(i){i.background=ul.clone(),i.fog=new Ol(ul,.014);const e=new jv(9274568,1380906,1.6);i.add(e);const t=new Md(15261951,1.7);t.position.set(-6,14,10),i.add(t);const n=new Md(9076223,1.2);n.position.set(8,6,-12),i.add(n);const s=[];for(let a=0;a<4;a++){const r=new Zv(16777215,0,14,1.6);i.add(r),s.push(r)}return{hemi:e,key:t,rim:n,pool:s}}function U_(i,e,t){const n=new tn,s=new pe(t),a=ds(new ui(gn+2.5,gn+1.5,1.4,48,2),.5),r=new Ge(a,wn("#1d1936"));r.position.y=-.7,n.add(r);const o=ds(new Ms(gn+1.6,16,18,4),1.6,!1);o.rotateX(Math.PI);const l=new Ge(o,wn("#141127"));l.position.y=-9.3,n.add(l);const c=new Ge(new Vl(gn+2.3,.04,6,120),tr(s,.55));c.rotation.x=Math.PI/2,c.position.y=.02,n.add(c);const h=new Zl(e.sealDesign||"hexagrama",t,gn+1);h.setIntensity(.035),h.speed=.25,h.group.position.y=.005,n.add(h.group);for(let d=0;d<9;d++){const u=3+Math.random()*6,m=ds(new Ms(u,u*2.2,7,2),u*.25,!1);m.rotateX(Math.PI);const g=new Ge(m,wn("#16132b")),v=d/9*Math.PI*2+Math.random()*.4,f=48+Math.random()*40;g.position.set(Math.cos(v)*f,-6+Math.random()*14,Math.sin(v)*f),n.add(g);const p=new ui(u*1.05,u,.6,7),E=new Ge(p,wn("#221d40"));E.position.copy(g.position).add(new R(0,u*1.1,0)),n.add(E)}return N_(n,e.props,s),n.add(jh()),i.add(n),{root:n,floorSeal:h,update:d=>h.update(d)}}function Cd(i,e){const t=Math.random()*Math.PI*2,n=i+Math.random()*(e-i);return[Math.cos(t)*n,Math.sin(t)*n]}function N_(i,e,t){const n=tr(t,1.1),s=14;for(let a=0;a<s;a++){const[r,o]=Cd(gn-.5,gn+2);let l;switch(e){case"flores":{l=new tn;for(let c=0;c<5;c++){const h=new Ge(new ui(.03,.04,.6+Math.random()*.5,4),wn("#2e3a35"));h.position.set((Math.random()-.5)*1.6,.35,(Math.random()-.5)*1.6);const d=new Ge(new ia(.14),n);d.position.copy(h.position).add(new R(0,.38,0)),l.add(h,d)}break}case"pilares":case"estatuas":{const c=2+Math.random()*3,h=ds(new li(1,c,1,1,3,1),.15,!1);if(h.translate(0,c/2,0),l=new Ge(h,wn(e==="estatuas"?"#4a5552":"#2b2648")),e==="pilares"){const d=new Ge(new li(1.04,.08,1.04),n);d.position.y=c*.6,l.add(d)}else{const d=new Ge(new br(.45,0),wn("#4a5552"));d.position.y=c+.35,l.add(d)}l.rotation.y=Math.random()*Math.PI,l.rotation.z=(Math.random()-.5)*.25;break}case"hielo":case"corales":case"cristales":{l=new tn;const c=e==="hielo"?"#a8dff0":null;for(let h=0;h<3;h++){const d=1+Math.random()*2.6,u=new Ms(.3+Math.random()*.3,d,5);u.translate(0,d/2,0);const m=e==="cristales"||e==="corales"?new Ge(u,tr(t,1.1)):new Ge(u,new $l({color:c,roughness:.2,metalness:.1,flatShading:!0,transparent:!0,opacity:.85}));m.position.set((Math.random()-.5)*1.2,0,(Math.random()-.5)*1.2),m.rotation.set((Math.random()-.5)*.5,0,(Math.random()-.5)*.5),l.add(m)}break}case"lava":{const c=new li(3+Math.random()*3,.05,.12);l=new Ge(c,tr("#ff7a2e",2)),l.position.y=.02,l.rotation.y=Math.random()*Math.PI;const[h,d]=Cd(5,gn-2);l.position.x=h,l.position.z=d,i.add(l),l=new Ge(ds(new ur(.8+Math.random()),.2,!1),wn("#241c2a"));break}case"telas":{l=new tn;const c=new Ge(new ui(.12,.2,3.5,5),wn("#2a2140"));c.position.y=1.75,l.add(c);const h=[];for(let u=0;u<6;u++)h.push(new R(0,3.3,0),new R(Math.cos(u)*2.5,.1,Math.sin(u)*2.5));const d=new bt().setFromPoints(h);l.add(new Vv(d,new yr({color:new pe(t).multiplyScalar(1.4)})));break}default:if(l=new Ge(ds(new ur(.6+Math.random()*1.2),.25,!1),wn(e==="vacio"?"#2a1d45":"#231f3d")),l.position.y=1+Math.random()*3,l.userData.float=Math.random()*6,e==="estrellas"||e==="vacio"){const c=new Ge(new ia(.12),n);c.position.y=1.2,l.add(c)}}l.position.x=r,l.position.z=o,i.add(l)}}const qa=new R,Zh=new R(0,1,0);function mo(i,e){const t=new R(e.x-i.x,0,e.z-i.z),n=t.length();return n>1e-4?t.divideScalar(n):new R(Math.sin(0),0,1)}function Rd(i,e,t,n,s){qa.set(t.pos.x-i.pos.x,0,t.pos.z-i.pos.z);const a=qa.length();return a>n+t.radius?!1:a<t.radius+.5?!0:(qa.divideScalar(a),Math.acos(ea.clamp(qa.dot(e),-1,1))<=ea.degToRad(s/2)+Math.atan2(t.radius,a))}function bi(i,e){return Math.hypot(i.x-e.x,i.z-e.z)}function go(i,e,t,n){const s=e.visual.glowColor;e.facing=Math.atan2(n.dir.x,n.dir.z),e.visual.attack(),e.castLock=t.type==="cone"&&t.dur?t.dur:.22;const a=i.foesOf(e);switch(t.type){case"melee":{if(Ee.whoosh(),n.target){const r=bi(e.pos,n.target.pos)-n.target.radius-e.radius*.5;r>t.range*.7&&r<t.range+5&&(e.dash={dir:n.dir.clone(),left:Math.min(5,r-t.range*.5),speed:30,ab:null,hit:new Set})}for(let r=0;r<(t.hits||1);r++)i.later(r*.13,()=>{if(!e.alive)return;e.visual.attack();const o=e.pos.clone().addScaledVector(n.dir,t.range*.55);i.fx.particles.burst(o,s,8,5,.35,.5,{dy:.8});for(const l of i.foesOf(e))Rd(e,n.dir,l,t.range+e.radius*.5,t.arc)&&i.damage(e,l,t.power,t.stat,t)});break}case"projectile":{const r=t.count||1,o=ea.degToRad(t.spread||0);Ee.shoot();for(let l=0;l<r;l++){const c=r===1?0:-o/2+o*l/(r-1),h=n.dir.clone().applyAxisAngle(Zh,c);i.spawnProjectile(e,t,h,s)}break}case"cone":{Ee.breath();const r=t.ticks||1,o=t.dur||0,l=n.dir.clone();for(let c=0;c<r;c++)i.later(o*c/r,()=>{if(!e.alive||e.stunned&&o)return;const h=e.side==="player"&&i.player===e?i.aimDir(e,l):l;e.facing=Math.atan2(h.x,h.z),F_(i,e,h,t,s);for(const d of i.foesOf(e))Rd(e,h,d,t.range,t.arc)&&(i.damage(e,d,t.power,t.stat,t),t.knock&&i.knockback(d,h,t.knock),c===r-1&&t.endStatus&&d.addStatus(t.endStatus,e))});break}case"aoe":{const r=t.range?Pd(n.pos,e.pos,t.range):e.pos.clone(),o=!t.range,l=()=>{if(!e.alive)return;const c=o?e.pos.clone():r;Ee.boom(),i.fx.shockwave(c,s,t.radius),i.fx.particles.ring(c,s,t.radius*.6,36,.7,.6,t.radius*.8),i.shake(.25);const h=t.ticks||1;for(let d=0;d<h;d++)i.later((t.dur||0)*d/h,()=>{const u=o?e.pos:c;h>1&&i.fx.particles.ring(u,s,t.radius*.8,24,.5,.5,-t.radius);for(const m of i.foesOf(e))bi(m.pos,u)<=t.radius+m.radius&&(t.power?i.damage(e,m,t.power,t.stat,t):t.status&&m.addStatus(t.status,e),t.pull&&(m.pullTo={pos:u,speed:t.pull,t:Math.max(.4,t.dur||.5)}));t.selfHeal&&i.healFx(e,e.maxHp*t.selfHeal)});t.final&&i.later((t.dur||0)+.05,()=>{const d=o?e.pos:c;i.fx.shockwave(d,s,t.radius*.6),Ee.boom(),i.shake(.4);for(const u of i.foesOf(e))bi(u.pos,d)<=t.radius*.6+u.radius&&i.damage(e,u,t.final,t.stat,t)})};t.delay?(i.fx.telegraph({pos:o?e.pos:r,radius:t.radius,color:e.def.color,time:t.delay}),i.later(t.delay,l)):l();break}case"dash":{Ee.whoosh();const r=n.target?Math.min(t.range,bi(e.pos,n.target.pos)+1.5):t.range;e.dash={dir:n.dir.clone(),left:r,speed:t.speed,ab:t,hit:new Set,color:s},e.iframes=Math.max(e.iframes,.2);break}case"heal":{Ee.heal();const r=t.team?i.teamOf(e):[e];for(const o of r){t.cleanse&&o.cleanse();const l=o.maxHp*t.pct;if(!t.dur)i.healFx(o,l);else{const c=Math.ceil(t.dur/.5);for(let h=1;h<=c;h++)i.later(h*.5,()=>i.healFx(o,l/c,h===1))}}if(i.fx.particles.pillar(e.pos,s,6,40,1,.6),t.burst){i.fx.shockwave(e.pos,s,t.burst.radius);for(const o of a)bi(o.pos,e.pos)<=t.burst.radius+o.radius&&i.damage(e,o,t.burst.power,t.burst.stat,t)}break}case"shield":{Ee.shield(),e.addShield(e.maxHp*t.pct,t.dur,t.reflect||0),i.fx.shockwave(e.pos,s,e.radius*2.5,.5);break}case"buff":{Ee.buff(),e.addBuff(t),i.fx.particles.pillar(e.pos,s,8,50,.8,.7),i.fx.shockwave(e.pos,s,4);break}case"zone":{const r=t.range?Pd(n.pos,e.pos,t.range):e.pos.clone();i.spawnZone(e,t,r,s),Ee.boom();break}case"strike":{Ee.zap();const r=[],o=a.filter(c=>c.has("mark")),l=o.length?o:a;for(let c=0;c<t.count;c++){let h;if(t.area||!l.length){const d=l.length?l[c%l.length].pos:e.pos;h=new R(d.x+(Math.random()-.5)*9,0,d.z+(Math.random()-.5)*9)}else h=l[c%l.length].pos.clone().add(new R((Math.random()-.5)*1.2,0,(Math.random()-.5)*1.2));hs(h,1),r.push(h)}r.forEach((c,h)=>{i.later(h*(t.interval||.15),()=>{i.fx.telegraph({pos:c,radius:t.radius,color:e.def.color,time:t.delay}),i.later(t.delay,()=>{e.id==="tortuga"?i.crystalTower(c,s):i.fx.bolt(c.clone().add(new R(0,14,0)),c,s,.25),i.fx.beam(c,s,10,.3,.3),i.fx.particles.burst(c,s,16,7,.6,.6),Ee.zap(),i.shake(.15);for(const d of i.foesOf(e))bi(d.pos,c)<=t.radius+d.radius&&i.damage(e,d,t.power,t.stat,t)})})});break}case"mines":{Ee.summon(e.def.el);for(let r=0;r<t.count;r++){const o=e.facing+(r-(t.count-1)/2)*.9,l=e.pos.clone().add(new R(Math.sin(o)*3,0,Math.cos(o)*3));hs(l,1),i.spawnMine(e,t,l,s)}break}case"revive":{Ee.ult(),e.side==="player"&&i.reviveTeam(t.pct),i.healFx(e,e.maxHp*t.pct),i.fx.particles.pillar(e.pos,s,12,90,1.4,.9),i.fx.shockwave(e.pos,s,t.radius);for(const r of a)bi(r.pos,e.pos)<=t.radius+r.radius&&(i.damage(e,r,t.power,t.stat,t),r.addStatus({t:"burn",dur:3,val:.5},e,10));break}}if(t.also){const r=t.also;if(r.type==="shield"){const o=t.key==="f"||t.team?i.teamOf(e):[e];for(const l of o)l.addShield(l.maxHp*r.pct,r.dur,r.reflect||0);Ee.shield()}r.type==="buff"&&e.addBuff(r)}}function F_(i,e,t,n,s){const a=ea.degToRad(n.arc);for(let r=0;r<14;r++){const o=(Math.random()-.5)*a,l=t.clone().applyAxisAngle(Zh,o),c=n.range*(1.6+Math.random());i.fx.particles.spawn(e.pos.x+l.x*e.radius,1+Math.random()*.6,e.pos.z+l.z*e.radius,l.x*c,Math.random()*1.5,l.z*c,s,.45,.9,0,1.2)}}function Pd(i,e,t){const n=new R(i.x-e.x,0,i.z-e.z);return n.length()>t&&n.setLength(t),hs(new R(e.x+n.x,0,e.z+n.z),1)}function hs(i,e=0){const t=Math.hypot(i.x,i.z),n=gn-e;return t>n&&(i.x*=n/t,i.z*=n/t),i}const ns=3e3,k_=`
attribute float size;
attribute vec4 pcolor;
varying vec4 vColor;
void main() {
  vColor = pcolor;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_PointSize = size * (300.0 / -mv.z);
  gl_Position = projectionMatrix * mv;
}`,O_=`
uniform sampler2D map;
varying vec4 vColor;
void main() {
  vec4 t = texture2D(map, gl_PointCoord);
  gl_FragColor = vec4(vColor.rgb * t.a * vColor.a, 1.0);
}`;class B_{constructor(e){this.geo=new bt,this.pos=new Float32Array(ns*3),this.col=new Float32Array(ns*4),this.size=new Float32Array(ns),this.geo.setAttribute("position",new Dt(this.pos,3).setUsage(Dr)),this.geo.setAttribute("pcolor",new Dt(this.col,4).setUsage(Dr)),this.geo.setAttribute("size",new Dt(this.size,1).setUsage(Dr)),this.mat=new Ot({uniforms:{map:{value:Cs()}},vertexShader:k_,fragmentShader:O_,transparent:!0,depthWrite:!1,blending:Vt}),this.points=new Hl(this.geo,this.mat),this.points.frustumCulled=!1,this.points.renderOrder=5,e.add(this.points),this.p=[];for(let t=0;t<ns;t++)this.p.push({life:0});this.cursor=0}spawn(e,t,n,s,a,r,o,l,c,h=0,d=0){const u=this.p[this.cursor];this.cursor=(this.cursor+1)%ns,u.x=e,u.y=t,u.z=n,u.vx=s,u.vy=a,u.vz=r,u.r=o.r,u.g=o.g,u.b=o.b,u.life=l,u.max=l,u.size=c,u.grav=h,u.drag=d}burst(e,t,n=20,s=6,a=.7,r=.6,o={}){const l=t.isColor?t:new pe(t),c=o.up??.5;for(let h=0;h<n;h++){const d=Math.random()*Math.PI*2,u=(Math.random()-.3)*Math.PI*c,m=s*(.4+Math.random()*.6);this.spawn(e.x,e.y+(o.dy??.5),e.z,Math.cos(d)*Math.cos(u)*m,Math.sin(u)*m+(o.lift??0),Math.sin(d)*Math.cos(u)*m,l,a*(.6+Math.random()*.6),r*(.6+Math.random()*.8),o.grav??-4,o.drag??1.5)}}ring(e,t,n,s=40,a=.6,r=.5,o=3){const l=t.isColor?t:new pe(t);for(let c=0;c<s;c++){const h=c/s*Math.PI*2;this.spawn(e.x+Math.cos(h)*n,e.y+.2,e.z+Math.sin(h)*n,Math.cos(h)*o,.6+Math.random(),Math.sin(h)*o,l,a,r,0,1)}}pillar(e,t,n=8,s=50,a=1,r=.7){const o=t.isColor?t:new pe(t);for(let l=0;l<s;l++){const c=Math.random()*Math.PI*2,h=Math.random()*.8;this.spawn(e.x+Math.cos(c)*h,e.y+Math.random()*.5,e.z+Math.sin(c)*h,0,n*(.5+Math.random()),0,o,a*(.5+Math.random()*.6),r,0,.5)}}update(e){const t=this.pos,n=this.col,s=this.size;for(let a=0;a<ns;a++){const r=this.p[a];if(r.life<=0){s[a]=0;continue}r.life-=e;const o=Math.max(0,1-r.drag*e);r.vx*=o,r.vy=r.vy*o+r.grav*e,r.vz*=o,r.x+=r.vx*e,r.y+=r.vy*e,r.z+=r.vz*e;const l=Math.max(0,r.life/r.max);t[a*3]=r.x,t[a*3+1]=r.y,t[a*3+2]=r.z,n[a*4]=r.r,n[a*4+1]=r.g,n[a*4+2]=r.b,n[a*4+3]=Math.min(1,l*1.6),s[a]=r.size*(.4+l*.6)}this.geo.attributes.position.needsUpdate=!0,this.geo.attributes.pcolor.needsUpdate=!0,this.geo.attributes.size.needsUpdate=!0}clear(){for(const e of this.p)e.life=0}}const ml=new Gl(.92,1,64),gl=new Mr(1,48),Jh=new br(1,1);ml.userData.shared=gl.userData.shared=Jh.userData.shared=!0;class z_{constructor(e){this.scene=e,this.particles=new B_(e),this.items=[]}add(e,t,n){this.scene.add(e);const s={obj:e,life:t,max:t,update:n};return this.items.push(s),s}shockwave(e,t,n,s=.45){const a=new kt({color:new pe(t).multiplyScalar(2),transparent:!0,blending:Vt,depthWrite:!1,side:Yt}),r=new Ge(ml,a);r.rotation.x=-Math.PI/2,r.position.set(e.x,.15,e.z),this.add(r,s,(o,l)=>{const c=n*(.2+(1-l)*.8);r.scale.setScalar(c),a.opacity=l})}telegraph({pos:e,radius:t,color:n="#ff3355",time:s=.8,cone:a,dir:r,length:o,width:l}){const c=new tn;c.position.set(e.x,.06,e.z);const h=new pe(n),d=new kt({color:h.clone().multiplyScalar(1.6),transparent:!0,opacity:.9,blending:Vt,depthWrite:!1,side:Yt}),u=new kt({color:h,transparent:!0,opacity:.22,blending:Vt,depthWrite:!1,side:Yt});let m;if(a){const g=ea.degToRad(a),v=new Mr(t,32,-g/2,g),f=new Ge(v,u);f.rotation.x=-Math.PI/2,c.add(f),m=new Ge(v,d),m.rotation.x=-Math.PI/2,c.add(m),c.rotation.y=-Math.atan2(r.z,r.x)}else if(o){const g=new Ts(o,l);g.translate(o/2,0,0);const v=new Ge(g,u);v.rotation.x=-Math.PI/2,c.add(v),m=new Ge(g,d),m.rotation.x=-Math.PI/2,c.add(m),c.rotation.y=-Math.atan2(r.z,r.x)}else{const g=new Ge(gl,u);g.rotation.x=-Math.PI/2,g.scale.setScalar(t),c.add(g);const v=new Ge(ml,d);v.rotation.x=-Math.PI/2,v.scale.setScalar(t),c.add(v),m=new Ge(gl,d.clone()),m.material.opacity=.3,m.rotation.x=-Math.PI/2,c.add(m)}return this.add(c,s,(g,v)=>{const f=1-v;a||o?m.scale.set(f,f,1):m.scale.setScalar(t*f),d.opacity=.5+Math.sin(f*30)*.2})}bolt(e,t,n,s=.25){const a=[];for(let h=0;h<=10;h++){const d=h/10,u=h===0||h===10?0:.6;a.push(new R(e.x+(t.x-e.x)*d+(Math.random()-.5)*u,e.y+(t.y-e.y)*d+(Math.random()-.5)*u,e.z+(t.z-e.z)*d+(Math.random()-.5)*u))}const o=new bt().setFromPoints(a),l=new yr({color:new pe(n).multiplyScalar(3),transparent:!0,blending:Vt,depthWrite:!1}),c=new Bl(o,l);this.add(c,s,(h,d)=>{l.opacity=d,d<=0&&o.dispose()})}orb(e,t){const n=new kt({color:new pe(e).multiplyScalar(2.6)}),s=new Ge(Jh,n);s.scale.setScalar(t);const a=new ol(new cr({map:Cs(),color:new pe(e),transparent:!0,opacity:.8,blending:Vt,depthWrite:!1}));return a.scale.setScalar(4),s.add(a),this.scene.add(s),s}removeOrb(e){this.scene.remove(e),e.material.dispose(),e.children[0].material.dispose()}beam(e,t,n=12,s=.6,a=.6){const r=new ui(s,s*1.4,n,16,1,!0);r.translate(0,n/2,0);const o=new kt({color:new pe(t).multiplyScalar(.8),transparent:!0,blending:Vt,depthWrite:!1,side:Yt}),l=new Ge(r,o);l.position.set(e.x,0,e.z),this.add(l,a,(c,h)=>{o.opacity=h*.6,l.scale.x=l.scale.z=.5+h*.5,h<=0&&r.dispose()})}update(e){this.particles.update(e);for(let t=this.items.length-1;t>=0;t--){const n=this.items[t];n.life-=e;const s=Math.max(0,n.life/n.max);n.update?.(n,s),n.life<=0&&(this.scene.remove(n.obj),n.obj.traverse?.(a=>{a.material&&a.material.dispose()}),this.items.splice(t,1))}}clear(){for(const e of this.items)this.scene.remove(e.obj);this.items=[],this.particles.clear()}}class H_{constructor(e,t){this.layer=e,this.camera=t,this.items=[],this.v=new R}show(e,t,n="",s=.9){this.items.length>40&&this.items.shift().el.remove();const a=document.createElement("div");a.className="dmg "+n,a.textContent=t,this.layer.appendChild(a),this.items.push({el:a,pos:e.clone().add(new R((Math.random()-.5)*.8,0,0)),life:s,max:s})}update(e){const t=window.innerWidth,n=window.innerHeight;for(let s=this.items.length-1;s>=0;s--){const a=this.items[s];if(a.life-=e,a.pos.y+=e*1.8,a.life<=0){a.el.remove(),this.items.splice(s,1);continue}this.v.copy(a.pos).project(this.camera);const r=(this.v.x*.5+.5)*t,o=(-this.v.y*.5+.5)*n,l=a.life/a.max;a.el.style.transform=`translate(${r}px, ${o}px) translate(-50%, -50%) scale(${.8+Math.min(1,(1-l)*6)*.3})`,a.el.style.opacity=Math.min(1,l*2.5)}}clear(){for(const e of this.items)e.el.remove();this.items=[]}}const He={move:{x:0,y:0},keys:new Set,pressed:new Set,touch:!1,joy:{active:!1,id:null,ox:0,oy:0,x:0,y:0},enabled:!0},G_={KeyQ:"q",KeyE:"e",KeyR:"r",KeyF:"f",Space:"dodge",Digit1:"sw1",Digit2:"sw2",Digit3:"sw3",Tab:"target",KeyG:"seal",Enter:"seal",Escape:"pause",KeyP:"pause",KeyJ:"q",KeyK:"e",KeyL:"r",ShiftLeft:"dodge"};function Ii(i){He.enabled&&He.pressed.add(i)}function V_(i,e,t){window.addEventListener("keydown",r=>{if(r.target&&(r.target.tagName==="INPUT"||r.target.tagName==="TEXTAREA"))return;He.keys.add(r.code);const o=G_[r.code];o&&!r.repeat&&(Ii(o),(r.code==="Tab"||r.code==="Space")&&r.preventDefault())}),window.addEventListener("keyup",r=>He.keys.delete(r.code)),window.addEventListener("blur",()=>He.keys.clear());const n=56;let s=null;t.addEventListener("pointerdown",r=>{r.pointerType!=="mouse"&&(He.touch=!0,document.body.classList.add("touch"),r.clientX<window.innerWidth*.45&&!He.joy.active?(He.joy={active:!0,id:r.pointerId,ox:r.clientX,oy:r.clientY,x:0,y:0},i.style.left=r.clientX+"px",i.style.top=r.clientY+"px",i.classList.add("on"),e.style.transform="translate(-50%, -50%)"):s={id:r.pointerId,x:r.clientX,y:r.clientY,t:performance.now()})}),t.addEventListener("pointermove",r=>{if(He.joy.active&&r.pointerId===He.joy.id){let o=r.clientX-He.joy.ox,l=r.clientY-He.joy.oy;const c=Math.hypot(o,l);c>n&&(o=o/c*n,l=l/c*n),He.joy.x=o/n,He.joy.y=l/n,e.style.transform=`translate(calc(-50% + ${o}px), calc(-50% + ${l}px))`}});const a=r=>{if(He.joy.active&&r.pointerId===He.joy.id&&(He.joy.active=!1,He.joy.x=He.joy.y=0,i.classList.remove("on")),s&&r.pointerId===s.id){const o=r.clientX-s.x,l=r.clientY-s.y;Math.hypot(o,l)>50&&performance.now()-s.t<350&&(He.swipeDir={x:o,y:l},Ii("dodge")),s=null}};t.addEventListener("pointerup",a),t.addEventListener("pointercancel",a)}let Ld=[];const Dd={2:"q",3:"e",1:"r",5:"f",7:"f",0:"dodge",14:"sw1",12:"sw2",15:"sw3",9:"pause",4:"target",6:"seal"};function $_(){let i=0,e=0;const t=He.keys;(t.has("KeyA")||t.has("ArrowLeft"))&&(i-=1),(t.has("KeyD")||t.has("ArrowRight"))&&(i+=1),(t.has("KeyW")||t.has("ArrowUp"))&&(e-=1),(t.has("KeyS")||t.has("ArrowDown"))&&(e+=1),He.joy.active&&(i+=He.joy.x,e+=He.joy.y);const n=navigator.getGamepads?navigator.getGamepads():[];for(const a of n){if(!a)continue;const r=a.axes[0]||0,o=a.axes[1]||0;Math.hypot(r,o)>.2&&(i+=r,e+=o),a.buttons.forEach((l,c)=>{l.pressed&&!Ld[c]&&Dd[c]&&Ii(Dd[c]),Ld[c]=l.pressed});break}const s=Math.hypot(i,e);s>1&&(i/=s,e/=s),He.move.x=i,He.move.y=e}function Bn(i){return He.pressed.has(i)?(He.pressed.delete(i),!0):!1}function nr(){He.pressed.clear()}const Si=new R;class W_{constructor(e,t,n){this.renderer=e,this.events=n,this.dmgLayer=t}start(e){this.config=e,this.island=It[e.islandIdx],this.islandIdx=e.islandIdx,this.scene=new Uh,this.camera=new qt(45,innerWidth/innerHeight,.1,400),this.lights=Kh(this.scene);const t=ct[this.island.boss];this.arena=U_(this.scene,{...this.island,sealDesign:t.circle},t.color),this.fx=new z_(this.scene),this.dmg=new H_(this.dmgLayer,this.camera),this.renderer.setScene(this.scene,this.camera),this.time=0,this.timers=[],this.projectiles=[],this.zones=[],this.mines=[],this.stars=[],this.enemies=[],this.paused=!1,this.over=!1,this.shakeAmt=0,this.camPos=new R(0,16,16),this.camLook=new R,this.switchCd=0,this.waveIdx=-1,this.waveCount=e.waves||4,this.waveSizes=e.tutorial?[1,1,2]:[1,2,2,3,3].slice(0,this.waveCount),this.waveCount=this.waveSizes.length,this.phase=0,this.boss=null,this.anchors=[],this.bossStage=!1,this.rewards={essence:0,xp:0,kills:0,sealed:[],fragments:{},crystals:0,bossSealed:!1,perfect:0,waves:0,stars:0},this.fought=new Set,this.waitingNext=0,this.revivesUsed=0,this.team=e.team.map(n=>{const s=C.creatures[n];return new Xa(n,{side:"player",level:s.level,form:s.form,glow:js(s.tint,ct[n].color),seal:this.sealDesign(n),owned:s})}),this.activeIdx=0,this.player=this.team[0],this.player.pos.set(0,0,6),this.player.facing=Math.PI,this.summon(this.player,!0),this.fought.add(this.player.id),rr("combat"),this.nextWave()}sealDesign(e){const t=C.cosmetics.seal;return t&&t!=="propio"?t:ct[e].circle}later(e,t){this.timers.push({t:this.time+e,fn:t})}foesOf(e){return e.side==="player"?[...this.enemies,...this.anchors].filter(t=>t.alive&&!t.sealing):this.player&&this.player.alive?[this.player]:[]}teamOf(e){return e.side==="player"?this.team.filter(t=>!t.fainted):[e]}shake(e){C.settings.shake&&(this.shakeAmt=Math.max(this.shakeAmt,e))}aimDir(e,t){const n=this.currentTarget();if(n)return mo(e.pos,n.pos);const s=He.move;return Math.hypot(s.x,s.y)>.2?new R(s.x,0,s.y).normalize():t||new R(Math.sin(e.facing),0,Math.cos(e.facing))}knockback(e,t,n){(e.boss||e.anchor)&&(n*=.2),e.knock.addScaledVector(t,n*4)}healFx(e,t,n=!0){const s=e.heal(t);s>0&&n&&e.visual.group.parent&&(this.dmg.show(Si.copy(e.pos).setY(e.visual.height+.6),"+"+Math.round(s),"heal"),this.fx.particles.burst(e.pos,"#7dffb0",8,3,.8,.5,{lift:2,grav:0}))}reviveTeam(e){for(const t of this.team)t.fainted&&(t.fainted=!1,t.alive=!0,t.hp=t.maxHp*e,t.statuses=[])}damage(e,t,n,s,a,r={}){if(!t.alive||this.over)return 0;if(t.iframes>0&&!r.dot)return this.dmg.show(Si.copy(t.pos).setY(t.visual.height+.4),x("dodged"),"miss"),0;if(t.invuln)return!r.dot&&Math.random()<.3&&this.dmg.show(Si.copy(t.pos).setY(t.visual.height+.4),x("immune"),"miss"),0;const o=s==="m"?e.stats.mag:e.stats.atk,l=t.def.stats[1],c=r.dot?1:Bd(e.def.el,t.def.el),h=!r.dot&&Math.random()<.05+e.def.stats[2]*.001;let d=r.raw??n*o*.06*(170/(100+l));if(r.raw||(d*=c*(h?1.5:1)*e.atkMul*(.92+Math.random()*.16)),t.has("mark")&&(d*=1.15),t.anchor&&(d=Math.max(d,t.maxHp*.04)),this.config.tutorial&&t.side==="player"&&(d*=.6),d=Math.max(1,d),t.shield>0){const u=Math.min(t.shield,d);if(t.shield-=u,d-=u,t.reflect&&!r.dot&&e.alive&&e!==t){const m=u*t.reflect;m>1&&this.later(.05,()=>this.damage(t,e,0,"m",null,{raw:m,dot:!0}))}if(d<=0)return this.dmg.show(Si.copy(t.pos).setY(t.visual.height+.4),Math.round(u),"shield"),0}if(t.boss&&!t.sealed&&(d=Math.min(d,t.hp-1)),t.hp-=d,d>0){const u=e.lifesteal;u&&!r.dot&&e.heal(d*u),r.dot||(t.visual.hit(e.def.color),Ee.hit(h||n>7),this.fx.particles.burst(t.pos,e.visual.glowColor,h?14:7,5,.45,.55,{dy:t.visual.height*.5}));const m=r.dot?"dot":h?"crit":c>1?"adv":t.side==="player"?"taken":"";this.dmg.show(Si.copy(t.pos).setY(t.visual.height+.4),Math.round(d)+(h?"!":""),m),r.dot||(e.side==="player"&&(e.seal=Math.min(100,e.seal+(a&&a.key==="f"?0:2.6))),t.side==="player"&&(t.seal=Math.min(100,t.seal+d/t.maxHp*30)),t.boss&&e.side==="player"&&this.shake(.05)),e.side==="player"&&c>1&&!r.dot&&ss("advantage")}return a&&a.status&&!r.dot&&t.addStatus(a.status,e,d),t.side==="enemy"&&!t.boss&&!t.anchor&&t.hp>0&&t.hp/t.maxHp<.25&&!t.sealable&&(t.sealable=!0,t.visual.circle?.setIntensity(1.7),t.visual.circle&&(t.visual.circle.speed=3),this.events.banner(x("sealOpen"),"seal",1.6),Ee.sealNode(4)),t.boss&&t.phaseReady3&&t.hp/t.maxHp<.25&&!t.sealable&&!t.invuln&&(t.sealable=!0,t.visual.circle?.setIntensity(1.8),this.events.banner(x("bossSealOpen"),"seal",2)),t.hp<=0&&this.onDown(t,e),d}onDown(e,t){if(!e.alive)return;e.alive=!1,e.hp=0;const n=e.pos.clone();if(this.fx.particles.burst(n,e.visual.glowColor,40,8,1,.8,{dy:1}),this.fx.shockwave(n,e.def.color,3),e.anchor){Ee.break(),this.scene.remove(e.mesh),this.scene.remove(e.beamLine),this.anchors=this.anchors.filter(s=>s!==e),!this.anchors.length&&this.boss&&(this.boss.invuln=!1,this.boss.phaseReady3=!0,this.boss.addStatus({t:"stun",dur:9},e),this.events.banner(x("anchorsBroken"),"gold",2.2),this.shake(.6));return}if(e.side==="enemy"){Ee.faint(),this.removeFighter(e);const s=e.level;this.rewards.kills++,this.rewards.xp+=10+s*6,this.rewards.essence+=15+s*4,C.stats.kills++,ss("kills")}else{Ee.faint(),e.fainted=!0,this.scene.remove(e.visual.group);const s=this.team.findIndex(a=>!a.fainted);s<0?(this.later(.8,()=>this.events.defeat()),this.paused=!1,this.defeated=!0):this.later(.7,()=>this.switchTo(s,!0))}}removeFighter(e){const t=e.visual,n=this.time,s=()=>{const a=1-(this.time-n)/.5;if(a<=0){this.scene.remove(t.group),e.dispose();return}t.group.scale.setScalar(a),t.setOpacity(a),this.later(.016,s)};s(),this.enemies=this.enemies.filter(a=>a!==e)}summon(e,t=!1){this.scene.add(e.visual.group),e.visual.group.position.copy(e.pos),e.iframes=.6;const n=e.side==="player"&&C.cosmetics.effect||"anillo",s=e.visual.glowColor;if(n==="estrellas")for(let a=0;a<24;a++)this.fx.particles.spawn(e.pos.x+(Math.random()-.5)*4,8+Math.random()*4,e.pos.z+(Math.random()-.5)*4,0,-14,0,s,.6,.8,0,0);else if(n==="pilar")this.fx.beam(e.pos,s,16,1.4,.8);else if(n==="espiral")for(let a=0;a<60;a++){const r=a*.4;this.fx.particles.spawn(e.pos.x+Math.cos(r)*2,a*.08,e.pos.z+Math.sin(r)*2,-Math.sin(r)*4,2,Math.cos(r)*4,s,.9,.6,0,.5)}this.fx.particles.pillar(e.pos,s,9,40,.8,.6),this.fx.shockwave(e.pos,e.def.color,4),(!t||e.side==="player")&&Ee.summon(e.def.el),zh(e.id)}switchTo(e,t=!1){if(e===this.activeIdx&&!t)return;const n=this.team[e];if(!n||n.fainted){Ee.error();return}if(!t&&this.switchCd>0){Ee.error();return}const s=this.player;s&&s.alive&&!s.fainted&&(this.fx.particles.burst(s.pos,s.visual.glowColor,20,4,.5,.6),this.scene.remove(s.visual.group),s.channel=null,s.dash=null),n.pos.copy(s?s.pos:new R),n.facing=s?s.facing:0,n.alive=!0,this.player=n,this.activeIdx=e,this.switchCd=1.5,this.fought.add(n.id),this.summon(n)}nextWave(){if(this.waveIdx++,this.waveIdx>=this.waveCount){this.events.choice();return}const e=this.waveSizes[this.waveIdx],t=C.islands.cleared.includes(this.islandIdx);this.events.banner(x("wave",{a:this.waveIdx+1,b:this.waveCount}),"",1.8);for(let n=0;n<e;n++)this.timers.push({t:this.time+.6+n*.45,wave:!0,fn:()=>{const s=this.island.pool,a=s[Math.floor(Math.random()*s.length)],r=t?Math.random():Math.min(1,this.waveIdx/this.waveCount*.7+Math.random()*.3),o=this.config.tutorial?1:r_(this.islandIdx,r),l=new Xa(a,{side:"enemy",level:o,form:0}),c=Math.random()*Math.PI*2;l.pos.set(this.player.pos.x+Math.cos(c)*9,0,this.player.pos.z+Math.sin(c)*9),hs(l.pos,2),l.facing=Math.atan2(this.player.pos.x-l.pos.x,this.player.pos.z-l.pos.z),l.aiGcd=1.2+Math.random(),this.enemies.push(l),this.summon(l)}})}starShower(){this.events.banner(x("starShower"),"gold",2),this.starT=9;for(let e=0;e<14;e++)this.later(e*.45,()=>{const t=new R((Math.random()-.5)*2*(gn-3),14,(Math.random()-.5)*2*(gn-3));hs(t,2);const n=this.fx.orb("#ffd76a",.32);n.position.copy(t),this.stars.push({mesh:n,pos:t,landed:!1,life:8})})}startBoss(){this.bossStage=!0;const e=this.island.boss,t=C.islands.cleared.includes(this.islandIdx),[n,s]=this.island.levels,a=this.team.reduce((l,c)=>l+c.level,0)/this.team.length,r=t?s+2:Math.round(Math.max(n,Math.min(s,a+1))),o=new Xa(e,{side:"enemy",level:r,form:2,boss:!0});o.pos.set(0,0,-7),o.facing=0,o.aiGcd=2.5,this.boss=o,this.enemies.push(o),this.summon(o),this.fx.beam(o.pos,o.def.color,26,1.1,1.1),this.shake(.8),Ee.roar(),rr("boss"),this.events.banner(o.def.name,"boss",3,!0),this.phase=1}bossPhase(e){const t=this.boss;if(this.phase=e,Ee.phase(),this.shake(.7),this.events.banner(x("phase",{n:e}),"boss",2),e===2){const n=["hexagrama","heptagrama","pentagrama"].filter(s=>s!==t.def.circle);t.visual.setSeal(n[0]),t.visual.circle&&(t.visual.circle.speed=2.5);for(let s=0;s<2;s++)this.later(1+s*.6,()=>{const a=this.island.pool.filter(c=>c!==t.id),r=a[s%a.length]||t.id,o=new Xa(r,{side:"enemy",level:Math.max(1,t.level-4),form:0}),l=Math.random()*Math.PI*2;o.pos.set(Math.cos(l)*10,0,Math.sin(l)*10),this.enemies.push(o),this.summon(o)})}if(e===3){t.invuln=!0,t.visual.setSeal(t.def.circle),t.visual.circle&&(t.visual.circle.speed=4),this.events.banner(x("anchors"),"boss",2.6);for(let n=0;n<4;n++){const s=Math.PI/4+n*Math.PI/2;this.spawnAnchor(new R(Math.cos(s)*12,0,Math.sin(s)*12))}}}spawnAnchor(e){const t=this.boss,n=new pe(t.def.color),s=new ia(1,0);s.scale(.9,2.6,.9);const a=new kt({color:n.clone().multiplyScalar(1.8)}),r=new Ge(s,a);r.position.set(e.x,2.8,e.z),this.scene.add(r);const o=new bt().setFromPoints([r.position.clone(),t.pos.clone().setY(2)]),l=new Bl(o,new yr({color:n.clone().multiplyScalar(1.2),transparent:!0,opacity:.6}));this.scene.add(l);const c=Math.round(t.maxHp*.045),h={anchor:!0,alive:!0,side:"enemy",id:t.id,def:t.def,pos:e.clone(),radius:1.2,hp:c,maxHp:c,mesh:r,beamLine:l,statuses:[],shield:0,iframes:0,invuln:!1,knock:new R,visual:{height:5,hit:()=>{a.color.setRGB(3,3,3),this.later(.08,()=>a.color.copy(n).multiplyScalar(1.8))},glowColor:n},has:()=>!1,addStatus:()=>{},heal:()=>0,atkMul:1};this.anchors.push(h),this.fx.beam(e,t.def.color,12,.5,.8)}spawnProjectile(e,t,n,s){const a=this.fx.orb(s,t.radius*.35),r=e.pos.clone().addScaledVector(n,e.radius*.8).setY(Math.min(2.2,e.visual.height*.5));a.position.copy(r),this.projectiles.push({f:e,ab:t,dir:n,pos:r,mesh:a,left:t.range,hit:new Set,color:s,side:e.side})}spawnZone(e,t,n,s){const a=this.fx.telegraph({pos:n,radius:t.radius,color:e.def.color,time:t.dur});this.fx.particles.ring(n,s,t.radius,40,.8,.6,1),this.zones.push({f:e,ab:t,pos:n,t:t.dur,tickT:0,inside:new Map,color:s,ring:a})}spawnMine(e,t,n,s){const a=this.fx.orb(s,.35);a.position.copy(n).setY(.4),this.mines.push({f:e,ab:t,pos:n,mesh:a,arm:.6,life:12,color:s})}crystalTower(e,t){const n=new Ms(.8,4,5);n.translate(0,2,0);const s=new kt({color:new pe(t).multiplyScalar(1.5),transparent:!0}),a=new Ge(n,s);a.position.set(e.x,0,e.z),this.fx.add(a,2.5,(r,o)=>{s.opacity=Math.min(1,o*3),a.scale.y=Math.min(1,(1-o)*8)})}currentTarget(){const e=this.foesOf(this.player);if(!e.length)return null;if(this.lockTarget&&e.includes(this.lockTarget))return this.lockTarget;let t=null,n=1/0;for(const s of e){const a=Math.hypot(s.pos.x-this.player.pos.x,s.pos.z-this.player.pos.z);a<n&&(n=a,t=s)}return t}nearestSealable(){let e=null,t=1/0;for(const n of this.enemies){if(!n.alive||!n.sealable||n.sealing)continue;const s=Math.hypot(n.pos.x-this.player.pos.x,n.pos.z-this.player.pos.z);s<t&&(t=s,e=n)}return e}tryCast(e){const t=this.player;if(!t||!t.alive||t.stunned||t.castLock>0||t.dash||this.defeated)return!1;const n=t.ability(e);if(!n||!t.hasAbility(e))return!1;if(e==="f"){if(t.seal<100)return Ee.error(),!1;t.seal=0,C.stats.ults++,ss("ult"),Ee.ult(),this.events.banner(n.name,"ult",1.4,!0),this.shake(.4)}else{if(t.cds[e]>0||t.energy<(n.cost||0))return Ee.error(),!1;t.energy-=n.cost||0,t.cds[e]=n.cd*t.cdrMul}const s=this.currentTarget(),a=this.aimDir(t);return go(this,t,n,{dir:a,pos:s?s.pos.clone():t.pos.clone().addScaledVector(a,6),target:s}),!0}playerUpdate(e){const t=this.player;if(!(!t||!t.alive)){Bn("q")&&this.tryCast("q"),Bn("e")&&this.tryCast("e"),Bn("r")&&this.tryCast("r"),Bn("f")&&this.tryCast("f");for(let n=0;n<3;n++)Bn("sw"+(n+1))&&this.switchTo(n);if(Bn("target")){const n=this.foesOf(t);if(n.length){const s=n.indexOf(this.lockTarget);this.lockTarget=n[(s+1)%n.length]}}if(Bn("seal")){const n=this.nearestSealable();n&&this.events.sealStart(n)}if(Bn("dodge")&&t.dodgeCd<=0&&!t.rooted){let n;He.swipeDir?(n=new R(He.swipeDir.x,0,He.swipeDir.y).normalize(),He.swipeDir=null):Math.hypot(He.move.x,He.move.y)>.1?n=new R(He.move.x,0,He.move.y).normalize():n=new R(-Math.sin(t.facing),0,-Math.cos(t.facing)),t.dash={dir:n,left:5.5,speed:26,ab:null,hit:new Set,dodge:!0},t.iframes=.4,t.dodgeCd=1,t.channel=null,Ee.dodge(),this.fx.particles.burst(t.pos,t.visual.glowColor,12,3,.4,.5)}if(!t.dash&&!t.rooted){const n=He.move,s=Math.hypot(n.x,n.y),a=t.castLock>0?.35:1;if(s>.05){const r=t.stats.spd*t.speedMul*a;t.pos.x+=n.x*r*e,t.pos.z+=n.y*r*e,t.castLock<=0&&(t.facing=Math.atan2(n.x,n.y))}t.moving=Math.min(1,s)}else t.moving=0}}aiUpdate(e,t){const n=this.player;if(!n||!n.alive||e.stunned||this.defeated){e.moving=0;return}if(e.windup){if(e.windup.t-=t,e.moving=0,e.facing=Math.atan2(e.windup.dir.x,e.windup.dir.z),e.windup.t<=0){const u=e.windup;e.windup=null,go(this,e,u.ab,{dir:u.dir,pos:u.pos,target:n})}return}const s=mo(e.pos,n.pos),a=Math.hypot(n.pos.x-e.pos.x,n.pos.z-e.pos.z),o=(e.abilities[0].type==="melee"||e.abilities[0].type==="dash"?2.2:7.5)+e.radius+n.radius;if(e.aiGcd-=t,e.aiGcd<=0&&e.castLock<=0&&!e.dash){const u=e.boss?["f","r","e","q"]:e.form>=1?["r","e","q"]:["e","q"];for(const m of u){const g=e.ability(m);if(!g||m==="f"&&e.seal<100||m!=="f"&&e.cds[m]>0)continue;const v=g.range||6;if(["heal","shield","buff"].includes(g.type)){if(g.type==="heal"&&e.hp/e.maxHp>.6)continue}else if(a>v+n.radius+1)continue;m==="f"?e.seal=0:e.cds[m]=g.cd*(e.boss?this.phase>=2?1.3:1.6:2.2);const f=n.pos.clone(),p=["cone","aoe","strike","dash","zone"].includes(g.type)||m==="f",E=e.boss?this.phase>=3?.5:.65:.75;p&&g.type!=="strike"?(e.windup={ab:g,dir:s.clone(),pos:f,t:E},g.type==="cone"?this.fx.telegraph({pos:e.pos,radius:g.range,cone:g.arc,dir:s,time:E,color:"#ff3355"}):g.type==="dash"?this.fx.telegraph({pos:e.pos,dir:s,length:g.range,width:g.width*1.6,time:E,color:"#ff3355"}):g.type==="aoe"?this.fx.telegraph({pos:g.range?f:e.pos,radius:g.radius,time:E,color:"#ff3355"}):g.type==="zone"?this.fx.telegraph({pos:f,radius:g.radius,time:E,color:"#ff3355"}):g.type==="revive"&&this.fx.telegraph({pos:e.pos,radius:g.radius,time:E,color:"#ff3355"}),Ee.warn()):g.type==="melee"||g.type==="projectile"?e.windup={ab:g,dir:s.clone(),pos:f,t:.28}:go(this,e,g,{dir:s,pos:f,target:n}),e.aiGcd=e.boss?this.phase>=2?.9:1.2:1.4+Math.random()*1.2,e.boss&&(e.seal=Math.min(100,e.seal+12));return}}if(e.rooted||e.dash){e.moving=0;return}const l=e.stats.spd*e.speedMul*(e.boss?.7:.62);let c=0,h=0;a>o+.5?(c=s.x,h=s.z):a<o-1.5&&(c=-s.x,h=-s.z),e.aiT+=t,e.boss||(c+=-s.z*e.strafe*.5,h+=s.x*e.strafe*.5,Math.random()<t*.3&&(e.strafe*=-1));const d=Math.hypot(c,h);d>.01?(e.pos.x+=c/d*l*t,e.pos.z+=h/d*l*t,e.moving=1):e.moving=0,e.facing=Math.atan2(s.x,s.z)}update(e){if(this.paused||!this.scene)return;if(e=Math.min(e,.05),this.time+=e,this.switchCd=Math.max(0,this.switchCd-e),this.timers.length){const n=this.timers.filter(s=>s.t<=this.time);this.timers=this.timers.filter(s=>s.t>this.time);for(const s of n)s.fn()}this.over||this.playerUpdate(e);const t=[...this.team.filter(n=>n===this.player&&n.alive),...this.enemies];for(const n of t){if(n.tick(e,(s,a,r)=>this.damage(r.src&&r.src.alive!==void 0?r.src:s,s,0,"m",null,{raw:a,dot:!0})),n.side==="enemy"&&n.alive&&!this.over&&this.aiUpdate(n,e),n.dash){const s=Math.min(n.dash.left,n.dash.speed*e);if(n.pos.addScaledVector(n.dash.dir,s),n.dash.left-=s,n.facing=Math.atan2(n.dash.dir.x,n.dash.dir.z),n.dash.ab){for(const a of this.foesOf(n))n.dash.hit.has(a)||Math.hypot(a.pos.x-n.pos.x,a.pos.z-n.pos.z)<a.radius+n.dash.ab.width&&(n.dash.hit.add(a),this.damage(n,a,n.dash.ab.power,n.dash.ab.stat,n.dash.ab),n.dash.ab.knock&&this.knockback(a,n.dash.dir,n.dash.ab.knock));this.fx.particles.spawn(n.pos.x,.8,n.pos.z,0,1,0,n.dash.color||n.visual.glowColor,.4,.8,0,0)}n.dash.left<=.01&&(n.dash=null)}if(n.knock.lengthSq()>.01&&(n.pos.addScaledVector(n.knock,e),n.knock.multiplyScalar(Math.max(0,1-e*6))),n.pullTo){const s=mo(n.pos,n.pullTo.pos),a=Math.hypot(n.pos.x-n.pullTo.pos.x,n.pos.z-n.pullTo.pos.z);a>1.2&&n.pos.addScaledVector(s,Math.min(a-1.2,n.pullTo.speed*e*(n.boss?.15:1))),n.pullTo.t-=e,n.pullTo.t<=0&&(n.pullTo=null)}hs(n.pos,n.radius*.5)}for(let n=0;n<t.length;n++)for(let s=n+1;s<t.length;s++){const a=t[n],r=t[s],o=r.pos.x-a.pos.x,l=r.pos.z-a.pos.z,c=Math.hypot(o,l),h=(a.radius+r.radius)*.75;if(c<h&&c>.001){const d=(h-c)/2,u=a.boss?.1:1,m=r.boss?.1:1;a.pos.x-=o/c*d*u,a.pos.z-=l/c*d*u,r.pos.x+=o/c*d*m,r.pos.z+=l/c*d*m}}if(this.boss&&this.boss.alive){const n=this.boss.hp/this.boss.maxHp;this.phase===1&&n<.66?this.bossPhase(2):this.phase===2&&n<.34&&this.bossPhase(3)}this.updateProjectiles(e),this.updateZones(e),this.updateMines(e),this.updateStars(e);for(const n of t)n.visual.group.position.copy(n.pos),n.visual.update(e,{moving:n.dash?1:n.moving,heading:n.facing,stunned:n.stunned});for(const n of this.anchors)n.mesh.rotation.y+=e,n.mesh.position.y=2.8+Math.sin(this.time*2+n.pos.x)*.2;if(this.arena.update(e),this.assignLights(),!this.over&&!this.bossStage&&this.waveIdx<this.waveCount&&this.enemies.length===0&&!this.timers.some(n=>n.wave)&&this.waitingNext<=0){this.waitingNext=2.2,this.rewards.waves++,this.rewards.essence+=20*(this.waveIdx+1);for(const n of this.team)n.fainted||n.heal(n.maxHp*.15);this.waveIdx===1&&!this.config.tutorial&&Math.random()<.55&&(this.starShower(),this.waitingNext=9.5)}this.waitingNext>0&&(this.waitingNext-=e,this.waitingNext<=0&&this.nextWave()),this.updateCamera(e),this.fx.update(e),this.dmg.update(e),this.events.hud(this)}updateProjectiles(e){for(let t=this.projectiles.length-1;t>=0;t--){const n=this.projectiles[t],s=n.ab.speed*e;n.pos.addScaledVector(n.dir,s),n.left-=s,n.mesh.position.copy(n.pos),Math.random()<.6&&this.fx.particles.spawn(n.pos.x,n.pos.y,n.pos.z,0,.3,0,n.color,.3,n.ab.radius*1.2,0,0);let a=n.left<=0;const r=n.side==="player"?this.foesOf(this.player):this.player&&this.player.alive?[this.player]:[];for(const o of r)if(!n.hit.has(o)&&Math.hypot(o.pos.x-n.pos.x,o.pos.z-n.pos.z)<o.radius+n.ab.radius){if(n.hit.add(o),o.reflect&&o.shield>0&&n.f.alive){n.dir.negate(),n.side=o.side,n.f=o,n.left=n.ab.range,n.hit.clear(),this.dmg.show(Si.copy(o.pos).setY(o.visual.height+.4),x("reflected"),"shield");break}if(n.ab.explode){this.fx.shockwave(n.pos,n.color,n.ab.explode),Ee.boom();for(const l of r)Math.hypot(l.pos.x-n.pos.x,l.pos.z-n.pos.z)<n.ab.explode+l.radius&&this.damage(n.f,l,n.ab.power,n.ab.stat,n.ab)}else this.damage(n.f,o,n.ab.power,n.ab.stat,n.ab);if(n.ab.pullBack&&o.alive&&(o.pullTo={pos:n.f.pos.clone(),speed:22,t:.5}),!n.ab.pierce){a=!0;break}}a&&(this.fx.particles.burst(n.pos,n.color,6,3,.3,.4,{dy:0}),this.fx.removeOrb(n.mesh),this.projectiles.splice(t,1))}}updateZones(e){for(let t=this.zones.length-1;t>=0;t--){const n=this.zones[t];if(n.t-=e,n.tickT-=e,Math.random()<.7){const s=Math.random()*Math.PI*2,a=Math.random()*n.ab.radius;this.fx.particles.spawn(n.pos.x+Math.cos(s)*a,.2,n.pos.z+Math.sin(s)*a,0,2+Math.random()*2,0,n.color,.6,.6,0,.5)}if(n.tickT<=0){if(n.tickT+=n.ab.tick||.5,n.ab.heal)for(const s of this.teamOf(n.f))s.visual.group.parent&&Math.hypot(s.pos.x-n.pos.x,s.pos.z-n.pos.z)<n.ab.radius+s.radius&&this.healFx(s,s.maxHp*n.ab.heal);else for(const s of this.foesOf(n.f))if(Math.hypot(s.pos.x-n.pos.x,s.pos.z-n.pos.z)<n.ab.radius+s.radius&&(this.damage(n.f,s,n.ab.power,n.ab.stat,n.ab,{zone:!0}),n.ab.freezeAfter)){const a=(n.inside.get(s)||0)+(n.ab.tick||.5);n.inside.set(s,a),a>=n.ab.freezeAfter&&!s.has("freeze")&&s.addStatus({t:"freeze",dur:1.5},n.f)}}n.t<=0&&this.zones.splice(t,1)}}updateMines(e){for(let t=this.mines.length-1;t>=0;t--){const n=this.mines[t];n.arm-=e,n.life-=e,n.mesh.position.y=.4+Math.abs(Math.sin(this.time*6+t))*.3;let s=n.life<=0;if(n.arm<=0)for(const a of this.foesOf(n.f))Math.hypot(a.pos.x-n.pos.x,a.pos.z-n.pos.z)<n.ab.radius+a.radius&&(s=!0);if(s){this.fx.shockwave(n.pos,n.color,n.ab.radius*1.4),this.fx.particles.burst(n.pos,n.color,18,6,.5,.6),Ee.boom();for(const a of this.foesOf(n.f))Math.hypot(a.pos.x-n.pos.x,a.pos.z-n.pos.z)<n.ab.radius*1.4+a.radius&&this.damage(n.f,a,n.ab.power,n.ab.stat,n.ab);this.fx.removeOrb(n.mesh),this.mines.splice(t,1)}}}updateStars(e){for(let t=this.stars.length-1;t>=0;t--){const n=this.stars[t];n.landed?n.pos.y=.8+Math.sin(this.time*4+t)*.15:(n.pos.y-=e*9,n.pos.y<=.8&&(n.pos.y=.8,n.landed=!0,this.fx.shockwave(n.pos,"#ffd76a",1.5))),n.mesh.position.copy(n.pos),n.life-=e;const s=this.player;if(s&&n.landed&&Math.hypot(s.pos.x-n.pos.x,s.pos.z-n.pos.z)<1.8+s.radius){const a=25+this.island.levels[0]*3;this.rewards.essence+=a,this.rewards.stars++,this.dmg.show(n.pos.clone().setY(2),"+"+a,"gold"),Ee.coin(),this.fx.particles.burst(n.pos,"#ffd76a",12,4,.6,.5),this.fx.removeOrb(n.mesh),this.stars.splice(t,1)}else n.life<=0&&(this.fx.removeOrb(n.mesh),this.stars.splice(t,1))}}assignLights(){const e=this.lights.pool,t=[this.player,...this.enemies.filter(n=>n.boss),...this.enemies.filter(n=>!n.boss)].filter(n=>n&&n.alive);for(let n=0;n<e.length;n++){const s=t[n];s?(e[n].color.copy(s.visual.glowColor),e[n].intensity=s.boss?26:n===0?11:7,e[n].distance=s.boss?22:12,e[n].position.set(s.pos.x,s.visual.height*.6+.8,s.pos.z+.5)):e[n].intensity=0}}updateCamera(e){const t=this.player;if(!t)return;const n=innerWidth<innerHeight,s=n?new R(0,17,12.5):new R(0,10.5,11),a=this.currentTarget(),r=t.pos.clone();n&&(r.z-=3.5),a&&r.lerp(a.pos,.25),this.boss&&this.boss.alive&&r.lerp(this.boss.pos,.15);const o=r.clone().add(s);this.camPos.lerp(o,Math.min(1,e*4)),this.camLook.lerp(r.setY(1),Math.min(1,e*5)),this.camera.position.copy(this.camPos),this.shakeAmt>0&&(this.camera.position.x+=(Math.random()-.5)*this.shakeAmt,this.camera.position.y+=(Math.random()-.5)*this.shakeAmt,this.shakeAmt=Math.max(0,this.shakeAmt-e*1.8)),this.camera.lookAt(this.camLook)}sealResult(e,t){if(e.sealing=!1,t==="fail"){e.heal(e.maxHp*.1),e.hp/e.maxHp>=.25&&(e.sealable=!1,e.visual.circle?.setIntensity(1),e.visual.circle&&(e.visual.circle.speed=e.boss?4:1)),this.dmg.show(Si.copy(e.pos).setY(e.visual.height+.6),x("sealFailed"),"taken");return}const n=t==="perfect";e.sealed=!0,this.fx.beam(e.pos,e.def.color,20,1.6,1.4),this.fx.particles.pillar(e.pos,e.visual.glowColor,14,120,1.4,1),this.fx.shockwave(e.pos,e.def.color,8),this.shake(.4),C.stats.seals++,n&&(C.stats.perfect++,this.rewards.perfect++,ss("perfect")),ss("seal");const s=e.level,a=Math.round((25+s*6)*(n?1.5:1));if(this.rewards.essence+=a,this.rewards.xp+=Math.round((10+s*6)*1.2),this.rewards.sealed.push({id:e.id,level:e.boss?Math.max(1,s-30):s,perfect:n,boss:!!e.boss,essence:a}),e.alive=!1,this.removeFighter(e),e.boss){this.rewards.bossSealed=!0,this.rewards.xp+=200+s*20,this.rewards.essence+=600+s*25,this.over=!0;for(const r of this.enemies)r.alive=!1;for(const r of[...this.enemies])this.removeFighter(r);this.later(2.2,()=>this.finish(!0))}}finish(e){this.ended||(this.ended=!0,this.over=!0,this.events.end(e,this.rewards,[...this.fought]))}revive(){this.defeated=!1,this.revivesUsed++,this.reviveTeam(.5);const e=this.team.findIndex(t=>!t.fainted);this.player=null,this.switchTo(e,!0);for(const t of this.enemies)t.addStatus({t:"stun",dur:1.5},this.player)}dispose(){this.fx?.clear(),this.dmg?.clear();for(const e of[...this.team,...this.enemies])e.dispose();this.scene?.traverse(e=>{e.geometry&&!e.geometry.userData?.shared&&e.geometry.dispose?.()}),this.scene=null}}function Qh(i,e){return e?Qh(e,i%e):i}function X_(i,e){let t=e;const n=()=>(t=(t*9301+49297)%233280)/233280;let s=Math.max(1,Math.floor(i/2)-(i%2===0?1:0));for(;Qh(i,s)!==1&&s>1;)s--;const a=n()*Math.PI*2,r=[];for(let o=0;o<i;o++){const l=o*s%i,c=a+l/i*Math.PI*2,h=.5+n()*.32;r.push({bx:Math.cos(c)*h,by:Math.sin(c)*h,ph:n()*10})}return r}const Id=i=>window.__manual?window.__manual.push(i):requestAnimationFrame(i);function q_({root:i,color:e,name:t,nodes:n,moving:s,time:a=5,boss:r=!1,ink:o,onDone:l}){const c=document.createElement("div");c.className="sealing",c.innerHTML=`
    <canvas></canvas>
    <div class="seal-head">
      <span class="eyebrow" style="color:${e}">${x("sealing")}</span>
      <h1>${x("traceSeal",{name:t})}</h1>
      <p>${x("traceHelp")}</p>
    </div>
    <div class="seal-side seal-left">${r?"":`<span class="eyebrow">${x("ink")}</span><div class="big num">${o}<small> / 10</small> <em>−1</em></div><p>${x("inkHelp")}</p>`}</div>
    <div class="seal-side seal-right"><span class="eyebrow">${x("time")}</span><div class="big num timer" style="text-shadow:0 0 22px ${e}">${a.toFixed(1)} s</div><div class="bar"><i style="background:${e}"></i></div><p>${x("struggle")}</p></div>
    <div class="seal-result"></div>`,i.appendChild(c);const h=c.querySelector("canvas"),d=h.getContext("2d"),u=c.querySelector(".timer"),m=c.querySelector(".bar i"),g=c.querySelector(".seal-result"),v=X_(n,Math.floor(Math.random()*1e5)),f={idx:0,errors:0,left:a,done:!1,down:!1,px:0,py:0,intro:.45,shake:0,flash:0};let p=0,E=0,w=0,b=0,O=0,P=1;const L=()=>{P=Math.min(2,window.devicePixelRatio||1),p=c.clientWidth,E=c.clientHeight,h.width=p*P,h.height=E*P,h.style.width=p+"px",h.style.height=E+"px",w=Math.min(p,E)*(p<700||E<500?.4:.34),b=p/2,O=E/2+(E<500?12:30)};L(),window.addEventListener("resize",L);const I=(ee,ie)=>{let ve=b+ee.bx*w,Te=O+ee.by*w;const Y=r?3.5:2.5;return ve+=Math.sin(ie*37+ee.ph)*Y,Te+=Math.cos(ie*41+ee.ph)*Y,s&&(ve+=Math.sin(ie*.9+ee.ph)*w*.08,Te+=Math.cos(ie*.7+ee.ph*2)*w*.08),[ve,Te]},S=()=>Math.max(26,w*.09);let y=0;const D=ee=>{f.done||(f.done=!0,window.__seal=null,ee==="perfect"?Ee.sealPerfect():ee==="ok"?Ee.sealOk():Ee.sealFail(),g.innerHTML=`<div class="res ${ee}">${x(ee==="perfect"?"perfectTrace":ee==="ok"?"sealed":"sealResists")}</div>${ee==="perfect"?`<p>${x("perfectBonus")}</p>`:""}`,g.classList.add("on"),setTimeout(()=>{window.removeEventListener("resize",L),window.__manual||cancelAnimationFrame(ne),f.stopped=!0,c.classList.add("out"),setTimeout(()=>c.remove(),300),l(ee)},ee==="fail"?1100:1300))},V=(ee,ie)=>{for(let ve=0;ve<v.length;ve++){if(ve<f.idx)continue;const[Te,Y]=I(v[ve],y);if(Math.hypot(Te-ee,Y-ie)<S()){if(ve===f.idx){if(f.idx++,Ee.sealNode(f.idx),f.idx>=v.length){const te=f.errors===0&&f.left/a>=(r?.3:.4);D(te?"perfect":"ok")}}else ve>f.idx&&!f.lastWrong?.includes(ve)&&(f.errors++,f.shake=.3,f.flash=1,f.lastWrong=[ve],Ee.error(),f.errors>=3&&D("fail"));return}}f.lastWrong=null},z=ee=>{const ie=h.getBoundingClientRect();return[ee.clientX-ie.left,ee.clientY-ie.top]};h.addEventListener("pointerdown",ee=>{f.done||(h.setPointerCapture(ee.pointerId),f.down=!0,[f.px,f.py]=z(ee),V(f.px,f.py))}),h.addEventListener("pointermove",ee=>{!f.down||f.done||([f.px,f.py]=z(ee),V(f.px,f.py))});const X=()=>{f.down=!1};h.addEventListener("pointerup",X),h.addEventListener("pointercancel",X);let J=!1,q=performance.now(),ne=0;const $=ee=>{if(f.stopped)return;const ie=Math.min(.05,(ee-q)/1e3);q=ee,y+=ie,f.intro>0?f.intro-=ie:f.done||(f.left-=ie,f.left<=0&&(f.left=0,D("fail")));const ve=He.move;if(Math.hypot(ve.x,ve.y)>.2&&!f.done){if(!J){J=!0;const Te=v[Math.max(0,f.idx-1)];[f.px,f.py]=f.idx?I(Te,y):[b,O]}f.px+=ve.x*ie*Math.max(500,w*2.2),f.py+=ve.y*ie*Math.max(500,w*2.2),V(f.px,f.py)}u.textContent=f.left.toFixed(1).replace(".",x("decimal"))+" s",m.style.width=f.left/a*100+"%",ce(),ne=Id($)},ce=()=>{d.setTransform(P,0,0,P,0,0),d.clearRect(0,0,p,E);const ee=f.shake>0?(Math.random()-.5)*10:0;f.shake=Math.max(0,f.shake-.016),f.flash=Math.max(0,f.flash-.05),d.save(),d.translate(ee,0);const ie=Math.max(0,Math.min(1,1-f.intro/.45));d.globalAlpha=ie,d.lineCap="round",d.lineJoin="round",d.strokeStyle=e,d.globalAlpha=ie*.16,d.lineWidth=5,d.beginPath(),d.arc(b,O,w*1.04,0,Math.PI*2),d.stroke(),d.globalAlpha=ie,d.shadowColor=e,d.shadowBlur=16,d.beginPath(),d.arc(b,O,w*1.04,-Math.PI/2,-Math.PI/2+f.left/a*Math.PI*2),d.stroke(),d.shadowBlur=0,d.globalAlpha=ie*.5,d.lineWidth=1.5,d.beginPath(),d.arc(b,O,w*.99,0,Math.PI*2),d.stroke(),d.setLineDash([1.5,w*.12]),d.lineWidth=9,d.globalAlpha=ie*.45,d.save(),d.translate(b,O),d.rotate(y*.2),d.beginPath(),d.arc(0,0,w*.96,0,Math.PI*2),d.stroke(),d.restore(),d.setLineDash([2,10]),d.lineWidth=1,d.globalAlpha=ie*.3,d.beginPath(),d.arc(b,O,w*.92,0,Math.PI*2),d.stroke(),d.setLineDash([]),d.globalAlpha=ie*.18,d.beginPath(),d.arc(b,O,w*.4,0,Math.PI*2),d.stroke();const ve=v.map(Te=>I(Te,y));d.globalAlpha=ie*.4,d.lineWidth=2,d.setLineDash([5,9]),d.beginPath();for(let Te=Math.max(0,f.idx-1);Te<ve.length;Te++)(Te===Math.max(0,f.idx-1)?d.moveTo:d.lineTo).call(d,ve[Te][0],ve[Te][1]);if(d.stroke(),d.setLineDash([]),f.idx>0){d.globalAlpha=ie*.32,d.lineWidth=18,d.beginPath();for(let Te=0;Te<f.idx;Te++)(Te?d.lineTo:d.moveTo).call(d,ve[Te][0],ve[Te][1]);(f.down||J)&&d.lineTo(f.px,f.py),d.stroke(),d.globalAlpha=ie,d.strokeStyle="#ffffff",d.shadowColor=e,d.shadowBlur=20,d.lineWidth=4,d.stroke(),d.shadowBlur=0,d.strokeStyle=e}d.font=`800 ${Math.max(13,w*.045)}px "Alegreya Sans", sans-serif`;for(let Te=0;Te<ve.length;Te++){const[Y,te]=ve[Te],Me=Te<f.idx,le=Te===f.idx;if(d.globalAlpha=ie,le){const De=.5+Math.sin(y*8)*.5;d.globalAlpha=ie*(.5+De*.5),d.lineWidth=2,d.beginPath(),d.arc(Y,te,S()*1.15,0,Math.PI*2),d.stroke(),d.globalAlpha=ie,d.fillStyle="#06180e",d.lineWidth=3.5,d.beginPath(),d.arc(Y,te,S()*.6,0,Math.PI*2),d.fill(),d.stroke()}else Me?(d.fillStyle="#ffffff",d.lineWidth=3,d.shadowColor=e,d.shadowBlur=14,d.beginPath(),d.arc(Y,te,S()*.48,0,Math.PI*2),d.fill(),d.stroke(),d.shadowBlur=0):(d.globalAlpha=ie*.7,d.fillStyle="#06100c",d.lineWidth=2,d.beginPath(),d.arc(Y,te,S()*.42,0,Math.PI*2),d.fill(),d.stroke());d.globalAlpha=ie*(Me||le?1:.6),d.fillStyle="#f4f1fb",d.fillText(String(Te+1),Y+S()*.75,te-S()*.6)}(J||f.down)&&(d.globalAlpha=ie,d.strokeStyle="#f4f1fb",d.lineWidth=2,d.beginPath(),d.arc(f.px,f.py,16,0,Math.PI*2),d.stroke(),d.fillStyle="#f4f1fb",d.beginPath(),d.arc(f.px,f.py,4,0,Math.PI*2),d.fill()),f.flash>0&&(d.globalAlpha=f.flash*.25,d.fillStyle="#ff3355",d.fillRect(-20,0,p+40,E)),d.restore()};ne=Id($),window.__seal={nodes:()=>v.map(ee=>I(ee,y)),idx:()=>f.idx,done:()=>f.done}}const Y_=(i,e=document)=>e.querySelector(i),j_=()=>document.getElementById("ui"),An=(i,e)=>bs(`assets/img/${i}/${e}.webp`),eu=i=>bs(`assets/img/escenas/${i}.webp`),nt=(i,e="")=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${e}>${i}</svg>`,Oe={essence:nt('<path d="M12 2.5l6.5 9.5-6.5 9.5-6.5-9.5z"/><path d="M5.5 12h13"/><path d="M12 2.5v19"/>','style="color:var(--essence)"'),ink:nt('<path d="M12 3c3.6 4.6 6 7.9 6 11.1a6 6 0 0 1-12 0C6 10.9 8.4 7.6 12 3z"/><path d="M9.5 13.5l2.5 3 2.5-3"/>','style="color:var(--ink-blue)"'),crystal:nt('<path d="M12 2l6 4.5v8L12 22l-6-7.5v-8z"/><path d="M6 6.5l6 4 6-4"/><path d="M12 10.5V22"/>','style="color:var(--crystal)"'),frag:nt('<path d="M12 3l7 9-7 9-7-9z"/><path d="M12 3v18"/>'),play:nt('<circle cx="12" cy="12" r="9"/><path d="M12 6l4 6-4 6-4-6z"/>'),book:nt('<path d="M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5z"/><path d="M5 19.5A1.5 1.5 0 0 0 6.5 21H19v-3"/><path d="M12 7l2 3-2 3-2-3z"/>'),team:nt('<circle cx="8" cy="9" r="3"/><circle cx="16" cy="9" r="3"/><path d="M3 20c0-3 2.5-5 5-5s5 2 5 5"/><path d="M11 20c0-3 2.5-5 5-5s5 2 5 5"/>'),shop:nt('<path d="M5 8h14l-1.2 12H6.2z"/><path d="M9 8a3 3 0 0 1 6 0"/>'),pass:nt('<path d="M4 8l4 3 4-6 4 6 4-3-2 11H6z"/>'),settings:nt('<path d="M4 7h9"/><path d="M17 7h3"/><circle cx="15" cy="7" r="2"/><path d="M4 17h3"/><path d="M11 17h9"/><circle cx="9" cy="17" r="2"/>'),gift:nt('<rect x="4" y="9" width="16" height="11" rx="1"/><path d="M4 13h16"/><path d="M12 9v11"/><path d="M12 9C10.5 5.5 7 5.5 7.5 8c.3 1 2 1 4.5 1z"/><path d="M12 9c1.5-3.5 5-3.5 4.5-1-.3 1-2 1-4.5 1z"/>'),arrow:nt('<path d="M5 12h14"/><path d="M13 6l6 6-6 6"/>'),back:nt('<path d="M19 12H5"/><path d="M11 6l-6 6 6 6"/>'),lock:nt('<rect x="5" y="11" width="14" height="10" rx="1.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>'),pause:nt('<path d="M9 5v14"/><path d="M15 5v14"/>'),star:nt('<path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6L12 16.6l-5.4 2.9 1.2-6-4.5-4.2 6.1-.7z"/>'),ad:nt('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 9l5 3-5 3z"/>'),check:nt('<path d="M5 12l5 5 9-10"/>'),seal:nt('<circle cx="12" cy="12" r="9"/><path d="M12 4l4.9 15.1L4 9.8h16L7.1 19.1z"/>'),globe:nt('<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18"/>'),fullscreen:nt('<path d="M4 9V4h5"/><path d="M20 9V4h-5"/><path d="M4 15v5h5"/><path d="M20 15v5h-5"/>')},Ya={melee:nt('<path d="M4 7l2.5 8L9 7"/><path d="M9.5 7l2.5 10 2.5-10"/><path d="M15 7l2.5 8L20 7"/>'),projectile:nt('<path d="M4 20L18 6"/><path d="M14 5h5v5"/><circle cx="6" cy="18" r="1"/>'),cone:nt('<path d="M4 12l16-7v14z"/>'),aoe:nt('<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/>'),dash:nt('<path d="M3 12h12"/><path d="M11 6l6 6-6 6"/><path d="M3 8h5"/><path d="M3 16h5"/><path d="M20.5 5v14"/>'),heal:nt('<path d="M12 5v14"/><path d="M5 12h14"/>'),shield:nt('<path d="M12 3l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V6z"/>'),buff:nt('<path d="M5 12h.01"/><path d="M9 9a4.2 4.2 0 0 1 0 6"/><path d="M12.5 6.5a8 8 0 0 1 0 11"/><path d="M16 4a11.5 11.5 0 0 1 0 16"/>'),zone:nt('<ellipse cx="12" cy="16" rx="8" ry="3"/><path d="M8 15c0-4 2-6 2-9"/><path d="M14 15c0-3 2-5 1-8"/>'),strike:nt('<path d="M13 2L5 14h6l-2 8 8-12h-6z"/>'),mines:nt('<circle cx="7" cy="15" r="2.5"/><circle cx="17" cy="15" r="2.5"/><circle cx="12" cy="7" r="2.5"/>'),revive:nt('<path d="M12 2.5c1.8 3.6 6 5 6 10.5a6 6 0 0 1-12 0c0-3 1.6-4.6 2.8-7 .9 2 2 3 3.2 3.2-.3-2.3-.7-4.6 0-6.7z"/>')},K_='<svg viewBox="0 0 100 100" fill="none" stroke="#cbb8ff" stroke-width="2.2" aria-hidden="true" style="width:66%;height:66%"><circle cx="50" cy="50" r="46"/><circle cx="50" cy="50" r="40" stroke-dasharray="2 4"/><path d="M50 16L64.75 80.63 23.42 28.8 83.15 57.57H16.85L76.58 28.8 35.25 80.63z" stroke-linejoin="round"/><circle cx="50" cy="50" r="6"/></svg>';function Rn(i,e=""){const t=j_();t.innerHTML="";const n=document.createElement("div");return n.className="screen "+e,n.innerHTML=i,t.appendChild(n),n}function ca(){const i=mu(),e=Math.ceil(i/6e4);return`<div class="chips">
    <div class="chip frm" title="${x("essence")}">${Oe.essence}<span class="sr">${x("essence")}</span><span class="num">${At(C.essence)}</span></div>
    <div class="chip frm" title="${x("ink")}${i?" · +1 "+x("inMin",{n:e}):""}">${Oe.ink}<span class="sr">${x("ink")}</span><span class="num">${C.ink}</span><small>/ ${ri}</small></div>
    <button class="chip frm" data-go="shop:crystals" title="${x("crystals")}">${Oe.crystal}<span class="sr">${x("crystals")}</span><span class="num">${At(C.crystals)}</span><span style="color:var(--muted);font-weight:800">+</span></button>
  </div>`}function Et(i,e=""){const t=document.getElementById("toast"),n=document.createElement("div");n.className="toast frm "+e,n.textContent=i,t.appendChild(n),setTimeout(()=>{n.style.opacity="0",n.style.transition="opacity .3s"},2300),setTimeout(()=>n.remove(),2700)}function pn(i,e,t=[{label:x("ok"),cls:"primary",value:!0}],n={}){return new Promise(s=>{const a=document.getElementById("modal-root"),r=document.createElement("div");r.className="modal-back",r.innerHTML=`<div class="modal frm" role="dialog" aria-modal="true" aria-label="${i}">
      ${i?`<h2>${i}</h2>`:""}
      <div class="modal-body ${n.scroll?"scroll":""}" style="display:flex;flex-direction:column;gap:.8rem">${e}</div>
      <div class="actions">${t.map((c,h)=>`<button class="btn frm ${c.cls||""}" data-i="${h}">${c.label}</button>`).join("")}</div>
    </div>`,a.appendChild(r);const o=c=>{r.remove(),s(c)};r.addEventListener("click",c=>{const h=c.target.closest("[data-i]");h?(Ee.click(),o(t[+h.dataset.i].value)):c.target===r&&n.dismiss!==!1&&o(null)}),n.onMount?.(r),(r.querySelector(".btn.primary, .btn.gold")||r.querySelector(".btn"))?.focus()})}function vl(i,e){return pn(x("confirmBuy"),`<p>${x("confirmBuyBody",{name:i})}</p><p style="font-size:1.3rem;font-weight:800;color:var(--bright)">${e}</p>`,[{label:x("cancel"),value:!1},{label:x("buy"),cls:"primary",value:!0}])}function _l(i){const e=[];return i.essence&&e.push(`${Oe.essence} ${At(i.essence)}`),i.ink&&e.push(`${Oe.ink} ${i.ink}`),i.crystals&&e.push(`${Oe.crystal} ${i.crystals}`),i.fragments&&e.push(`${Oe.frag} ${i.fragments}`),e.join(" · ")}function yn(i,e){i.addEventListener("click",t=>{const n=t.target.closest("[data-action]");if(!n||!i.contains(n))return;const s=e[n.dataset.action];s&&(Ee.click(),s(n,t))})}const Z_="v1.0";function tu(){ye.showcase.setTeam([]);const i=Rn(`
    <div style="margin-top:1.4rem">
      <h1 class="logo">${x("gameTitle")}</h1>
      <div class="tagline"><i></i><span>${x("tagline")}</span><i></i></div>
    </div>
    <div class="title-foot">
      <button class="btn frm primary big" data-action="play">${x("play")}</button>
      <span class="muted" style="letter-spacing:.08em">${x("pressStart")}</span>
    </div>
    <div class="title-top">
      <button class="icon-btn frm" data-action="lang" aria-label="${x("language")}" title="${x("language")}">${Oe.globe}</button>
      <button class="icon-btn frm" data-action="settings" aria-label="${x("settings")}">${Oe.settings}</button>
    </div>
    <div class="title-corner l"><span class="eyebrow" style="color:#c9a0ff">${x("season1")}</span><span class="title" style="font-size:1.6rem">${x("eclipse")}</span></div>
    <span class="title-corner r">${Z_}</span>`,"s-title");i.style.backgroundImage=`url(${eu("arte_clave")})`;const e=()=>{Sl(),C.starterChosen?ye.go("menu"):nu()};yn(i,{play:e,settings:()=>Sr(),lang:()=>{bl(hi()==="es"?"en":"es"),C.settings.lang=hi(),ht(),tu()}});const t=n=>{(n.code==="Enter"||n.code==="Space")&&(document.removeEventListener("keydown",t),Ee.click(),e())};document.addEventListener("keydown",t),ye.onLeave=()=>document.removeEventListener("keydown",t)}function nu(){let i=1;ye.showcase.setTeam(ua.map(t=>({id:t,form:1})),"starter");const e=()=>{const t=Rn(`
      <div style="display:flex;flex-direction:column;gap:.6rem;align-items:center">
        <span class="eyebrow">${x("orderWelcome")}</span>
        <h1 class="title" style="font-size:2.6rem">${x("chooseFirst")}</h1>
        <p class="muted" style="margin:0;max-width:42rem">${x("chooseFirstHelp")}</p>
      </div>
      <div style="display:flex;flex-direction:column;gap:1rem;align-items:center;width:100%">
        <div class="starter-cards">
          ${ua.map((n,s)=>{const a=ct[n];return`<button class="starter-card frm ${s===i?"sel":""}" data-action="pick" data-i="${s}" style="--el:${a.color}">
              <span class="eyebrow" style="color:${a.color}">${re(nn[a.el])} · ${re(us[nn[a.el].domain])} · ${re(Od[a.role])}</span>
              <h3>${re(a.name)}</h3>
              <p>${re(a.lore)}</p>
            </button>`}).join("")}
        </div>
        <div style="display:flex;gap:.8rem;align-items:center;flex-wrap:wrap;justify-content:center">
          <input class="name" maxlength="16" placeholder="${x("yourName")}" value="${C.name||""}" aria-label="${x("yourName")}" style="width:16rem">
          <button class="btn frm primary big" data-action="ok">${x("bindPact")}</button>
        </div>
      </div>`,"s-starter");yn(t,{pick:n=>{i=+n.dataset.i,Ee.summon(ct[ua[i]].el),e()},ok:()=>{const n=ua[i];C.name=(Y_("input.name",t).value||"").trim().slice(0,16)||x("defaultName"),C.creatures[n]={form:0,level:1,xp:0,bond:2,bondXp:0,tint:""},C.bestiary[n].seen=!0,C.bestiary[n].forms[0]=!0,C.team=[n],C.starterChosen=!0,ht(),Ee.sealPerfect(),ye.startExpedition(0,{tutorial:!0})}})};e()}function Vs(i,e,t,n,s=""){return`<button class="nav-item" data-action="${i}"><span class="ico">${e}</span><span class="txt"><span class="lbl">${t}</span><span class="sub">${n}</span></span>${s}</button>`}function xl(){gr(),Wh();const i=pr(),e=t_(i.rank);ye.showcase.setTeam(C.team.map(c=>({id:c,form:C.creatures[c].form,glow:js(C.creatures[c].tint,ct[c].color),seal:ye.sealFor(c)})));const t=Math.min(C.islands.unlocked,It.length-1),n=Vh(),s=C.contracts.list,a=Ui.filter(c=>c.n<=mr()&&(!C.pass.free.includes(c.n)||C.pass.premium&&!C.pass.prem.includes(c.n))).length,r=s.filter(c=>c.progress>=c.goal&&!c.claimed).length,o=Rn(`
    <div class="menu-left">
      <span class="brand">${x("gameTitle").toUpperCase()}</span>
      <div class="player-card">
        <div class="sigil frm">${K_}</div>
        <div class="info">
          <div class="row"><span class="name">${J_(C.name||x("defaultName"))}</span><span class="num muted" style="font-weight:700">${x("rank")} ${i.rank}</span></div>
          <span class="eyebrow" style="color:#cbb8ff">${re(e)}</span>
          <div class="bar"><i style="width:${i.xp/i.need*100}%;background:#cbb8ff;color:#cbb8ff"></i></div>
          <span class="num muted" style="font-size:.9rem">${At(i.xp)} / ${At(i.need)} ${x("xp")}</span>
        </div>
      </div>
      <nav class="nav scroll" aria-label="${x("mainMenu")}">
        <button class="nav-item frm play" data-action="play"><span class="ico">${Oe.play}</span><span class="txt"><span class="lbl">${x("play")}</span><span class="sub">${re(It[t].name)} · ${x("chapter")} ${t+1}</span></span>${Oe.arrow}</button>
        ${Vs("bestiary",Oe.book,x("bestiary"),x("formsSealed",{n:ql()}))}
        ${Vs("team",Oe.team,x("team"),C.team.map(c=>re(ct[c].name).split(" ")[0]).join(" · "))}
        ${Vs("shop",Oe.shop,x("shop"),x("shopSub"))}
        ${Vs("pass",Oe.pass,x("pass"),x("passSub",{n:mr()}),a?`<span class="badge">${a}</span>`:"")}
        ${Vs("settings",Oe.settings,x("settings"),x("settingsSub"))}
      </nav>
    </div>
    <div class="menu-right">
      ${ca()}
      <div class="card daily frm">
        <span style="color:var(--gold);width:2.2rem;height:2.2rem;flex:none">${Oe.gift}</span>
        <div class="body"><span class="ttl">${x("dailyReward")}</span><span class="sub">${x("dayOf",{n:n.day+1})} · ${_l(n.reward)}</span></div>
        <button class="btn frm gold small ${n.can?"":"off"}" data-action="daily">${n.can?x("claim"):x("claimed")}</button>
      </div>
      ${!C.purchases.founder&&je.canBuy()?`<button class="card frm offer-pill" data-go="shop:crystals"><span style="color:var(--crystal);width:2.2rem;height:2.2rem;flex:none">${Oe.crystal}</span><div class="body"><span class="ttl">${x("founderPack")}</span><span class="sub">${x("founderSub")}</span></div>${Oe.arrow}</button>`:""}
      <div class="contracts frm">
        <div style="display:flex;justify-content:space-between;align-items:center"><span class="eyebrow">${x("dailyContracts")}</span>${r?`<span class="badge">${r}</span>`:""}</div>
        ${s.map((c,h)=>`<div class="contract ${c.progress>=c.goal?"done":""}">
          <div class="top"><span>${Kl(c,hi())}</span>${c.claimed?`<span class="muted">${Oe.check.replace("<svg",'<svg style="width:1em;height:1em"')}</span>`:c.progress>=c.goal?`<button class="btn frm small gold" data-action="contract" data-i="${h}">+${At(c.essence)}</button>`:`<span class="num muted">${c.progress}/${c.goal}</span>`}</div>
          <div class="bar thin"><i style="width:${c.progress/c.goal*100}%;background:var(--ok);color:var(--ok)"></i></div>
        </div>`).join("")}
      </div>
      <div class="team-foot">
        <span class="eyebrow">${x("yourTeam")}</span>
        <button class="btn frm" data-action="leader">${x("viewLeader")}</button>
      </div>
    </div>`,"s-menu");yn(o,{play:()=>ye.go("map"),bestiary:()=>ye.go("bestiary"),team:()=>ye.go("bestiary",{filter:"owned"}),shop:()=>ye.go("shop"),pass:()=>ye.go("pass"),settings:()=>Sr(),leader:()=>ye.go("ficha",{id:C.team[0]}),daily:()=>{const c=o_();c&&(Ee.coin(),Et(x("claimedReward")+" "+_l(c).replace(/<svg[\s\S]*?<\/svg>/g,"").trim(),"gold"),xl())},contract:c=>{l_(+c.dataset.i)&&(Ee.coin(),xl())}});const l=Yl();l.length&&setTimeout(()=>Et(x("milestone",{n:l[l.length-1].forms,c:l.reduce((c,h)=>c+h.crystals,0)}),"gold"),600)}function J_(i){return String(i).replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}function Ud(i){const e=-Math.PI/2+i/12*Math.PI*2;return[50+Math.cos(e)*40,50+Math.sin(e)*38]}function Q_(i={}){ye.showcase.setTeam([]);let e=i.sel??Math.min(C.islands.unlocked,It.length-1);const t=()=>{const n=It[e],s=ct[n.boss],a=e>C.islands.unlocked,r=C.islands.cleared.includes(e),o=Rn(`
      <div class="topbar">
        <button class="back frm" data-action="back">${Oe.back}${x("menu")}</button>
        <div style="display:flex;flex-direction:column;align-items:center;gap:.2rem;text-align:center">
          <h1 class="title" style="font-size:2rem">${x("mapTitle")}</h1>
          <span class="muted">${x("mapSub")}</span>
        </div>
        ${ca()}
      </div>
      <div class="map-wrap">
        <div class="map">
          <svg class="links" viewBox="0 0 100 100" preserveAspectRatio="none">
            ${It.map((l,c)=>{const[h,d]=Ud(c);return`<line x1="50" y1="50" x2="${h}" y2="${d}" stroke="${c<=C.islands.unlocked?"rgba(203,184,255,.35)":"rgba(87,81,122,.25)"}" stroke-width=".25" stroke-dasharray="1 1"/>`}).join("")}
          </svg>
          <div class="citadel"><svg viewBox="0 0 100 100" fill="none" stroke="#cbb8ff" stroke-width="2"><circle cx="50" cy="50" r="44"/><circle cx="50" cy="50" r="36" stroke-dasharray="2 4"/><path d="M50 18L80 74H20z"/><path d="M50 82L20 26h60z"/></svg>${x("citadel")}</div>
          ${It.map((l,c)=>{const[h,d]=Ud(c),u=ct[l.boss],m=c>C.islands.unlocked,g=C.islands.cleared.includes(c);return`<button class="isle ${m?"locked":""} ${c===e?"sel":""}" style="left:${h}%;top:${d}%;--el:${u.color}" data-action="sel" data-i="${c}" aria-label="${re(l.name)}">
              <span class="gem"><i></i></span><span class="nm">${re(l.name)}</span><span class="lv">${x("islandN",{n:c+1})} · ${x("lvl")} ${l.levels[0]}–${l.levels[1]}${g?" · ✓":""}</span></button>`}).join("")}
        </div>
        <div class="isle-panel frm" style="--bc:${s.color}">
          <span class="eyebrow" style="color:${s.color}">${x("islandN",{n:e+1})} · ${x("chapter")} ${e+1} · ${x(r?"completed":a?"locked":"inProgress")}</span>
          <h2 class="title" style="font-size:2rem">${re(n.name)}</h2>
          <p class="lore" style="margin:0">${re(n.desc)}</p>
          <div class="facts">
            <span>${x("primordial")}</span><span>${C.bestiary[n.boss].seen?re(s.name):"???"}</span>
            <span>${x("levels")}</span><span>${n.levels[0]}–${n.levels[1]}</span>
            <span>${x("element")}</span><span style="color:${s.color}">${re(nn[s.el])}</span>
            <span>${x("creatures")}</span><span>${n.pool.map(l=>C.bestiary[l].seen?re(ct[l].name).split(" ")[0]:"???").join(" · ")}</span>
            <span>${x("loot")}</span><span>${x("fragmentsOf",{el:re(nn[s.el])})}</span>
          </div>
          ${a?`<button class="btn frm off">${Oe.lock} ${x("clearPrevious")}</button>`:`<button class="btn frm primary big" data-action="travel">${x("travel")}</button>`}
        </div>
      </div>`,"s-map");yn(o,{back:()=>ye.go("menu"),sel:l=>{e=+l.dataset.i,t()},travel:()=>ye.startExpedition(e)})};t()}function ex(i,e){const t=It[i],n=ct[t.boss],s=Eu[hi()],a=s[Math.floor(Math.random()*s.length)],r=En[Math.floor(Math.random()*En.length)],o=Rn(`
    <div class="loading-grid">
      <div>
        <span class="eyebrow">${x("travelingTo")}</span>
        <h1 class="title" style="font-size:3rem">${re(t.name)}</h1>
        <span class="muted">${x("islandN",{n:i+1})} · ${x("levels")} ${t.levels[0]}–${t.levels[1]} · <b style="color:${n.color}">${re(nn[n.el])}</b></span>
        <p class="lore" style="margin:0">${re(t.desc)}</p>
      </div>
      <div><span class="eyebrow">${x("tip")}</span><p style="margin:0;color:var(--bright);font-size:1.05rem;line-height:1.4">${a}</p></div>
      <div><span class="eyebrow">${x("fromBestiary")}</span><b style="color:var(--bright)">${C.bestiary[r.id].seen?re(r.name):"???"}</b><p class="lore" style="margin:0">${re(r.lore)}</p></div>
      <div style="align-items:flex-end"><span class="eyebrow" style="color:var(--ok)">${x("islandReady")}</span><button class="btn frm primary big" data-action="enter">${x("enter")}</button></div>
    </div>`,"s-loading");o.style.backgroundImage=`url(${eu("carga")})`,yn(o,{enter:e});const l=c=>{(c.code==="Enter"||c.code==="Space")&&(document.removeEventListener("keydown",l),e())};document.addEventListener("keydown",l),ye.onLeave=()=>document.removeEventListener("keydown",l)}function Sr(){const i=C.settings,e=`
    <div class="setting"><span>${x("language")}</span><div class="seg"><button data-lang="es" class="${hi()==="es"?"on":""}">Español</button><button data-lang="en" class="${hi()==="en"?"on":""}">English</button></div></div>
    <div class="setting"><span>${x("music")}</span><input type="range" min="0" max="1" step="0.05" value="${i.music}" data-vol="music" aria-label="${x("music")}"></div>
    <div class="setting"><span>${x("sounds")}</span><input type="range" min="0" max="1" step="0.05" value="${i.sfx}" data-vol="sfx" aria-label="${x("sounds")}"></div>
    <div class="setting"><span>${x("graphics")}</span><div class="seg">${["auto","low","medium","high"].map(t=>`<button data-q="${t}" class="${i.quality===t?"on":""}">${x("q_"+t)}</button>`).join("")}</div></div>
    <div class="setting"><span>${x("screenShake")}</span><div class="seg"><button data-shake="1" class="${i.shake?"on":""}">${x("yes")}</button><button data-shake="0" class="${i.shake?"":"on"}">${x("no")}</button></div></div>
    <div class="setting"><span>${x("fullscreen")}</span><button class="btn frm small" data-fs="1">${Oe.fullscreen}</button></div>
    <details><summary style="cursor:pointer;font-weight:700;color:var(--bright);min-height:44px;display:flex;align-items:center">${x("controls")}</summary>
      <div class="keys" style="margin-top:.5rem">
        <kbd>WASD</kbd><span>${x("k_move")}</span><kbd>Q E R</kbd><span>${x("k_abilities")}</span><kbd>F</kbd><span>${x("k_ult")}</span>
        <kbd>${x("space")}</kbd><span>${x("k_dodge")}</span><kbd>1 2 3</kbd><span>${x("k_switch")}</span><kbd>Tab</kbd><span>${x("k_target")}</span>
        <kbd>G</kbd><span>${x("k_seal")}</span><kbd>Esc</kbd><span>${x("k_pause")}</span>
      </div>
      <p class="muted" style="margin:.6rem 0 0;font-size:.9rem">${x("touchHelp")}</p>
    </details>
    <details><summary style="cursor:pointer;font-weight:700;color:var(--bright);min-height:44px;display:flex;align-items:center">${x("privacy")}</summary><p class="muted" style="font-size:.9rem">${x("privacyText")}</p></details>
    <button class="btn frm small" data-reset="1" style="align-self:flex-start;color:var(--danger)">${x("resetProgress")}</button>`;return pn(x("settings"),e,[{label:x("close"),cls:"primary",value:!0}],{scroll:!0,onMount:t=>{t.addEventListener("input",n=>{const s=n.target.dataset.vol;s&&(i[s]=+n.target.value,Xd(i.music,i.sfx),ht())}),t.addEventListener("click",async n=>{const s=n.target.closest("button");s&&(s.dataset.lang&&(bl(s.dataset.lang),i.lang=s.dataset.lang,ht(),t.remove(),ye.refresh(),Sr()),s.dataset.q&&(i.quality=s.dataset.q,ht(),ye.renderer.setQuality(i.quality),t.querySelectorAll("[data-q]").forEach(a=>a.classList.toggle("on",a===s))),s.dataset.shake&&(i.shake=s.dataset.shake==="1",ht(),t.querySelectorAll("[data-shake]").forEach(a=>a.classList.toggle("on",a===s))),s.dataset.fs&&(document.fullscreenElement?document.exitFullscreen?.():document.documentElement.requestFullscreen?.().catch(()=>{})),s.dataset.reset&&await pn(x("resetProgress"),`<p>${x("resetConfirm")}</p>`,[{label:x("cancel"),value:!1},{label:x("reset"),cls:"primary",value:!0}])&&(pu(),t.remove(),location.reload()))})}})}function tx(){return je.hasRewarded()&&C.ads.ink<3}async function iu(){const i=await je.rewarded();return i?(C.ads.ink++,Gd(3),Et(x("inkGained",{n:3}),"good")):Et(x("adUnavailable")),i}function nx(i={}){let e=i.filter||"all";ye.showcase.setTeam([]);const t=()=>{const n=En.filter(r=>{const o=C.bestiary[r.id];return e==="owned"?!!C.creatures[r.id]:e==="seen"?o.seen&&!C.creatures[r.id]:e==="unknown"?!o.seen:!0}),s={owned:En.filter(r=>C.creatures[r.id]).length,seen:En.filter(r=>C.bestiary[r.id].seen&&!C.creatures[r.id]).length,unknown:En.filter(r=>!C.bestiary[r.id].seen).length},a=Rn(`
      <div class="topbar">
        <button class="back frm" data-action="back">${Oe.back}${x("menu")}</button>
        <div style="display:flex;flex-direction:column;gap:.2rem">
          <h1 class="title" style="font-size:2.2rem">${x("greatBestiary")}</h1>
          <span class="muted">${x("bestiarySub")}</span>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:.2rem">
          <span class="eyebrow">${x("sealedForms")}</span>
          <span class="title num" style="font-size:2.2rem">${ql()}<small class="muted" style="font-size:1rem"> / 36</small></span>
        </div>
      </div>
      <div class="tabs" role="tablist" style="margin:.8rem 0">
        ${[["all",x("all")],["owned",`${x("sealedF")} · ${s.owned}`],["seen",`${x("seenF")} · ${s.seen}`],["unknown",`${x("unknownF")} · ${s.unknown}`]].map(([r,o])=>`<button class="tab ${e===r?"on":""}" data-action="filter" data-f="${r}" role="tab" aria-selected="${e===r}">${o}</button>`).join("")}
        <span class="muted" style="margin-left:auto;align-self:center;font-size:.9rem">${e==="owned"?x("teamHelp",{n:sa()}):x("titleHelp")}</span>
      </div>
      <div class="scroll" style="flex:1;min-height:0"><div class="grid">
        ${n.map(r=>{const o=C.bestiary[r.id],l=C.creatures[r.id],c=C.team.includes(r.id),h=o.seen?re(r.name):"???";return`<button class="beast frm" data-action="open" data-id="${r.id}" style="--el:${r.color};${l?`--bc:color-mix(in srgb, ${r.color} 45%, #3b3658)`:""}">
            <div class="img">${l?`<img src="${An("criaturas",r.id)}" alt="" loading="lazy">`:`<img class="sil" src="${An("siluetas",r.id)}" alt="" loading="lazy" style="${o.seen?"opacity:.55":""}">`}
              ${c?`<span class="tag-team">${x("inTeam")}</span>`:""}</div>
            <span class="no">Nº ${r.num}</span>
            <span class="nm">${h}</span>
            <span class="muted" style="font-size:.85rem">${l?`${re(nn[r.el])} · ${x("lvl")} ${l.level}`:o.seen?x("seenNotSealed"):x("undiscovered")}</span>
            <div class="forms">${o.forms.map(d=>`<i class="${d?"on":""}"></i>`).join("")}<span class="muted" style="font-size:.8rem;margin-left:.4rem">${o.forms.filter(Boolean).length}/3</span></div>
          </button>`}).join("")}
      </div></div>`,"s-bestiary");yn(a,{back:()=>ye.go("menu"),filter:r=>{e=r.dataset.f,t()},open:r=>{const o=r.dataset.id;if(!C.bestiary[o].seen){Et(x("notFoundYet",{isle:re(It[ct[o].island].name)}));return}ye.go("ficha",{id:o,from:e})}})};t()}function ix({id:i,from:e}){const t=ct[i],n=()=>{const s=C.creatures[i],a=s?s.form:0,r=s?s.level:1,o=s?js(s.tint,t.color):t.color;ye.showcase.setSingle(i,{form:a,glow:o,seal:ye.sealFor(i),offsetX:-1});const l=Bh(i,r,a),c=s?dl(i):null,h=C.team.includes(i),d=ps.filter(g=>g.creature===i),u=[x("power"),x("defense"),x("agility"),x("magic")],m=Rn(`
      <div class="ficha-info">
        <div class="topbar" style="justify-content:flex-start">
          <button class="back frm" data-action="back">${Oe.back}${x("bestiary")}</button>
          <span class="eyebrow">Nº ${t.num}</span>
          <span class="el-pill" style="--el:${t.color}">${re(nn[t.el])}</span>
        </div>
        <div class="scroll">
          <div style="display:flex;flex-direction:column;gap:.4rem">
            <span class="eyebrow" style="color:${t.color}">${x("domain")} ${re(us[nn[t.el].domain])} · ${re(Od[t.role])} · ${re(t.sub)}</span>
            <h1 class="title" style="font-size:3rem">${re(t.name)}</h1>
            <p class="lore" style="margin:0;font-size:1.15rem">${re(t.lore)}</p>
          </div>
          ${s?`
          <div style="display:flex;gap:1.2rem;align-items:center;flex-wrap:wrap">
            <div style="display:flex;flex-direction:column;gap:.3rem;min-width:12rem;flex:1">
              <span style="font-weight:800;color:var(--bright)">${x("level")} ${r} · ${re(Hn[a])}</span>
              <div class="bar"><i style="width:${r>=Ni?100:s.xp/fr(r)*100}%;background:${t.color};color:${t.color}"></i></div>
              <span class="muted num" style="font-size:.85rem">${r>=Ni?x("maxLevel"):`${At(s.xp)} / ${At(fr(r))} ${x("xp")}`}</span>
            </div>
            <div style="display:flex;flex-direction:column;gap:.3rem"><span class="eyebrow">${x("bond")}</span><div class="bond" style="--el:${t.color}">${[1,2,3,4,5].map(g=>`<i class="${g<=s.bond?"on":""}"></i>`).join("")}</div></div>
          </div>
          <div class="actions">
            <button class="btn frm ${h?"":"accent"}" data-action="team" style="--accent:${t.color}">${x(h?"removeFromTeam":"addToTeam")}</button>
            ${r<Ni?`<button class="btn frm ${C.essence>=cl(r)?"":"off"}" data-action="train">${x("train")} · ${Oe.essence.replace("<svg",'<svg style="width:1.1em;height:1.1em"')} ${At(cl(r))}</button>`:""}
            ${c?`<button class="btn frm ${c.ok?"gold":"off"}" data-action="evolve">${x("evolveTo",{f:re(Hn[c.to])})}</button>`:""}
          </div>
          ${c&&!c.ok?`<span class="muted" style="font-size:.9rem">${c.to===1?x("evoReq1",{have:c.haveFrags,el:re(nn[t.el])}):x("evoReq2",{isle:re(It[t.island].name)})}</span>`:""}
          `:`<div class="frm" style="--c:12px;padding:1rem"><b style="color:var(--bright)">${x("notSealedYet")}</b><p class="muted" style="margin:.3rem 0 0">${x("livesIn",{isle:re(It[t.island].name),n:t.island+1})}</p></div>`}
          <div style="display:flex;flex-direction:column;gap:.5rem">
            <span class="eyebrow">${x("stats300")}</span>
            <div class="stats">${t.stats.map((g,v)=>`<span>${u[v]}</span><div class="bar"><i style="width:${g}%;background:${t.color};color:${t.color}"></i></div><span class="num" style="color:var(--bright);font-weight:700">${g}</span>`).join("")}
              <span>${x("hp")}</span><span></span><span class="num" style="color:var(--bright);font-weight:700">${At(l.hp)}</span></div>
          </div>
          <div style="display:flex;flex-direction:column;gap:.5rem">
            <span class="eyebrow">${x("abilities")}</span>
            <div class="ab-list">${Oh[i].map(g=>{const v=g.key==="r"&&a<1;return`<div class="ab-row ${v?"locked":""}"><span class="k frm" style="${g.key==="f"?`--bc:${t.color}`:""}">${g.key.toUpperCase()}</span><div><b>${re(g.name)}</b>${g.key==="f"?` <span style="color:${t.color}">· ${x("ultimate")}</span>`:""}<br><span>${re(g.desc)}${v?" · "+x("unlocksAdult"):""}</span></div></div>`}).join("")}</div>
          </div>
          <div style="display:flex;flex-direction:column;gap:.5rem">
            <span class="eyebrow">${x("forms")}</span>
            <div class="form-steps" style="--el:${t.color}">${Hn.map((g,v)=>{const f=C.bestiary[i].forms[v],p=f?s&&s.form===v?x("currentForm"):x("sealedF"):x(v===0?"notSealedYet":v===1?"reqAdult":"reqPrimordial");return`<div class="form-step frm ${f?"on":""}"><b>${re(g)}</b><span>${p}</span></div>`}).join("")}</div>
          </div>
          ${s?`<div style="display:flex;flex-direction:column;gap:.5rem">
            <span class="eyebrow">${x("glowTints")}</span>
            <div class="tint-row">
              <button class="tint ${s.tint?"":"on"}" style="background:${t.color}" data-action="tint" data-t="" aria-label="${x("original")}"></button>
              ${d.map(g=>{const v=C.cosmetics.tints.includes(g.id),f=g.color==="prisma"?"prisma":g.color==="aurora"?"aurora":"";return`<button class="tint ${f} ${s.tint===g.id?"on":""} ${v?"":"lock"}" style="${f?"":`background:${g.color}`}" data-action="tint" data-t="${g.id}" title="${re(g.name)}" aria-label="${re(g.name)}"></button>`}).join("")}
            </div>
          </div>`:""}
        </div>
      </div>
      <div class="ficha-right">
        ${ca()}
        <span class="drag-hint">${Oe.globe.replace("<svg",'<svg style="width:1.2em;height:1.2em"')} ${x("dragToRotate")}</span>
      </div>`,"s-ficha");yn(m,{back:()=>ye.go("bestiary",{filter:e}),team:()=>{if(h){if(C.team.length<=1){Et(x("teamMin"));return}C.team=C.team.filter(g=>g!==i)}else{if(C.team.length>=sa()){Et(x("teamFull",{n:sa()}));return}C.team.push(i),Ee.summon(t.el)}ht(),n()},train:()=>{s_(i)?(Ee.levelUp(),n()):Ee.error()},evolve:async()=>{const g=dl(i);if(!g?.ok)return;await pn(x("evolve"),`<p>${x("evolveConfirm",{name:re(t.name),f:re(Hn[g.to])})}</p>`,[{label:x("cancel"),value:!1},{label:x("evolve"),cls:"gold",value:!0}])&&a_(i)&&(Ee.sealPerfect(),Et(x("evolved",{name:re(t.name),f:re(Hn[g.to])}),"gold"),Yl(),n())},tint:async g=>{const v=g.dataset.t;if(!v||C.cosmetics.tints.includes(v)){s.tint=v,ht(),ye.showcase.setGlow(js(v,t.color)),n();return}ye.showcase.setGlow(Xs[v].color);const f=await pn(re(Xs[v].name),`<p>${x("tintPreview",{name:re(t.name)})}</p>`,[{label:x("close"),value:!1},{label:`${x("buy")} · ${Xs[v].price}`,cls:"primary",value:!0}]);ye.showcase.setGlow(js(s.tint,t.color)),f&&ye.buyCosmetic("tint",v,()=>n())}})};n()}const sx="modulepreload",ax=function(i,e){return new URL(i,e).href},Nd={},Fd=function(e,t,n){let s=Promise.resolve();if(t&&t.length>0){const r=document.getElementsByTagName("link"),o=document.querySelector("meta[property=csp-nonce]"),l=o?.nonce||o?.getAttribute("nonce");s=Promise.allSettled(t.map(c=>{if(c=ax(c,n),c in Nd)return;Nd[c]=!0;const h=c.endsWith(".css"),d=h?'[rel="stylesheet"]':"";if(!!n)for(let g=r.length-1;g>=0;g--){const v=r[g];if(v.href===c&&(!h||v.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${c}"]${d}`))return;const m=document.createElement("link");if(m.rel=h?"stylesheet":sx,h||(m.as="script"),m.crossOrigin="",m.href=c,l&&m.setAttribute("nonce",l),document.head.appendChild(m),h)return new Promise((g,v)=>{m.addEventListener("load",g),m.addEventListener("error",()=>v(new Error(`Unable to preload CSS for ${c}`)))})}))}function a(r){const o=new Event("vite:preloadError",{cancelable:!0});if(o.payload=r,window.dispatchEvent(o),!o.defaultPrevented)throw r}return s.then(r=>{for(const o of r||[])o.status==="rejected"&&a(o.reason);return e().catch(a)})},Ks=i=>`<span class="price">${Oe.crystal.replace("<svg",'<svg style="width:1.1em;height:1.1em"')} ${At(i)}</span>`;function rx(i={}){let e=i.tab||"tints";ye.showcase.setTeam([]);const t=()=>{C.ads.date!==di()&&(C.ads={date:di(),ink:0,chest:!1},ht());const n=[["crystals",x("getCrystals")],["tints",x("glowTints")],["seals",x("sealDesigns")],["effects",x("summonEffects")],["free",x("freeOffers")]];let s="";if(e==="crystals")je.canBuy()?s=`<div class="grid">${Zd.filter(r=>!(r.once&&(r.sku==="fundador"&&C.purchases.founder||r.sku==="pase_premium"&&C.pass.premium||r.sku==="sin_anuncios"&&C.purchases.noAds))).filter(r=>!r.standaloneOnly||je.name==="web").map(r=>`
          <div class="item frm ${r.best?"featured":""}">
            <div class="art">${r.best?`<span class="ribbon">${x("bestValue")}</span>`:r.tag?`<span class="ribbon">${x("tag_"+r.tag)}</span>`:""}
              ${r.sku==="fundador"?`<img src="${An("criaturas",C.team[0]||"fenix")}" alt="">`:r.sku==="pase_premium"?`<img src="${An("tintes","hidra_eclipsedorado")}" alt="">`:'<span class="swatch" style="color:var(--crystal);background:radial-gradient(circle at 35% 30%, #ffd6f4, #ff4fd2 60%, #6b1a5a)"></span>'}</div>
            <h3>${re(r.name)}</h3>${r.desc?`<p>${re(r.desc)}</p>`:""}
            <button class="btn frm primary buy" data-action="iap" data-sku="${r.sku}">US$ ${r.usd.toFixed(2)}</button>
          </div>`).join("")}</div>`:s=`<div class="frm" style="--c:14px;padding:1.4rem;max-width:40rem;display:flex;flex-direction:column;gap:.6rem"><b style="color:var(--bright);font-size:1.2rem">${x("earnCrystals")}</b><p class="muted" style="margin:0">${x("earnCrystalsHelp")}</p></div>`;else if(e==="tints")s=`<div class="grid">${[...ps].sort((o,l)=>(l.season?1:0)-(o.season?1:0)||(C.creatures[l.creature]?1:0)-(C.creatures[o.creature]?1:0)).map(o=>{const l=ct[o.creature],c=C.cosmetics.tints.includes(o.id),h=o.color==="prisma"?"conic-gradient(#ff3d3d,#ffd76a,#3dff88,#2ff2d6,#4fb4ff,#b06bff,#ff4fd2,#ff3d3d)":o.color==="aurora"?"linear-gradient(135deg,#9fefff,#3dff88,#b06bff,#ff4fd2)":o.color;return`<div class="item frm ${o.season?"featured":""}">
          <div class="art">${o.season?`<span class="ribbon">${x("seasonEclipse")}</span>`:""}${o.img?`<img src="${An("tintes",o.img)}" alt="" loading="lazy">`:`<img src="${An("criaturas",o.creature)}" alt="" loading="lazy" style="filter:saturate(.2) brightness(.7)"><span class="swatch" style="position:absolute;width:30%;background:${h};color:${o.color.startsWith("#")?o.color:"#fff"}"></span>`}</div>
          <h3>${re(o.name)}</h3><p>${x("tintFor",{name:re(l.name)})}</p>
          ${c?`<button class="btn frm off buy">${x("owned")}</button>`:`<button class="btn frm buy" data-action="buy" data-kind="tint" data-id="${o.id}">${Ks(o.price)}</button>`}
        </div>`}).join("")}</div>`;else if(e==="seals")s=`<div class="grid">${jd.map(r=>{const o=C.cosmetics.seals.includes(r.id),l=C.cosmetics.seal===r.id;return`<div class="item frm ${r.season?"featured":""}">
          <div class="art" style="background:radial-gradient(circle,#1d1640,#0d0b1e)">${r.season?`<span class="ribbon">${x("seasonEclipse")}</span>`:""}<canvas data-seal="${r.id}" width="256" height="256" style="width:80%;height:80%"></canvas></div>
          <h3>${re(r.name)}</h3><p>${re(r.desc)}</p>
          ${o?`<button class="btn frm buy ${l?"off":"accent"}" data-action="equip" data-kind="seal" data-id="${r.id}">${x(l?"equipped":"equip")}</button>`:`<button class="btn frm buy" data-action="buy" data-kind="seal" data-id="${r.id}">${Ks(r.price)}</button>`}
        </div>`}).join("")}</div>`;else if(e==="effects")s=`<div class="grid">${Kd.map(r=>{const o=C.cosmetics.effects.includes(r.id),l=C.cosmetics.effect===r.id;return`<div class="item frm">
          <div class="art" style="background:radial-gradient(circle,#1d1640,#0d0b1e)"><span class="swatch" style="width:40%;color:#cbb8ff;background:radial-gradient(circle,#fff,#b06bff 60%,transparent 70%)"></span></div>
          <h3>${re(r.name)}</h3><p>${x("effectHelp")}</p>
          ${o?`<button class="btn frm buy ${l?"off":"accent"}" data-action="equip" data-kind="effect" data-id="${r.id}">${x(l?"equipped":"equip")}</button>`:`<button class="btn frm buy" data-action="buy" data-kind="effect" data-id="${r.id}">${Ks(r.price)}</button>`}
        </div>`}).join("")}</div>`;else if(e==="free"){const r=je.hasRewarded();s=`<div class="grid">
        <div class="item frm"><div class="art"><span class="swatch" style="color:var(--ink-blue);background:radial-gradient(circle,#dff6ff,#8fd8ff 60%,transparent 70%)"></span></div>
          <h3>+3 ${x("ink")}</h3><p>${x("adInkHelp",{n:3-C.ads.ink})}</p>
          <button class="btn frm buy ${r&&C.ads.ink<3?"primary":"off"}" data-action="adInk">${Oe.ad} ${x("watchAd")}</button></div>
        <div class="item frm"><div class="art"><span style="width:45%;color:var(--gold)">${Oe.gift}</span></div>
          <h3>${x("dailyChest")}</h3><p>${x("dailyChestHelp")}</p>
          <button class="btn frm buy ${r&&!C.ads.chest?"gold":"off"}" data-action="adChest">${C.ads.chest?x("claimed"):`${Oe.ad} ${x("watchAd")}`}</button></div>
        <div class="item frm"><div class="art"><span style="width:45%;color:var(--crystal)">${Oe.book}</span></div>
          <h3>${x("bestiaryMilestones")}</h3><p>${x("bestiaryMilestonesHelp")}</p>
          <button class="btn frm buy" data-action="goBestiary">${x("bestiary")}</button></div>
      </div>
      ${r?"":`<p class="muted">${x("noAdsHere")}</p>`}`}const a=Rn(`
      <div class="topbar">
        <button class="back frm" data-action="back">${Oe.back}${x("menu")}</button>
        <h1 class="title" style="font-size:2.2rem">${x("shop")}</h1>
        ${ca()}
      </div>
      <div class="tabs" role="tablist" style="margin:.8rem 0 .2rem">${n.map(([r,o])=>`<button class="tab ${e===r?"on":""}" data-action="tab" data-t="${r}" role="tab" aria-selected="${e===r}">${o}</button>`).join("")}</div>
      <div class="rules"><span>${x("rule1")}</span><span>${x("rule2")}</span><span>${x("rule3")}</span><span>${x("rule4")}</span></div>
      <div class="scroll" style="flex:1;min-height:0">${s}</div>`,"s-shop");ox(a),yn(a,{back:()=>ye.go("menu"),tab:r=>{e=r.dataset.t,t()},buy:r=>ye.buyCosmetic(r.dataset.kind,r.dataset.id,t),equip:r=>{r.dataset.kind==="seal"?C.cosmetics.seal=r.dataset.id:C.cosmetics.effect=r.dataset.id,ht(),Ee.shield(),t()},iap:r=>ye.buyProduct(r.dataset.sku),adInk:async()=>{await iu(),t()},adChest:async()=>{await je.rewarded()?(C.ads.chest=!0,jl({essence:500,crystals:5}),Et(x("claimedReward")+" 500 + 5","gold"),Ee.coin()):Et(x("adUnavailable")),t()},goBestiary:()=>ye.go("bestiary")})};t()}function ox(i){i.querySelectorAll("canvas[data-seal]").forEach(e=>{const t=e.dataset.seal,n=t==="propio"?"hexagrama":t;Fd(async()=>{const{assets:s}=await Promise.resolve().then(()=>f_);return{assets:s}},void 0,import.meta.url).then(({assets:s})=>Fd(async()=>{const{MagicCircle:a}=await Promise.resolve().then(()=>__);return{MagicCircle:a}},void 0,import.meta.url).then(({MagicCircle:a})=>{const r=new a(n,"#cbb8ff",1),o=e.getContext("2d");o.globalCompositeOperation="lighter";for(const l of r.layers){const c=l.material.map,h=c&&(c.image||c.source?.data);h&&o.drawImage(h,0,0,256,256)}o.globalCompositeOperation="source-in",o.fillStyle=t==="eclipse"?"#ffd76a":"#cbb8ff",o.fillRect(0,0,256,256),r.dispose()}))})}function lx(){ye.showcase.setTeam([]);const i=()=>{const e=mr(),t=C.pass.xp%wl,n=a=>a?a.tint?`${Oe.star}<span>${x("tint")}</span>`:a.seal?`${Oe.seal}<span>${x("seal")}</span>`:a.effect?`${Oe.star}<span>${x("effect")}</span>`:`<span style="display:flex;flex-direction:column;gap:.2rem;align-items:center">${_l(a).split(" · ").map(r=>`<span style="display:flex;align-items:center;gap:.3rem">${r.replace("<svg",'<svg style="width:1.2em;height:1.2em"')}</span>`).join("")}</span>`:"",s=Rn(`
      <div class="topbar">
        <button class="back frm" data-action="back">${Oe.back}${x("menu")}</button>
        <div style="display:flex;flex-direction:column;gap:.2rem;align-items:center;text-align:center">
          <span class="eyebrow" style="color:#c9a0ff">${x("season1")} · ${x("eclipse")}</span>
          <h1 class="title" style="font-size:2.2rem">${x("pass")}</h1>
        </div>
        ${ca()}
      </div>
      <div style="display:flex;gap:1.4rem;align-items:center;flex-wrap:wrap;margin-top:1rem">
        <div style="display:flex;flex-direction:column;gap:.3rem;min-width:16rem;flex:1">
          <span style="font-weight:800;color:var(--bright)">${x("passLevel",{n:e,m:Ui.length})}</span>
          <div class="bar"><i style="width:${e>=Ui.length?100:t}%;background:#c9a0ff;color:#c9a0ff"></i></div>
          <span class="muted" style="font-size:.9rem">${x("passHelp")}</span>
        </div>
        ${C.pass.premium?`<span class="eyebrow" style="color:var(--gold)">${Oe.check.replace("<svg",'<svg style="width:1.2em;height:1.2em;vertical-align:-.2em"')} ${x("premiumActive")}</span>`:`
          <button class="btn frm gold" data-action="premium">${x("unlockPremium")} · ${Ks(ma)}</button>
          ${je.canBuy()?'<button class="btn frm" data-action="premiumIap">US$ 4.99</button>':""}`}
      </div>
      <div class="pass-track" style="flex:1;min-height:0;align-items:flex-start">
        <div class="tier" style="width:6rem;padding-top:1.6rem"><div class="slot" style="--bc:transparent;--bgc:transparent">${x("free")}</div><div class="slot" style="--bc:transparent;--bgc:transparent;color:var(--gold)">${x("premium")}</div></div>
        ${Ui.map(a=>{const r=e>=a.n,o=C.pass.free.includes(a.n),l=C.pass.prem.includes(a.n);return`<div class="tier ${r?"reached":""}">
            <span class="n">${a.n}</span>
            <button class="slot frm ${o?"claimed":r?"claimable":""}" ${r&&!o?`data-action="claim" data-n="${a.n}" data-tr="free"`:""}>${n(a.free)}</button>
            <button class="slot prem frm ${l?"claimed":r&&C.pass.premium?"claimable":""}" ${r&&C.pass.premium&&!l?`data-action="claim" data-n="${a.n}" data-tr="prem"`:""}>${C.pass.premium?"":Oe.lock.replace("<svg",'<svg style="width:1rem;height:1rem;opacity:.6"')}${n(a.prem)}</button>
          </div>`}).join("")}
      </div>`,"s-pass");yn(s,{back:()=>ye.go("menu"),claim:a=>{c_(+a.dataset.n,a.dataset.tr)&&(Ee.coin(),i())},premium:async()=>{if(C.crystals<ma){Et(x("notEnoughCrystals")),ye.go("shop",{tab:"crystals"});return}await vl(x("passPremium"),Ks(ma))&&(C.crystals-=ma,C.pass.premium=!0,ht(),Ee.sealPerfect(),i())},premiumIap:()=>ye.buyProduct("pase_premium")})};i()}let zn=null,Re={},kd=0,yl=null;function cx(i){const e=document.getElementById("ui");e.innerHTML="",zn=document.createElement("div"),zn.className="hud",zn.innerHTML=`
    <div class="self">
      <div class="portrait frm" data-el><div class="pclip"><img data-pimg alt=""></div></div>
      <div>
        <div class="bars">
          <div class="nm"><span data-pname></span><span class="num" data-plvl></span></div>
          <div class="bar"><i data-php style="background:var(--bright);color:var(--bright)"></i></div>
          <div class="lbl"><span>${x("hp")}</span><span class="num" data-phpt></span></div>
          <div class="bar en"><i data-pen style="background:var(--ink-blue);color:var(--ink-blue)"></i></div>
          <div class="bar sl"><i data-psl></i></div>
          <div class="lbl"><span>${x("energy")} · ${x("sealBar")}</span><span class="num" data-pslt></span></div>
        </div>
        <div class="bench" data-bench></div>
      </div>
    </div>
    <div class="target" data-target style="display:none">
      <div class="row"><span class="nm"><span class="diamond" data-tdot></span><span data-tname></span></span><span class="num muted" data-tlvl style="font-weight:700"></span></div>
      <div class="bar"><i data-thp></i></div>
      <div class="row"><span class="adv" data-tadv></span><span class="sealable" data-tseal></span></div>
    </div>
    <div class="tr">
      <div class="chip frm">${Oe.ink}<span class="sr">${x("ink")}</span><span class="num" data-ink></span></div>
      <button class="icon-btn frm" data-action="pause" aria-label="${x("pause")}">${Oe.pause}</button>
    </div>
    <div class="wave-info">
      <span class="eyebrow" data-wave></span>
      <span class="muted" style="font-size:.9rem" data-contract></span>
    </div>
    <div class="joy-hint">${x("move")}</div>
    <div class="abilities" data-abs></div>
    <div class="seal-prompt" data-sealp style="display:none">
      <button class="btn frm" data-action="seal">${Oe.seal} ${x("traceSealBtn")}</button>
      <small data-sealsub></small>
    </div>
    <div data-banner></div>
    <span class="swipe-hint">${x("swipeDodge")}</span>`,e.appendChild(zn),Re={},zn.querySelectorAll("*").forEach(t=>{for(const n of t.getAttributeNames())n.startsWith("data-")&&!["data-action","data-k"].includes(n)&&(Re[n.slice(5)]=t)}),yn(zn,{pause:()=>ye.pause(),seal:()=>Ii("seal"),ab:t=>Ii(t.dataset.k),sw:t=>Ii("sw"+t.dataset.i)}),zn.addEventListener("pointerdown",t=>{const n=t.target.closest("[data-k]");n&&t.pointerType!=="mouse"&&(t.preventDefault(),Ii(n.dataset.k))}),yl=null,su(i)}function dx(i){const e=i.abilities,t=["q","e","r"].map(s=>{const a=e.find(o=>o.key===s);return`<button class="ab frm ${!i.hasAbility(s)?"locked":""}" data-action="ab" data-k="${s}" aria-label="${re(a.name)}" title="${re(a.name)} — ${re(a.desc)}">
      <span class="key">${s.toUpperCase()}</span>${Ya[a.type]||Ya.aoe}<span class="nm">${re(a.name)}</span><span class="cd" data-cd-${s} style="display:none"></span></button>`}).join(""),n=e.find(s=>s.key==="f");Re.abs.innerHTML=`<button class="ab frm dodge" data-action="ab" data-k="dodge" aria-label="${x("dodge")}"><span class="key">${x("spaceShort")}</span>${Ya.dash.replace('<path d="M20.5 5v14"/>',"")}<span class="cd" data-cd-dodge style="display:none"></span></button>${t}
    <button class="ab frm ult" data-action="ab" data-k="f" style="--el:${i.def.color}" aria-label="${re(n.name)}" title="${re(n.name)} — ${re(n.desc)}"><span class="fill"></span><span class="key" style="z-index:1">F</span><span style="z-index:1;display:flex">${Ya.revive}</span><span class="nm" style="z-index:1">${re(n.name)}</span></button>`,Re.abs.querySelectorAll('[class^="cd"], .cd').forEach(s=>{for(const a of s.getAttributeNames())a.startsWith("data-cd-")&&(Re["cd-"+a.slice(8)]=s)}),Re.ult=Re.abs.querySelector(".ult")}function hx(i){Re.bench.innerHTML=i.team.map((e,t)=>`<button class="frm ${e.fainted?"fainted":""}" data-action="sw" data-i="${t+1}" style="--bc:${e===i.player?e.def.color:"var(--line2)"}" aria-label="${x("switchTo",{name:re(e.def.name)})}">
    <div class="pclip" style="width:100%;height:100%;overflow:hidden;clip-path:polygon(6px 0,100% 0,100% calc(100% - 6px),calc(100% - 6px) 100%,0 100%,0 6px)"><img src="${An("criaturas",e.id)}" alt="" style="width:100%;height:100%;object-fit:cover;transform:scale(1.5)"></div>
    <span class="hp"><i style="width:${e.hp/e.maxHp*100}%"></i></span><span class="k">${t+1}</span></button>`).join("")}let Ml="";function su(i){if(!zn||!i.player)return;const e=i.player;yl!==e&&(yl=e,Re.el.style.setProperty("--el",e.def.color),Re.pimg.src=An("criaturas",e.id),Re.pname.textContent=re(e.def.name).split(" ")[0],Re.psl.style.background=e.def.color,Re.psl.style.color=e.def.color,dx(e)),Re.plvl.textContent=`${x("lvl")} ${e.level}`,Re.php.style.width=e.hp/e.maxHp*100+"%",Re.php.style.background=e.hp/e.maxHp<.3?"var(--danger)":"var(--bright)",Re.phpt.textContent=`${At(e.hp)} / ${At(e.maxHp)}${e.shield>1?` (+${At(e.shield)})`:""}`,Re.pen.style.width=e.energy+"%",Re.psl.style.width=e.seal+"%",Re.pslt.textContent=`${Math.floor(e.energy)} · ${Math.floor(e.seal)} %`,Re.ink.textContent=C.ink;const t=i.team.map(r=>`${r.id}${r.fainted}${Math.round(r.hp/r.maxHp*20)}`).join()+i.player.id;t!==Ml&&(Ml=t,hx(i));for(const r of["q","e","r"]){const o=Re["cd-"+r];if(!o)continue;const l=e.cds[r],c=e.ability(r),h=e.energy<(c.cost||0);o.style.display=l>0||h?"flex":"none",o.textContent=l>0?Math.ceil(l):""}Re["cd-dodge"]&&(Re["cd-dodge"].style.display=e.dodgeCd>0?"flex":"none",Re["cd-dodge"].textContent=""),Re.ult&&(Re.ult.style.setProperty("--p",e.seal+"%"),Re.ult.classList.toggle("ready",e.seal>=100));const n=i.boss&&i.boss.alive?i.boss:i.currentTarget();if(n&&!n.anchor){Re.target.style.display="flex",Re.target.classList.toggle("boss",!!n.boss),Re.tdot.style.color=n.def.color,Re.tname.textContent=re(n.def.name),Re.tlvl.textContent=`${x("lvl")} ${n.level} · ${re(Hn[n.form])}`,Re.thp.style.width=n.hp/n.maxHp*100+"%",Re.thp.style.background=n.def.color,Re.thp.style.color=n.def.color;const r=Bd(e.def.el,n.def.el),o=us[nn[e.def.el].domain],l=us[nn[n.def.el].domain];Re.tadv.className="adv "+(r>1?"good":r<1?"bad":""),Re.tadv.textContent=r>1?`${re(o)} ${x("beats")} ${re(l)} · +30 %`:r<1?`${re(l)} ${x("beats")} ${re(o)} · −23 %`:`${re(o)} · ${re(l)}`,Re.tseal.textContent=n.invuln?x("shieldedAnchors",{n:i.anchors.length}):n.sealable?x("sealable"):""}else n&&n.anchor?(Re.target.style.display="flex",Re.tname.textContent=x("runeAnchor"),Re.tlvl.textContent=`${i.anchors.length} / 4`,Re.thp.style.width=n.hp/n.maxHp*100+"%",Re.tadv.textContent="",Re.tseal.textContent=x("breakAnchors")):Re.target.style.display="none";const s=i.nearestSealable();s&&!i.over?(Re.sealp.style.display="flex",Re.sealsub.textContent=s.boss?x("bossSealFree"):C.ink>0?x("sealCost",{n:C.ink}):x("noInk")):Re.sealp.style.display="none",Re.wave.textContent=i.bossStage?i.boss?re(i.boss.def.name):"":x("wave",{a:Math.min(i.waveIdx+1,i.waveCount),b:i.waveCount});const a=C.contracts.list.find(r=>!r.claimed&&r.progress<r.goal);Re.contract.textContent=a?`${x("contract")}: ${Kl(a,hi())} · ${a.progress}/${a.goal}`:""}function ux(i,e="",t=1.6,n=!1){if(!Re.banner)return;const s=typeof i=="object";Re.banner.innerHTML=`<div class="banner ${e}">${s?re(i):i}${n&&e==="boss"?`<small>${x("primordial")}</small>`:n&&e==="ult"?`<small>${x("ultimate")}</small>`:""}</div>`,clearTimeout(kd),kd=setTimeout(()=>{Re.banner&&(Re.banner.innerHTML="")},t*1e3)}function fx(){zn=null,Re={},Ml=""}function px(i){ye.showcase.setTeam([]);const e=i.rewards,t=e.sealed[0],n=t?ct[t.id]:null,s=i.victory?e.bossSealed?x("primordialSealed"):x("expeditionDone"):x("retreated"),a=Rn(`
    <div class="results">
      <div class="hero">
        <span class="eyebrow" style="color:${n?n.color:"var(--gold)"}">${i.newEntries?x("newEntry",{n:i.newEntries}):i.victory?x("victory"):x("withdrawal")}</span>
        <h1 class="title">${s}</h1>
        ${i.unlocked?`<p style="margin:0;color:var(--gold);font-weight:800">${x("islandUnlocked",{isle:i.unlocked})}</p>`:""}
        ${e.sealed.map(r=>{const o=ct[r.id];return`<div class="sealed-card frm" style="--el:${o.color}"><img src="${An("criaturas",r.id)}" alt="">
            <div style="display:flex;flex-direction:column;gap:.2rem"><b style="color:var(--bright);font-size:1.1rem">${re(o.name)}</b>
            <span class="muted">${r.boss?x("primordial"):re(Hn[0])} · ${x("lvl")} ${r.level}${r.perfect?` · <b style="color:var(--gold)">${x("perfectTrace")}</b>`:""}</span>
            <span class="muted" style="font-size:.85rem">${r.isNew?`<b style="color:var(--ok)">${x("newCreature")}</b>`:x("duplicateBonus")}</span></div></div>`}).join("")}
        <div style="display:flex;flex-direction:column;gap:.4rem;width:100%">
          <span class="eyebrow">${x("teamXp")}</span>
          ${i.xp.map(r=>`<div class="xp-row"><img src="${An("criaturas",r.id)}" alt="" style="clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)"><b style="color:var(--bright)">${re(ct[r.id].name).split(" ")[0]}</b><span class="num muted">${x("lvl")} ${r.level}</span><span class="num" style="color:var(--bright)">+${At(r.xp)} ${x("xp")}</span>${r.ups?`<span class="lvup">▲ ${r.ups}</span>`:""}</div>`).join("")}
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:1rem;justify-content:center">
        <div class="reward-list">
          <div class="reward frm"><span class="v num">+${At(i.essence)}</span><div class="t"><b>${x("essence")}</b><span>${e.perfect?x("inclPerfect"):x("essenceHelp")}</span></div></div>
          ${i.fragments?`<div class="reward frm"><span class="v num">+${i.fragments}</span><div class="t"><b>${x("fragments")}</b><span>${x("fragmentsHelp")}</span></div></div>`:""}
          ${i.crystals?`<div class="reward frm" style="--bc:var(--crystal)"><span class="v num">+${i.crystals}</span><div class="t"><b>${x("crystals")}</b><span>${x("firstClear")}</span></div></div>`:""}
          <div class="reward frm"><span class="v num">+${i.passXp}</span><div class="t"><b>${x("passXp")}</b><span>${x("passXpHelp")}</span></div></div>
          ${i.contractsDone.map(r=>`<div class="reward frm" style="--bc:var(--ok)"><span class="v">${Oe.check.replace("<svg",'<svg style="width:2rem;height:2rem;color:var(--ok)"')}</span><div class="t"><b>${x("contractDone")}</b><span>${Kl(r,hi())}</span></div></div>`).join("")}
        </div>
        <div class="actions">
          ${i.canDouble?`<button class="btn frm gold" data-action="double">${Oe.ad} ${x("doubleEssence")}</button>`:""}
          <button class="btn frm primary big" data-action="cont">${x("continue")}</button>
        </div>
      </div>
    </div>`,"s-results");yn(a,{double:async r=>{r.classList.add("off"),await je.rewarded()?(C.essence+=i.essence,Et(x("doubled",{n:At(i.essence)}),"gold"),r.remove()):(Et(x("adUnavailable")),r.classList.remove("off"))},cont:async()=>{await je.interstitial(),ye.go(i.victory&&e.bossSealed?"map":"menu",i.victory&&e.bossSealed?{sel:Math.min(C.islands.unlocked,11)}:{})}})}const ye={renderer:null,showcase:null,combat:null,current:null,params:null,onLeave:null,go(i,e={}){C.team=C.team.filter(n=>C.creatures[n]),!C.team.length&&Object.keys(C.creatures).length&&(C.team=[Object.keys(C.creatures)[0]]),this.onLeave?.(),this.onLeave=null,this.combat&&i!=="hud"&&this.endCombat(),this.current=i,this.params=e,document.body.classList.toggle("in-combat",i==="hud"),i!=="hud"&&(this.showcase.activate(),rr("menu")),{title:tu,starter:nu,menu:xl,map:Q_,bestiary:nx,ficha:ix,shop:rx,pass:lx}[i]?.(e)},refresh(){this.current&&this.current!=="hud"&&this.go(this.current,this.params)},sealFor(i){const e=C.cosmetics.seal;return e&&e!=="propio"?e:ct[i].circle},startExpedition(i,e={}){Sl(),this.showcase.setTeam([]);const t=()=>{je.gameplayStart(),this.current="hud",document.body.classList.add("in-combat");const n=C.team.filter(s=>C.creatures[s]).slice(0,sa());this.combat=new W_(this.renderer,document.getElementById("dmg"),this.combatEvents()),this.combat.start({islandIdx:i,team:n,tutorial:!!e.tutorial,waves:e.tutorial?3:4}),cx(this.combat),e.tutorial&&this.tutorialHints(),nr()};e.tutorial?t():ex(i,t)},tutorialHints(){(He.touch||matchMedia("(pointer: coarse)").matches?["tut1t","tut2t","tut3","tut4"]:["tut1","tut2","tut3","tut4"]).forEach((t,n)=>setTimeout(()=>{this.combat&&!this.combat.over&&Et(x(t))},1500+n*5200))},combatEvents(){return{hud:i=>su(i),banner:(i,e,t,n)=>ux(i,e,t,n),sealStart:i=>this.startSeal(i),choice:()=>this.bossChoice(),defeat:()=>this.defeatModal(),end:(i,e,t)=>this.finishExpedition(i,e,t)}},async startSeal(i){const e=this.combat;if(!e||i.sealing)return;if(!i.boss){if(C.ink<=0&&(Ee.error(),tx()?(e.paused=!0,await pn(x("noInkTitle"),`<p>${x("noInkBody")}</p>`,[{label:x("cancel"),value:!1},{label:`${x("watchAd")} · +3`,cls:"primary",value:!0}])&&await iu(),e.paused=!1):Et(x("noInk")),C.ink<=0))return;gu()}i.sealing=!0,e.paused=!0,je.gameplayStop();const t=ct[i.id],n=i.boss?9:Math.min(7,Math.max(4,t.nodes-2+Math.floor(e.islandIdx/4)));q_({root:document.getElementById("modal-root"),color:i.visual.glowColor.getStyle(),name:re(t.name),nodes:n,moving:i.boss||i.form>=1,time:i.boss?7:5,boss:i.boss,ink:C.ink+1,onDone:s=>{e.paused=!1,je.gameplayStart(),e.sealResult(i,s),s!=="fail"&&je.happytime(),nr()}})},async bossChoice(){const i=this.combat;i.paused=!0;const e=It[i.islandIdx],t=C.islands.cleared.includes(i.islandIdx),n=await pn(x("pathEnds"),`<p>${t?x("bossAgain",{name:re(ct[e.boss].name)}):x("bossFirst")}</p>`,[{label:x("returnCitadel"),value:"leave"},{label:x("facePrimordial"),cls:"primary",value:"boss"}],{dismiss:!1});if(i.paused=!1,n==="boss"){for(const s of i.team)s.fainted||(s.hp=s.maxHp,s.energy=100);i.startBoss()}else i.finish(!0)},async defeatModal(){const i=this.combat;if(!i)return;i.paused=!0,je.gameplayStop();const e=150+i.islandIdx*80,t=[{label:x("retreat"),value:"retreat"}];i.revivesUsed<2&&(C.essence>=e&&t.push({label:`${x("revive")} · ${At(e)} ${x("essenceShort")}`,value:"essence"}),je.hasRewarded()&&t.push({label:`${x("revive")} · ${x("ad")}`,cls:"primary",value:"ad"}));const n=await pn(x("teamFell"),`<p>${x("teamFellBody")}</p>`,t,{dismiss:!1});if(n==="ad"){if(await je.rewarded()){i.paused=!1,i.revive(),je.gameplayStart();return}return Et(x("adUnavailable")),this.defeatModal()}if(n==="essence"){C.essence-=e,ht(),i.paused=!1,i.revive(),je.gameplayStart();return}i.paused=!1,i.rewards.essence=Math.floor(i.rewards.essence*.5),i.rewards.xp=Math.floor(i.rewards.xp*.5),i.finish(!1)},pause(){const i=this.combat;!i||i.paused||(i.paused=!0,je.gameplayStop(),pn(x("pause"),`<p class="muted">${re(It[i.islandIdx].name)} · ${x("wave",{a:Math.min(i.waveIdx+1,i.waveCount),b:i.waveCount})}</p>`,[{label:x("settings"),value:"settings"},{label:x("abandon"),value:"abandon"},{label:x("resume"),cls:"primary",value:"resume"}]).then(async e=>{if(e==="settings"){await Sr(),i.paused=!1,this.pause();return}if(e==="abandon"){if(await pn(x("abandon"),`<p>${x("abandonBody")}</p>`,[{label:x("cancel"),value:!1},{label:x("abandon"),cls:"primary",value:!0}])){i.paused=!1,i.rewards.essence=Math.floor(i.rewards.essence*.5),i.rewards.xp=Math.floor(i.rewards.xp*.5),i.finish(!1);return}i.paused=!1,this.pause();return}i.paused=!1,je.gameplayStart(),nr()}))},finishExpedition(i,e,t){je.gameplayStop();const n=this.combat,s=n.islandIdx,a={victory:i,rewards:e,xp:[],essence:e.essence,fragments:0,crystals:0,passXp:0,contractsDone:[],newEntries:0,unlocked:""};for(const l of e.sealed){const c=!!C.creatures[l.id],h=n_(l.id,l.level,l.perfect);l.isNew=h.isNew,a.fragments+=h.fragments,c||a.newEntries++}if(e.bossSealed){const l=It[s],c=ct[l.boss].el,h=!C.islands.cleared.includes(s),d=h?12:6;C.fragments[c]=(C.fragments[c]||0)+d,a.fragments+=d,h&&(C.islands.cleared.push(s),C.stats.bosses++,a.crystals=25,C.crystals+=25,s+1<It.length&&C.islands.unlocked<s+1&&(C.islands.unlocked=s+1,a.unlocked=re(It[s+1].name)))}C.essence+=e.essence;for(const l of n.team.map(c=>c.id)){const c=C.creatures[l],h=t.includes(l)?1:.5,d=Math.round(e.xp*h),u=i_(l,d);c.bondXp+=t.includes(l)?12:4,Hh(c),a.xp.push({id:l,xp:d,ups:u,level:c.level})}const r=pr().rank;C.rankXp+=Math.round(e.xp*.6+e.sealed.length*25+(e.bossSealed?150:0)),pr().rank>=10&&r<10&&setTimeout(()=>Et(x("thirdSlot"),"gold"),1200),a.passXp=30+e.sealed.length*10+(e.bossSealed?40:0),Xh(a.passXp),C.stats.runs++,i&&(a.contractsDone=ss("runs")),a.contractsDone=[...a.contractsDone,...C.contracts.list.filter(l=>l.progress>=l.goal&&!l.claimed&&!a.contractsDone.includes(l))],Gh(),Yl(),a.canDouble=i&&je.hasRewarded()&&e.essence>0,as(),this.endCombat(),this.current="results",document.body.classList.remove("in-combat"),this.showcase.activate(),rr("menu"),px(a),e.bossSealed||a.newEntries?Ee.sealPerfect():Ee.levelUp()},endCombat(){this.combat&&(this.combat.dispose(),this.combat=null,fx(),document.body.classList.remove("in-combat"))},async buyCosmetic(i,e,t){const n=i==="tint"?Xs[e]:i==="seal"?Ru[e]:Pu[e];if(!n)return;const s=i==="tint"?C.cosmetics.tints:i==="seal"?C.cosmetics.seals:C.cosmetics.effects;if(s.includes(e))return;const a=`${Oe.crystal.replace("<svg",'<svg style="width:1.1em;height:1.1em;vertical-align:-.15em"')} ${At(n.price)}`;if(C.crystals<n.price){await pn(x("notEnoughCrystals"),`<p>${x("needCrystals",{n:At(n.price-C.crystals)})}</p>`,[{label:x("close"),value:!1},{label:x("getCrystals"),cls:"primary",value:!0}])&&this.go("shop",{tab:je.canBuy()?"crystals":"free"});return}await vl(re(n.name),a)&&(C.crystals-=n.price,s.push(e),i==="tint"&&C.creatures[n.creature]&&(C.creatures[n.creature].tint=e),i==="seal"&&(C.cosmetics.seal=e),i==="effect"&&(C.cosmetics.effect=e),as(),Ee.sealPerfect(),Et(x("purchased",{name:re(n.name)}),"gold"),t?.())},async buyProduct(i){const e=xo[i];if(!e)return;if(!je.canBuy()){Et(x("paymentsOff"));return}if(await vl(re(e.name),`US$ ${e.usd.toFixed(2)}`))try{as(),await je.buy(i,document.documentElement.lang)}catch{Et(x("paymentError"))}},grantProduct(i,e){const t=xo[i];if(!t||C.purchases.sessions.includes(e))return!1;C.purchases.sessions.push(e);const n=t.grant;if(n.crystals&&(C.crystals+=n.crystals),n.passPremium&&(C.pass.premium=!0),n.noAds&&(C.purchases.noAds=!0,je.noAds=!0),i==="fundador"&&(C.purchases.founder=!0),n.starterPrism){const s=Object.keys(C.creatures)[0]||"fenix",a=`${s}_prisma`;C.cosmetics.tints.includes(a)||C.cosmetics.tints.push(a),C.creatures[s]&&(C.creatures[s].tint=a)}for(const s of n.seals||[])C.cosmetics.seals.includes(s)||C.cosmetics.seals.push(s);for(const s of n.effects||[])C.cosmetics.effects.includes(s)||C.cosmetics.effects.push(s);return as(),!0}};class mx{constructor(e){this.renderer=e,this.scene=new Uh,this.camera=new qt(40,innerWidth/innerHeight,.1,300),this.lights=Kh(this.scene),this.scene.fog.density=.02,this.scene.add(jh(700,120)),this.items=[],this.mode="",this.drag={on:!1,x:0,rot:0,vel:0},this.motes=this.makeMotes(),this.scene.add(this.motes),this.t=0,this.camTarget=new R,this.camPos=new R(0,3,12)}makeMotes(){const t=new bt,n=new Float32Array(160*3);for(let a=0;a<160;a++)n[a*3]=(Math.random()-.5)*30,n[a*3+1]=Math.random()*10,n[a*3+2]=(Math.random()-.5)*20;t.setAttribute("position",new Dt(n,3));const s=new zl({map:Cs(),color:13617407,size:.22,transparent:!0,opacity:.6,blending:Vt,depthWrite:!1});return new Hl(t,s)}activate(){this.renderer.setScene(this.scene,this.camera)}clear(){for(const e of this.items)this.scene.remove(e.v.group),e.v.dispose();this.items=[]}setTeam(e,t="menu"){const n=t+JSON.stringify(e);if(this.mode===n)return;this.mode=n,this.clear();const s=innerWidth<innerHeight,a=t==="starter"?s?[[-2.7,0,0],[0,0,-1.4],[2.7,0,0]]:[[-5.2,0,0],[0,0,-.6],[5.2,0,0]]:s?[[0,0,1.6],[-3.2,0,-2.2],[3.2,0,-2.6]]:[[3.2,0,1.8],[.4,0,-2.2],[6.6,0,-1.6]];e.forEach((r,o)=>{const l=new pl(r.id,{form:Math.max(1,r.form??1),glow:r.glow,seal:r.seal}),[c,h,d]=a[o]||[o*3,0,0];l.group.position.set(c,h,d),l.pivot.rotation.y=t==="starter"?0:-.5+o*.1,this.scene.add(l.group),this.items.push({v:l,base:new R(c,h,d),heading:l.pivot.rotation.y})}),t==="starter"&&s?(this.camPos.set(0,3.5,17),this.camTarget.set(0,-2.2,0)):t==="starter"?(this.camPos.set(0,4.2,15),this.camTarget.set(0,1.6,0)):s?(this.camPos.set(0,6,16),this.camTarget.set(0,5,0)):(this.camPos.set(-2.5,4.4,13.5),this.camTarget.set(1.2,1.6,0))}setSingle(e,{form:t=1,glow:n,seal:s,offsetX:a=0}={}){const r="single"+e+t+n+s+a;if(this.mode===r)return;this.mode=r,this.clear();const o=new pl(e,{form:1,glow:n||ct[e].color,seal:s,scale:t===2?.95:t===1?.8:.66});o.group.position.set(0,0,0),this.scene.add(o.group),this.items.push({v:o,base:new R,heading:.5}),this.drag.rot=.5;const l=o.height,c=innerWidth<innerHeight,h=c?0:a*(l*.35+.8);this.camPos.set(h,l*.75+1,c?l*3.2+7:l*2.4+4.5),this.camTarget.set(h,c?-l*.55:l*.45,0),this.singleOffset=a}setGlow(e){for(const t of this.items)t.v.setGlow(e)}bindDrag(e){e.addEventListener("pointerdown",t=>{this.mode.startsWith("single")&&(this.drag.on=!0,this.drag.x=t.clientX)}),window.addEventListener("pointermove",t=>{if(!this.drag.on)return;const n=t.clientX-this.drag.x;this.drag.x=t.clientX,this.drag.rot+=n*.012,this.drag.vel=n*.012}),window.addEventListener("pointerup",()=>{this.drag.on=!1})}update(e){this.t+=e,this.camera.position.lerp(this.camPos,Math.min(1,e*3)),this.camera.lookAt(this.camTarget);const t=this.mode.startsWith("single");t&&!this.drag.on&&(this.drag.rot+=this.drag.vel,this.drag.vel*=.94,this.drag.rot+=e*.25),this.items.forEach((a,r)=>{const o=t?this.drag.rot:a.heading+Math.sin(this.t*.4+r)*.15;a.v.pivot.rotation.y=o,a.v.update(e,{})});const n=this.lights.pool;for(let a=0;a<n.length;a++){const r=this.items[a];r?(n[a].color.copy(r.v.glowColor),n[a].intensity=12,n[a].distance=14,n[a].position.set(r.v.group.position.x,r.v.height*.6+1,r.v.group.position.z+1.2)):n[a].intensity=0}const s=this.motes.geometry.attributes.position;for(let a=0;a<s.count;a++){let r=s.getY(a)+e*.35;r>10&&(r=0),s.setY(a,r)}s.needsUpdate=!0}}const au=document.getElementById("boot-txt");function ru(i){au.textContent=i,document.querySelector("#boot .ring")?.remove()}async function gx(){je.setHooks({pause:()=>{dc(!0),ye.combat&&(ye.combat.paused=!0)},resume:()=>{dc(!1),ye.combat&&!document.querySelector(".modal-back, .sealing")&&(ye.combat.paused=!1)}}),je.loadingStart?.(),await je.init(),await fu(),bl(_u(C.settings.lang)),C.ads.date!==di()&&(C.ads={date:di(),ink:0,chest:!1}),je.noAds=!!C.purchases.noAds,Xd(C.settings.music,C.settings.sfx);const e=document.getElementById("gl");let t;try{t=new R_(e)}catch{ru(x("noWebgl"));return}C.settings.quality!=="auto"&&t.setQuality(C.settings.quality),ye.renderer=t,await qh(c=>{au.textContent=`${x("loading")} ${Math.round(c*100)} %`}),ye.showcase=new mx(t),ye.showcase.activate(),ye.showcase.bindDrag(document.getElementById("ui")),V_(document.getElementById("joy"),document.getElementById("knob"),document.getElementById("area"));const n=()=>{Sl(),window.removeEventListener("pointerdown",n),window.removeEventListener("keydown",n)};window.addEventListener("pointerdown",n),window.addEventListener("keydown",n),document.addEventListener("visibilitychange",()=>{document.hidden?(Su(),ye.combat&&!ye.combat.paused&&!ye.combat.over&&ye.pause(),ht()):wu()}),window.addEventListener("pagehide",()=>ht()),document.getElementById("boot").remove(),je.loadingStop();try{const c=await je.consumeReturn();c&&ye.grantProduct(c.sku,c.session)&&setTimeout(()=>Et(x("purchaseDone",{name:re(xo[c.sku].name)}),"gold"),600)}catch{}ye.go("title");let s=performance.now(),a=0,r=0;const o=c=>{const h=Math.min(.1,(c-s)/1e3);s=c,$_(),ye.combat?(Bn("pause")&&!ye.combat.paused&&ye.pause(),ye.combat.update(h)):ye.showcase.update(h),r=ye.combat&&ye.combat.paused?r+1:0,r%4===0&&t.render(h),nr(),a+=h,a>5&&(a=0,gr(),C.stats.playMs+=5e3),l||requestAnimationFrame(o)},l=new URLSearchParams(location.search).has("capture");if(l){let c=performance.now();window.__manual=[],window.__tick=h=>{c+=h*1e3,s=c-h*1e3,o(c);const d=window.__manual.splice(0);for(const u of d)u(c)}}else requestAnimationFrame(o)}gx().catch(i=>{console.error(i),ru("Error: "+(i&&i.message?i.message:i))});window.__sa={app:ye,state:C,input:He};
